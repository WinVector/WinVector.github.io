#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "tmat.h"
#include "mlc.h"

/* return det(m) */
double det3(double (*m)[3][3])
{
  return (*m)[0][0]*((*m)[1][1]*(*m)[2][2] -(*m)[2][1]*(*m)[1][2]) -
    (*m)[0][1]*((*m)[1][0]*(*m)[2][2] - (*m)[2][0]*(*m)[1][2]) +
    (*m)[0][2]*((*m)[1][0]*(*m)[2][1] - (*m)[2][0]*(*m)[1][1]);
}

/* r = inv(m), r can be m */
void inv3(double (*m)[3][3], double (*r)[3][3])
{
  int i,j;
  double t[3][3],d;

  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      t[i][j] = (*m)[i][j];
  d = 1.0/det3(m);
  (*r)[0][0] =  (t[1][1]*t[2][2]-t[2][1]*t[1][2])*d;
  (*r)[1][0] = -(t[1][0]*t[2][2]-t[2][0]*t[1][2])*d;
  (*r)[2][0] =  (t[1][0]*t[2][1]-t[2][0]*t[1][1])*d;
  (*r)[0][1] = -(t[0][1]*t[2][2]-t[2][1]*t[0][2])*d;
  (*r)[1][1] =  (t[0][0]*t[2][2]-t[2][0]*t[0][2])*d;
  (*r)[2][1] = -(t[0][0]*t[2][1]-t[2][0]*t[0][1])*d;
  (*r)[0][2] =  (t[0][1]*t[1][2]-t[1][1]*t[0][2])*d;
  (*r)[1][2] = -(t[0][0]*t[1][2]-t[1][0]*t[0][2])*d;
  (*r)[2][2] =  (t[0][0]*t[1][1]-t[1][0]*t[0][1])*d;
}

/* r = a b, r can be a or b */
void mul3(double (*a)[3][3], double (*b)[3][3], double (*r)[3][3])
{
  int i,j,k;
  double t[3][3];
  
  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      {
	t[i][j] = 0.0;
	for(k=0;k<3;++k)
	  t[i][j] += (*a)[i][k]*(*b)[k][j];
      }
  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      (*r)[i][j] = t[i][j];
}

/* r = a v , r can equal v */
void mulv3(double (*a)[3][3], const double v[], double r[])
{
  int i,j;
  double t[3];
  
  for(i=0;i<3;++i)
    {
      t[i] = 0.0;
      for(j=0;j<3;++j)
	t[i] += (*a)[i][j]*v[j];
    }
  for(i=0;i<3;++i)
    r[i] = t[i];
}


#define sq(x) ((x)*(x))
/* normalize vector */
static void nv3(const double vin[], double v[])
{
  double n;

  n = 1.0/sqrt(sq(vin[0])+sq(vin[1])+sq(vin[2]));
  v[0] = vin[0]*n;
  v[1] = vin[1]*n;
  v[2] = vin[2]*n;
}


#define tol 0.000001
/* orthogonal xform taking v to (||v||,0,0) */
void orthmap(const double vin[], double (*m)[3][3])
{
  int i,j;
  double a[3][3],b[3][3],d,v[3];

  nv3(vin,v);
  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      if(i==j)
	(*m)[i][j] = a[i][j] = b[i][j] = 1.0;
      else
	(*m)[i][j] = a[i][j] = b[i][j] = 0.0;
  if((fabs(v[1])<=tol)&&(fabs(v[2])<=tol))
    {
      if(v[0]<0.0)
	(*m)[0][0] = (*m)[1][1] = -1.0;
      return;
    }
  d = sqrt(sq(v[1])+sq(v[2]));
  a[0][0] = v[0];
  a[0][1] = d;
  a[1][0] = -a[0][1];
  a[1][1] = a[0][0];
  b[1][1] = v[1]/d;
  b[1][2] = v[2]/d;
  b[2][1] = -b[1][2];
  b[2][2] = b[1][1];
  mul3(&a,&b,m);
}


/* b = transpose a (can have b = a) */
void tran3(double (*a)[3][3], double (*b)[3][3])
{
  int i,j;
  double t[3][3];
  
  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      t[i][j] = (*a)[j][i];
  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      (*b)[i][j] = t[i][j];
}



/* find orthogonal xform taking a,b nearly to a',b' */
/* check code against comment */
void orthxform(const double a[], const double bin[], 
               const double ap[], const double bpin[],
	       double (*m)[3][3])
{
  int i,j;
  double ma[3][3],map[3][3],mb[3],mbp[3],n,t1[3][3],t2[3][3],b[3],bp[3];

  orthmap(a,&ma);
  orthmap(ap,&map);
  nv3(bin,b);
  nv3(bpin,bp);
  mulv3(&ma,b,mb);
  n = 1.0/sqrt(sq(mb[1])+sq(mb[2]));
  for(i=0;i<3;++i)
    mb[i] *= n;
  mulv3(&map,bp,mbp);
  n = 1.0/sqrt(sq(mbp[1])+sq(mbp[2]));
  for(i=0;i<3;++i)
    mbp[i] *= n;
  for(i=0;i<3;++i)
    for(j=0;j<3;++j)
      if(i==j)
	t1[i][j] = t2[i][j] = 1.0;
      else
	t1[i][j] = t2[i][j] = 0.0;
  t1[1][1] =  mb[1];
  t1[1][2] =  mb[2];
  t1[2][1] = -t1[1][2];
  t1[2][2] =  t1[1][1];
  t2[1][1] =  mbp[1];
  t2[1][2] = -mbp[2];
  t2[2][1] = -t2[1][2];
  t2[2][2] =  t2[1][1];
  mul3(&t1,&ma,m);
  mul3(&t2,m,m);
  tran3(&map,&map);
  mul3(&map,m,m);
}


void pmat3(double (*a)[3][3])
{
  int i,j;
  
  for(i=0;i<3;++i)
    {
      if(i==0)
	(void)printf("[ [ ");
      else
	(void)printf("  [ ");
      for(j=0;j<3;++j)
	(void)printf("%8g ",(*a)[i][j]);
      if(i==2)
	(void)printf("] ]\n");
      else
	(void)printf("]\n");
    }
}




/* produces 12 orthogonal xforms (orientation preserving symmetries of tet)*/
void tet_maps(double (*m)[12][3][3])
{
  int i,j,k;
  double tet[4][3];

  /* put tetrahral pts on unit sphere */
  tet[0][0] = 0.0;
  tet[0][1] = 0.0;
  tet[0][2] = 1.0;
  tet[1][0] = 2.0*sqrt(2.0)/3.0;
  tet[1][1] = 0.0;
  tet[1][2] = -1.0/3.0;
  tet[2][0] = -sqrt(2.0)/3.0;
  tet[2][1] = sqrt(6.0)/3.0;
  tet[2][2] = -1.0/3.0;
  tet[3][0] = -sqrt(2.0)/3.0;
  tet[3][1] = -sqrt(6.0)/3.0;
  tet[3][2] = -1.0/3.0;
  
  /* get transitive group on directed edges */
  k = 0;
  for(i=0;i<4;++i)
    for(j=0;j<4;++j)
      if(i!=j)
        orthxform(tet[0],tet[1],tet[i],tet[j],(*m)+k++);
}




#if 0
main()
{
  int i;
  double m[3][3],a[3][3],n[3][3],v[3],rv[3];

  m[0][0] = 1.0;
  m[0][1] = 2.0;
  m[0][2] = .5;
  m[1][0] = -1.0;
  m[1][1] = 3.0;
  m[1][2] = .5;
  m[2][0] = 1.0;
  m[2][1] = 0.0;
  m[2][2] = .5;
  v[0] = 1.0;
  v[1] = -1.0;
  v[2] = 1.0;
  
  pmat3(&m);
  (void)printf("det = %g\n",det3(&m));
  inv3(&m,&a);
  pmat3(&a);
  mul3(&m,&a,&n);
  pmat3(&n);
  mul3(&a,&m,&n);
  pmat3(&n);
  for(i=0;i<3;++i)
    (void)printf("%g ",v[i]);
  (void)printf("\n");
  mulv3(&a,v,rv);
  for(i=0;i<3;++i)
    (void)printf("%g ",rv[i]);
  (void)printf("\n");
  for(i=0;i<3;++i)
    (void)printf("%g ",v[i]);
  (void)printf("\n");
  orthmap(v,&a);
  (void)printf("det %g\n",det3(&a));
  mulv3(&a,v,rv);
  for(i=0;i<3;++i)
    (void)printf("%g ",rv[i]);
  (void)printf("\n");
  pmat3(&a);
  tran3(&a,&m);
  mul3(&a,&m,&n);
  pmat3(&n);
  return 0;
}
#endif

