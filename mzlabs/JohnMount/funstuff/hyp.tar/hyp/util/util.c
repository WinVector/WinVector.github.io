
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

static char rcsid[] = "$Header: /home/cvs/cvsroot/c/util/util.c,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $" ;

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <unistd.h>
#include <math.h>
/* #include <stdlib.h> */
#ifdef HANDLE_SIGNALS
#include <signal.h>
#endif
#include <sys/errno.h>
#ifndef NOTIME
#include <time.h>
#ifdef _AIX
#include <time.h>
#else
#include <sys/time.h>
#endif
#include <sys/resource.h>
#ifdef __hpux
#include <sys/syscall.h>
#endif
#endif
#include "config.h"
#include "myutil.h"


#ifdef __STDC__
extern mlibreal atof(const char *s);
extern int atoi(const char *s);
extern void exit(int i);
/*extern void free(char *p);*/
#ifndef _gcc
extern int atexit(void (*f)(void));
#endif
#ifndef _gcc
extern int psignal(unsigned sig,const char *pfix);
#endif
#ifdef _AIX
typedef void *sigptrtype;
#else
typedef void (*sigptrtype)(int);
#endif
#else
extern mlibreal atof();
extern int atoi();
extern void exit();
/* extern void free(); */
extern int psignal();
#ifdef CMUCS
extern int atexit();   /* also defined in __STDC__ case */
#endif
#ifdef _AIX
typedef void *sigptrtype;
#else
typedef int (*sigptrtype)();
#endif
#endif


/* try to pick up ANY error hooks */


#ifdef STRICTMATH
#ifdef __STDC__
int matherr(struct exception *e)
#else
int matherr()
#endif
{
  punt("matherr");
  return 0;  /* not reached */
}


#ifdef __STDC__
double ifnan(int i)
#else
double ifnan(i)
     int i;
#endif
{
  (void)fprintf(stderr,"\nifnan called with %d\n",i);
  punt("math error");
  return 0.0;  /* not reached */
}
#endif


static char tstr2[stlen+sizeof(double)];


#ifdef __STDC__
long now(void)
#else
long now()
#endif
{
  struct timeval tp;
  struct timezone tzp;

  gettimeofday(&tp,&tzp);
  return tp.tv_sec;
}


/* write time and utilization stats in tstr ( tstr-double has elapsed time)*/
#ifdef __STDC__
char *mydate(void)
#else
char *mydate()
#endif
{
  char *tptr;

#ifdef NOTIME
  tptr = (char *)((double *)tstr2+1); /*weasely */
  *((double *)tstr2) = 0.0;
  tptr[0] = 0;
  return tptr;
#else
  struct timeval tp;
  struct timezone tzp;
  struct tm *tms;
  struct rusage rs;
  char *ts;
  int i,j;
  char tstr[stlen];
  realtype rtime;

  tptr = (char *)((double *)tstr2+1); /*weasely */
#ifndef __hpux
  (void)getrusage(RUSAGE_SELF,&rs);
#else
  (void)syscall(SYS_GETRUSAGE,RUSAGE_SELF,&rs);
#endif
  (void)gettimeofday(&tp,&tzp);
  tms = localtime(
#if defined(_AIX) || defined(__STDC__)
                  (time_t *)
#endif
                  (&(tp.tv_sec)));
  ts = asctime(tms);
  for(i=0,j=0;(ts[j]!='\n')&&(ts[j]!=0)&&(i<stlen-1);++i,++j)
    tstr[i] = ts[j];
#if (!defined(_AIX)) && (!defined(__hpux)) && (!defined(_sgi)) && (!defined(_gcc))
  if(tms->tm_zone!=(char *)NULL)
    {
      if(i<stlen-1)
        {
          tstr[i] = ' ';
          ++i;
          for(j=0;(tms->tm_zone[j]!='\n')&&(tms->tm_zone[j]!=0)&&(i<stlen-1);
              ++i,++j)
            tstr[i] = tms->tm_zone[j];
        }
    }
#endif
  tstr[i] = 0;
  rtime = ((realtype)(rs.ru_utime.tv_sec+rs.ru_stime.tv_sec)) +
    ((realtype)(rs.ru_utime.tv_usec+rs.ru_stime.tv_usec)/1000000.0);
  *((double *)tstr2) = rtime;  /* squirel away */
#ifdef CMUCS
  (void)snprintf(tptr,stlen,"%s (user %ds %du, sys %ds %du)",tstr,
                 rs.ru_utime.tv_sec,rs.ru_utime.tv_usec,
                 rs.ru_stime.tv_sec,rs.ru_stime.tv_usec);
#else
  (void)sprintf(tptr,"%s (user %lds %ldu, sys %lds %ldu)",tstr,
                 rs.ru_utime.tv_sec,rs.ru_utime.tv_usec,
                 rs.ru_stime.tv_sec,rs.ru_stime.tv_usec);
#endif
  return tptr;
#endif
}



static int abb_exit = 0;



/* can be called before exit if not CMUCS or __STDC__ */
#ifdef __STDC__
static void do_finish_up(int quiet)
#else
static void do_finish_up(quiet)
   int quiet;
#endif
{
  static int been = 0;

  if(!been)
    {
      if(!quiet)
        {
          (void)fprintf(stderr,"\nEXITING(e=%d): %s\n",errno,mydate());
          if(abb_exit&&errno)
            {
              (void)perror(" system error status ");
              /* can't find man page entry of matherr() or errno */
            }
        }
      been = 1;
    }
}



#ifndef use_wax
#if defined(CMUCS)||(defined(__STDC__)&&!defined(_gcc))
#ifdef __STDC__
static void do_finish_up_q(void)
#else
static void do_finish_up_q()
#endif
{
  do_finish_up(1);
}
#endif
#endif


/* can be called before exit if not CMUCS or __STDC__ */
#ifdef __STDC__
void finish_up(int quiet)
#else
void finish_up(quiet)
int quiet;
#endif
{
#if !(defined(CMUCS)||(defined(__STDC__)&&!defined(_gcc)))
  do_finish_up(quiet);   /* do finish up by hand */
#endif
}


#ifdef HANDLE_SIGNALS

typedef struct {
  int sig;
  char *name;
  } srec_type;

static srec_type bad_signals[] = { 
#ifdef SIGHUP
  {SIGHUP,"SIGHUP"}, 
#endif
#ifdef SIGINT
  {SIGINT,"SIGINT"}, 
#endif
#ifdef SIGQUIT
  {SIGQUIT,"SIGQUIT"}, 
#endif
#ifdef SIGILL
  {SIGILL,"SIGILL"}, 
#endif
#ifdef SIGTRAP
  {SIGTRAP,"SIGTRAP"}, 
#endif
#ifdef SIGIOT
  {SIGIOT,"SIGIOT"},
#endif
#ifdef SIGEMT
  {SIGEMT,"SIGEMT"}, 
#endif
#ifdef SIGFPE
  {SIGFPE,"SIGFPE"}, 
#endif
#ifdef SIGBUS
  {SIGBUS,"SIGBUS"}, 
#endif
#ifdef SIGSEGV
  {SIGSEGV,"SIGSEGV"}, 
#endif
#ifdef SIGSYS
  {SIGSYS,"SIGSYS"},
#endif
#ifdef SIGPIPE
  {SIGPIPE,"SIGPIPE"}, 
#endif
#ifdef SIGALRM
  {SIGALRM,"SIGALRM"}, 
#endif
#ifdef SIGTERM
  {SIGTERM,"SIGTERM"}, 
#endif
#ifdef SIGURG
  {SIGURG,"SIGURG"},  
#endif
#ifdef SIGTTIN
  {SIGTTIN,"SIGTTIN"}, 
#endif
#ifdef SIGTTOU 
  {SIGTTOU,"SIGTTOU"},  
#endif
#ifdef SIGXCPU
  {SIGXCPU,"SIGXCPU"}, 
#endif
#ifdef SIGXFSZ
  {SIGXFSZ,"SIGXFSZ"}, 
#endif
#ifdef SIGABRT
  {SIGABRT,"SIGABRT"},
#endif
#ifdef SIGVTALRM
  {SIGVTALRM,"SIGVTALRM"}, 
#endif
#ifdef SIGPROF
  {SIGPROF,"SIGPROF"}, 
#endif
#ifdef SIGUSR1
  {SIGUSR1,"SIGUSR1"}, 
#endif
#ifdef SIGUSR2
  {SIGUSR2,"SIGUSR2"},
#endif
/*
#ifdef SIGCLD
  {SIGCLD,"SIGCLD"},
#endif
*/
#ifdef SIGPWR
  {SIGPWR,"SIGPWR"}, 
#endif
#ifdef SIGLOST
  {SIGLOST,"SIGLOST"},
#endif
#ifdef SIGDANGER
  {SIGDANGER,"SIGDANGER"},
#endif
#ifdef SIGPRE
  {SIGPRE,"SIGPRE"},
#endif
  {-1,(char *)NULL}};

static srec_type wimpy_signals[] = {  
#ifdef SIGIO
  {SIGIO,"SIGIO"}, 
#endif
#ifdef SIGWINCH
  {SIGWINCH,"SIGWINCH"},
#endif
#ifdef SIGWINDOW
  {SIGWINDOW,"SIGWINDOW"}, 
#endif
  {-1,(char *)NULL}};


#ifdef __STDC__
static void mysighandler(int sig)
#else
static int mysighandler(sig
#ifndef _AIX
                        ,code,scp
#endif
                        )
     int sig;
#ifndef _AIX
     int code;
     struct sigcontext *scp;
#endif
#endif
{
#ifdef __hpux
  int i;
#endif

#if (!defined(_AIX)) && (!defined(__STDC__))
  (void)fprintf(stderr,"\nSIGNAL: (sig= %d, code= %d)",sig,code);
#else
  (void)fprintf(stderr,"\nSIGNAL: (sig= %d)",sig);
#endif
#ifndef __hpux
  (void)psignal((unsigned)sig," ");
#else
  for(i=0;(bad_signals[i].name!=NULL)&&(bad_signals[i].sig!=sig);++i)
    ;
  if(bad_signals[i].name==NULL)
    (void)fprintf(stderr," <unknown signal>\n");
  else
    (void)fprintf(stderr," %s\n",bad_signals[i].name);
#endif
  punt("fatal signal");
}
#endif


#ifdef __STDC__
void start_up(int quiet)
#else
void start_up(quiet)
int quiet;
#endif
{
#ifdef HANDLE_SIGNALS
  int i;
#if (!defined(_AIX)) && (!defined(_sgi)) && (!defined(_gcc))
  struct sigvec v,ov;
#endif
#endif

#ifdef STRICTMATH
  /* force matherr to link in */
  if(abb_exit)
    matherr(NULL);
#endif

#ifdef merge_streams
  dup2(1,2);   /* copy stdout to stderr */
#endif
#ifndef buffer_io
  (void)setbuf(stdout,(char *)NULL);
  (void)setbuf(stderr,(char *)NULL);
#endif
#ifndef use_wax
#if defined(CMUCS)||(defined(__STDC__)&&!defined(_gcc))
  if(atexit(do_finish_up_q))
    punt("coudln't set exit function");
#endif
#endif
#ifdef HANDLE_SIGNALS
  for(i=0;bad_signals[i].name!=NULL;++i)
    {
#if (!defined(_AIX)) && (!defined(_sgi)) && (!defined(_gcc))
      v.sv_mask = 0;
      v.sv_flags = 0;
      v.sv_handler = mysighandler;
#ifdef __hpux
      if(sigvector(bad_signals[i].sig,&v,&ov))
#else
      if(sigvec(bad_signals[i].sig,&v,&ov))
#endif
#else
      if(signal(bad_signals[i].sig,mysighandler)==(sigptrtype)-1)
#endif
        punt("couldn't set signal");
    }
  for(i=0;wimpy_signals[i].name!=(char *)NULL;++i)
    {
#if (!defined(_AIX)) && (!defined(_sgi)) && (!defined(_gcc))
      v.sv_mask = 0;
      v.sv_flags = 0;
      v.sv_handler = SIG_IGN;
#ifdef __hpux
      if(sigvector(wimpy_signals[i].sig,&v,&ov))
#else
      if(sigvec(wimpy_signals[i].sig,&v,&ov))
#endif
#else
      if(signal(wimpy_signals[i].sig,SIG_IGN)==(sigptrtype)-1)
#endif
        punt("couldn't set signal");
    }
#endif
  if(!quiet)
    {
#ifdef __STDC__
#ifdef DEBUG
      (void)fprintf(stderr,
                    "\nSTART(rcs= %s\n  ran=%s __STDC__ libDEBUG=%d): %s\n",
                    rcsid,stringify(myrand),DEBUG,mydate());
#else
      (void)fprintf(stderr,"\nSTART(rcs= %s\n  ran= %s __STDC__): %s\n",
                    rcsid,stringify(myrand),mydate());
#endif
#else
#ifdef DEBUG
      (void)fprintf(stderr,"\nSTART (rcs= %s\n  ran= %s libDEBUG=%d): %s\n",
                    rcsid,stringify(myrand),DEBUG,mydate());
#else
      (void)fprintf(stderr,"\nSTART (rcs= %s\n  ran= %s): %s\n",
                    rcsid,stringify(myrand),mydate());
#endif
#endif
    }
}


#ifdef __STDC__
void dopunt(const char s[],int line, const char file[])
#else
void dopunt(s,line,file)
     char s[],*file;
     int line;
#endif
{
  (void)fflush(stdout);
  if(abb_exit)
    (void)fprintf(stderr,"\nRECURSIVE PUNT!!!\n");
  (void)fprintf(stderr,"\nPUNT %s:\n--- \"%s\" stop at \"%s\":%d\n",
                mydate(),s,file,line);
  abb_exit = 1;
  finish_up(0);
  exit(1);
}


#ifdef __STDC__
void pvec(FILE *f,
          const realtype x[],
          int d)
#else
void pvec(f,x,d)
     FILE *f;
     realtype x[];
     int d;
#endif
{
  int i;

  (void)fprintf(f," [ ");
  for(i=0;i<d;++i)
    (void)fprintf(f,"%g ",(printfreal)x[i]);
  (void)fprintf(f,"]\n");
}



/* usr must call eatline before switching streams!!! */
int saw_newline = 1;
static int lchar = (int)'\n';
static int have_lchar = 1;

/* strip until the next cr, eat any trailing comments */
#ifdef __STDC__
void eatline(FILE *f)
#else
void eatline(f)
     FILE *f;
#endif
{
  if(!feof(f))
    {
      do { /* finish off a line */
        lchar = getc(f);
      } while((lchar!='\n')&&(!feof(f))&&(lchar!=EOF));
    }
  else
    lchar = EOF;
  saw_newline = 1;
  have_lchar = 1;
}


/* get the next character from input */
/* change all whitespace to spaces and eat lines beginning with '#' */
/* don't want to have to peek past cr's for getreal and getint and confuse */
/* an interactive user */
#ifdef __STDC__
int nchar(FILE *f)
#else
int nchar(f)
     FILE *f;
#endif
{
  int c;

  if(feof(f))
    {
      c = EOF;
      lchar = EOF;
      have_lchar = 1;
    }
  else
    {
      c = getc(f);
      lchar = c;
      have_lchar = 1;
      if(c!=EOF)
        {
          if(saw_newline&&(c=='#'))
            {
              eatline(f);
              c = ' ';
            }
          else
            {
              if(c=='\n')         /* on new line? */
                {
                  saw_newline = 1;
                  c = ' ';
                }
              else
                {
                  saw_newline = 0;
                  if((!isascii(c))||isspace(c))
                    c = ' ';
                }
            }
        }
    }
  return c;  /* only one exit point for easy debugging */
}


#ifdef __STDC__
static void myungetc(FILE *f)
#else
static void myungetc(f)
     FILE *f;
#endif
{
  if(!have_lchar)
    punt("nested ungetc");
  if(ungetc(lchar,f)==EOF)
    punt("ungetc failed");
  have_lchar = 0;
}


#define tlen 1024

#ifdef __STDC__
int getint(FILE *f)
#else
int getint(f)
     FILE *f;
#endif
{
  static char tstr[tlen];
  int i;

  i = 0;
  /* strip to first valid character for an integer */
  do {
    tstr[i] = nchar(f);
  } while((!isdigit(tstr[i]))&&(tstr[i]!='+')&&(tstr[i]!='-')&&
          (tstr[i]!=((char)EOF))&&(tstr[i]!=']')&&(tstr[i]!='[')&&
          (tstr[i]!='}')&&(tstr[i]!='{'));
  if((tstr[i]==((char)EOF))||(tstr[i]==']')||(tstr[i]=='[')||
     (tstr[i]=='}')||(tstr[i]=='{'))
    punt("expected an int");
  do {
    if(i>=tlen-2)
      punt("digit sequence too long");
    tstr[++i] = nchar(f);
  } while(isdigit(tstr[i])||(tstr[i]=='+')||(tstr[i]=='-'));
  myungetc(f);
  return atoi(tstr);
}


/* finds first occurrence (case invarient) slowly */
#ifdef __STDC__
char *mystrpos(char *pattern, char *str)
#else
char *mystrpos(pattern,str)
     char *pattern,*str;
#endif
{
  char *i;
  int j;

  for(i=str;*i!=0;++i)  /* try different positions */
    {
      j = 0;
      /* code to work around stupid versions of tolower and toupper */
      while(((i[j]==pattern[j])||
             (isupper(i[j])&&(tolower(i[j])==pattern[j]))||
             (islower(i[j])&&(toupper(i[j])==pattern[j])))
            &&(pattern[j]!=0)
            &&(i[j]!=0))
        ++j;
      if(pattern[j]==0)
        return i;       /* found it */
    }
  return (char *)NULL;  /* nope */
}


/* extended to allow +-Infinity (or huge) */
/* extended to allow the HP notation of ++ (Infinity) and -- (-Infinity) */
#ifdef __STDC__
int getreal(FILE *f,realtype *r)
#else
int getreal(f,r)
     FILE *f;
     realtype *r;
#endif
{
  static char tstr[tlen];
  int i;

  i = 0;
  /* strip to first valid character for an integer */
  do {
    tstr[i] = nchar(f);
  } while((!isdigit(tstr[i]))&&(tstr[i]!='+')&&(tstr[i]!='-')&&(tstr[i]!='.')&&
          (tstr[i]!=((char)EOF))&&(tstr[i]!=']')&&(tstr[i]!='[')&&
          (tstr[i]!='}')&&(tstr[i]!='{')&&
          (!isalpha(tstr[i])));
  if((tstr[i]==((char)EOF))||(tstr[i]==']')||(tstr[i]=='[')||
     (tstr[i]=='}')||(tstr[i]=='{'))
    return 0;
  do {
    if(i>=tlen-2)
      return 0;
    tstr[++i] = nchar(f);
  } while(isdigit(tstr[i])||(tstr[i]=='+')||(tstr[i]=='-')||(tstr[i]=='.')
          ||(tstr[i]=='e')||(tstr[i]=='E')||isalpha(tstr[i]));
  myungetc(f);
  tstr[i] = 0; 
  /* look for +- infinity */
  if((mystrpos("inf",tstr)!=(char *)NULL)||
     (mystrpos("huge",tstr)!=(char *)NULL)||
     (mystrpos("++",tstr)!=(char *)NULL)||
     (mystrpos("--",tstr)!=(char *)NULL))
    {
      if(mystrpos("-",tstr)==(char *)NULL)
        *r = HUGE;
      else
        *r = -HUGE;
    }
  else
    *r = (realtype)atof(tstr);
  return 1;
}


#ifdef __STDC__
void rvec(FILE *f,
          realtype **x,
          int *n)
#else
void rvec(f,x,n)
     FILE *f;
     realtype **x;
     int *n;
#endif
{
  int t;

  *n = 0;
  *x = NULL;

  /* eat initial brace */
  do {
    t = nchar(f);
  } while((t!='[')&&(t!='{')&&(t!=EOF));
  if(t==EOF)
    punt("file ended while looking for open brace in rvec");
  do {
    /* skip over white space */
    do {
      t = nchar(f);
    } while(t==' ');
    if(t==EOF)
      punt("file ended while processing a vector");
    /* done? */
    if((t!=']')&&(t!='}'))
      {
        myungetc(f);
        if(*x==NULL)
          {
            myalloc(*x,realtype,1);
          }
        else
          {
            if(*n>maxdim)
              punt("vector too long");
            myrealloc(*x,realtype,*n+1);
          }
         if(!getreal(f,&((*x)[*n])))
           punt("expected a real while reading vector");
        *n += 1;
      }
  } while((t!=']')&&(t!='}'));
}


#ifdef __STDC__
void pmat(FILE *f,
          const realtype * const A[],
          int m,
          int n)
#else
void pmat(f,A,m,n)
     FILE *f;
     realtype *A[];
     int m,n;
#endif
{
  int i;

  (void)fprintf(f,"[\n");
  for(i=0;i<m;++i)
    {
      (void)fprintf(f," ");
      pvec(f,A[i],n);
    }
  (void)fprintf(f,"]\n");
}



#ifdef __STDC__
void rmat(FILE *f,
          realtype ***A,
          int *m,
          int *n)
#else
void rmat(f,A,m,n)
     FILE *f;
     realtype ***A;
     int *m,*n;
#endif
{
  int t,a;
  realtype *r;

  *n = 0;
  *m = 0;
  *A = NULL;

  /* eat initial brace */
  do {
    t = nchar(f);
  } while((t!='[')&&(t!='{')&&(t!=EOF));
  if(t==EOF)
    punt("file ended while looking for open brace in rmat");
  do {
    /* skip over white space */
    do {
      t = nchar(f);
    } while(t==' ');
    if(t==EOF)
      punt("file ended while processing a matrix");
    /* done? */
    if((t!=']')&&(t!='}'))
      {
        myungetc(f);
        rvec(f,&r,&a);
        if(*A!=NULL)
          {
            if(a!=*n)
              punt("bad row in matrix");
            myrealloc(*A,realtype *,*m+1);
          }
        else
          {
            myalloc(*A,realtype *,1);
            *n = a;
          }
        (*A)[*m] = r;
        *m += 1;
      }
  } while((t!=']')&&(t!='}'));
}


#ifdef __STDC__
realtype mydot(const realtype a[],
             const realtype b[],
             int n)
#else
realtype mydot(a,b,n)
     realtype a[],b[];
     int n;
#endif
{
  int i;
  realtype r;

  r = a[0]*b[0];
  for(i=1;i<n;++i)
    r += a[i]*b[i];

  return r;
}

#ifdef __STDC__
realtype mdot(const realtype a[],
	     const realtype * const A[],
             const realtype b[],
             int n)
#else
realtype mdot(a,A,b,n)
     realtype a[],*A[],b[];
     int n;
#endif
{
  int i;
  realtype r;

  r = a[0]*mydot(A[0],b,n);
  for(i=1;i<n;++i)
    r += a[i]*mydot(A[i],b,n);

  return r;
}



#ifdef __STDC__
realtype *allocreal(int n)
#else
realtype *allocreal(n)
     int n;
#endif
{
  realtype *r;

  if(n<=0)
    punt("allocreal called with bad length");
  myalloc(r,realtype,n);
  return r;
}


#ifdef __STDC__
void freereal(realtype *p)
#else
void freereal(p)
     realtype *p;
#endif
{
  if(p!=(realtype *)NULL)
    free((char *)p);
}


#ifdef __STDC__
realtype **allocmat(int m,int n)
#else
realtype **allocmat(m,n)
     int m,n;
#endif
{
  int i;
  realtype **r;

  if(m<=0)
    return (realtype **)NULL;
  myalloc(r,realtype *,m);
  for(i=0;i<m;++i)
    r[i] = allocreal(n);
  return r;
}


#ifdef __STDC__
void freemat(realtype **A,int m)
#else
void freemat(A,m)
     realtype **A;
     int m;
#endif
{
  int i;

  if((A!=NULL)&&(m>0))
    {
      for(i=0;i<m;++i)
        freereal(A[i]);
      free((char *)A);
    }
}


#ifdef __STDC__
int *allocint(int n)
#else
int *allocint(n)
     int n;
#endif
{
  int *r;

  myalloc(r,int,n);
  return r;
}


#ifdef __STDC__
void freeint(int *p)
#else
void freeint(p)
     int *p;
#endif
{
  if(p!=(int *)NULL)
    free((char *)p);
}


#ifdef __STDC__
realtype max(realtype a,realtype b)
#else
realtype max(a,b)
     realtype a,b;
#endif
{
if(a>b)
  return a;
/* else */
return b;
}


#ifdef __STDC__
realtype min(realtype a,realtype b)
#else
realtype min(a,b)
     realtype a,b;
#endif
{
if(a<b)
  return a;
/* else */
return b;
}


#ifdef __STDC__
void reset_stat(stat_type *a)
#else
void reset_stat(a)
     stat_type *a;
#endif
{
  a->n = 0;
  a->sumx = 0.0;
  a->sumx2 = 0.0;
  a->high = 0.0;
  a->low = 0.0;
  a->mean = 0.0;
  a->stddev = 0.0;
}


#ifdef __STDC__
void collect_stat(stat_type *a,realtype p)
#else
void collect_stat(a,p)
     stat_type *a;
     realtype p;
#endif
{
  if(a->n<=0)
    {
      a->high = p;
      a->low = p;
    }
  else
    {
      if(a->low>p)
        {
          a->low = p;
        }
      else
        if(a->high<p)
          {
            a->high = p;
          }
    }
  a->n += 1;
  a->sumx += p;
  a->sumx2 += sqr(p);
}


#ifdef __STDC__
void calc_stat(stat_type *a)
#else
void calc_stat(a)
     stat_type *a;
#endif
{
  a->mean = a->sumx/a->n;
  a->stddev = (realtype)sqrt((mlibreal)(a->sumx2/a->n - sqr(a->mean)));
}


#if __hpux
/* hpux 8.07 doesn't have rint hpux 9.01 has a FUCKED rint */
/* even this stupid code is better */
#ifdef __STDC__
mlibreal my_rint(mlibreal x)
#else
mlibreal my_rint(x)
     mlibreal x;
#endif
{
#ifdef __STDC__
  extern mlibreal ceil(mlibreal);
#else
  extern mlibreal ceil();
#endif
  return ceil(x-0.5);
}
#endif


#ifdef USE_OWN_NAN
static int nothing_var = 1;
#ifdef __STDC__
void nothing_func(double *a)
#else
void nothing_func(a)
     double *a;
#endif
{
if(nothing_var!=1)  /* optimizer should not be able to eliminate this */
  *a = 0.0;
}

/*
 * isnan quick hack.  bsy, 92 Feb 25.
 *
 * If you trust your compiler to work okay and you have an IEEE 754 compliant
 * floating point unit, just use
 *
 * isnan(d) double d; { return d != d; }
 */
#ifdef __STDC__
int isnan(double d) 
#else
int isnan(d)
     double d; 
#endif
#ifdef TRUST_COMPILER
{ 
  double a;       /* to force optimzier not to get us */
  a = d;
  nothing_func(&a);
  return d != a; 
}
#else
#if     pmax
#define        FP_LITTLE_ENDIAN        1
#else
/*     ibmrt|sun */
#define        FP_LITTLE_ENDIAN        0
#endif

/* assumes IEEE-754, ugh; exponent stored XS127 */

#if	vax
{ return 0; }	/* any better idea? */
#else	/* vax */
{
	unsigned short	*shack = ((unsigned short *) &d);
	int		ebits;

	if (d < 0) d = -d;	/* ignore sign bit */

#if	FP_LITTLE_ENDIAN
	ebits = (shack[3]>>4)&0x7ff;
#else
	ebits = (shack[0]>>4)&0x7ff;
#endif
	if (ebits != 0x7ff) return 0;

	/*
	 * chk mantissa bits not all zero, clear exp bits, check rest.
	 */
#if	FP_LITTLE_ENDIAN
	shack[3] &= ~(0x7ff<<4);
#else
	shack[0] &= ~(0x7ff<<4);
#endif
	return (shack[0] || shack[1] || shack[2] || shack[3]);
}
#endif	/* vax */
#endif /* TRUST_COMPILER */
#endif /*use own nan*/

#ifdef USE_OWN_LOG1P
/* lousy version of function- but we try not to use it */
#ifdef __STDC__
mlibreal log1p(mlibreal x)
#else
mlibreal log1p(x)
     mlibreal x;
#endif
{
  int i,n;
  mlibreal t,t2;

  if(fabs(x)>=0.3)
    return(log(1.0+x));
  /* else */
  /* determine how many terms will be significant */
  t = x;
  n = 1;
  while(t*t+x!=x)  /* find signifcance fall off */
    {
      t *= x;
      ++n;
      if(n>=40)
        punt("log1p blew up");
    }
  t = 0.0;
  t2 = -x;
  for(i=1;i<n;++i)
    {
      t += -t2/((mlibreal)i);
      t2 = -t2*x;
    }
  return t;
}
#endif

void vmult(double **a, int am, int an, double *v, int vm, double *r, int rm)
{
  int i,j;
  double t;

  if(v==r) 
    punt("dependent pointers");
  if((vm!=an)||(am!=rm))
    punt("size mismatch");
  for(i=0;i<rm;++i) {
    t = 0.0;
    for(j=0;j<an;++j) {
      t += a[i][j]*v[j];
    }
    r[i] = t;
  }
}

void mmult(double **a, int am, int an, double **b, int bm, int bn,
	   double **c, int cm, int cn)
{
  int i,j,k;
  double t;

  if((a==c)||(b==c)) {
    punt("dependent pointers");
  }
  if((an!=bm)||(am!=cm)||(bn!=cn)) {
    punt("sizes are wrong");
  }
  for(i=0;i<cm;++i) {
    for(j=0;j<cn;++j) {
      t = 0.0;
      for(k=0;k<bm;++k) {
	t += a[i][k]*b[k][j];
      }
      c[i][j] = t;
    }
  }
}

void mtrans(double **a, int am, int an, double **b, int bm, int bn)
{
  int i,j;

  if(a==b) 
    punt("dependent pointers to trans");
  if((am!=bn)&&(an!=bm))
    punt("size mismatch");
  for(i=0;i<am;++i) {
    for(j=0;j<an;++j) {
      b[j][i] = a[i][j];
    }
  }
}
