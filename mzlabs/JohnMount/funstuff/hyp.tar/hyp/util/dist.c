
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

static char rcsid[] = "$Header: /home/cvs/cvsroot/c/util/dist.c,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $" ;

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <sys/errno.h>
#include "config.h"
#include "dist.h"
#include "myutil.h"
#include "nr.h"


#ifdef __STDC__
int rmodn(int n)
#else
int rmodn(n)
  int n;
#endif
{
  int i;
  
  do {
#ifdef RAND_IS_INT
    i = ((int)(floor((mlibreal)(((myrand&bconst)/((realtype)bconst))*(n)))));
#else
    i = ((int)(floor((mlibreal)(myrand*(n)))));
#endif
  } while((i<0)||(i>=n));
  return i;
}


/* generate an exponentially distributed random variable */
/* mean 1.0, stddev 1.0, when u = Infinity and l = 0  */
#ifdef __STDC__
realtype expv(realtype l, realtype u)
#else
realtype expv(l,u)
     realtype l,u;
#endif
{
  realtype x,a,b;

  if(u>=HUGE)
    a = 0.0;
  else
    a = (realtype)exp((mlibreal)(-1.0*u));
  b = (realtype)exp((mlibreal)(-1.0*l));
  do {
    x = uniform(a,b);
  } while(x<=0.0);
  return (realtype)(-1.0*log((mlibreal)x));
}


/* generate a uniform random variable */
/* mean 1/2 stddev 1/12, when l = 0 and u = 1 */
#ifdef __STDC__
realtype univ(realtype l,realtype u)
#else
realtype univ(l,u)
     realtype l,u;
#endif
{
  if((l<=-HUGE)||(u>=HUGE))
    punt("unbounded range for uniform distribution");
  return uniform(l,u);
}




/* the chop distributions use rejection sampling- so must be */
/* convex constraints that contain a good fraction of the distribution */
/* given an m by n  matrix A, vector b, return y = Ax + b */
/* where x is normally distributed coordinate wise by distfunc */
/* subject to Cx <= d (k constraints) */
/* each coordinate is generated from its coordinate distribution and */
/* then rejection sampled to meet l_i <= x_i <= u_i */
#ifdef __STDC__
void spacedist(const realtype * const A[],
               const realtype b[],
               int m,
               int n,
               const realtype * const C[],
               const realtype d[],
               int k,
               int w,
               const realf2 distfunc[],
               const realtype l[],
               const realtype u[],
               realtype y[])
#else
void spacedist(A,b,m,n,C,d,k,w,distfunc,l,u,y)
     realtype *A[],b[],*C[],d[],l[],u[],y[];
     int m,n,k,w;
     realf2 distfunc[];
#endif
{
  int i,rejected;
  realtype x[maxdim];

  if((n>maxdim)||(m>maxdim)||(k>maxdim)||(w>maxdim))
    punt("dimension too high");

  do {
    /* generate point */
    for(i=0;i<n;++i)
      {
        x[i] = (*(distfunc[i]))(l[i],u[i]);
      }
    /* intersect with constraints */
    rejected = 0;
    for(i=0;(i<k)&&(!rejected);++i)
      {
        if(mydot(C[i],x,w)>d[i])
          rejected = 1;
      }
  } while(rejected);
  /* hit with transformation */
  for(i=0;i<m;++i)
    {
      y[i] = b[i] + mydot(A[i],x,n);
    }
#ifdef DEBUG_dist
  (void)printf("  dist ");
  pvec(stdout,y,m);
#endif
}
