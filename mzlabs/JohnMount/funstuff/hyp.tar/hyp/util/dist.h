
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/* RCS  $Header: /home/cvs/cvsroot/c/util/dist.h,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $  */

#ifndef dist_included
#define dist_included

/* dist stuff */

#ifdef __STDC__
typedef realtype (*realf2)(realtype l,realtype u);
#else
typedef realtype (*realf2)(/*l,u*/);
#endif

  /* currently uses the Unix improved random number generator "random" */
  /* but all direct references are in this block */
  /* try to minimize number of calls to random number generator */
  /* by combining a few uses */

#ifdef RAND_IS_INT
/* the constant in next line must be a power of 2 minus 1 */
#define bconst 0x0fffffff
#define uniform(a,b) ((a) + ((myrand&bconst)/((realtype)bconst))*((b)-(a)))
#define bnumber(b) ((int)rint((mlibreal)((b)*bconst)))
#define biasedcoin(b) ((bnumber(b)>=(myrand&bconst)) ? 1 : 0 )
#define quickcoin(b)  (((b)>=(myrand&bconst)) ? 1 : 0 )
#else

#define uniform(a,b) ((a) + myrand*((b)-(a)))
#define bnumber(b) (b)
#define biasedcoin(b) (((b)>=myrand) ? 1 : 0 )
#define quickcoin(b) biasedcoin(b)
#endif

#define faircoin() biasedcoin(0.5)


#ifdef __STDC__
extern int rmodn(int n);
#ifdef USE_SYSTEM_RANDOM
#ifdef _sgi
extern int srandom(unsigned seed);
#else
/*extern int srandom(int seed); */
#endif
/*extern long random(void); */
/*extern int srand(int seed);
extern long rand(void);*/ 
extern void srand48(long);
extern double drand48(void);
#endif
extern realtype expv(realtype l, realtype u);
extern realtype univ(realtype l,realtype u);
extern void spacedist(const realtype * const A[],
                      const realtype b[],
                      int m,
                      int n,
                      const realtype * const C[],
                      const realtype d[],
                      int k,
                      int w,
                      const realf2 distfunc[],
                      const realtype l[],
                      const realtype u[],
                      realtype y[]);
#else
extern int rmodn(/*int n */);
#ifdef USE_SYSTEM_RANDOM
extern int srandom();
/* extern long random(); */
/*extern int srand();
extern long rand();*/
extern void srand48();
extern double drand48();
#endif
extern void spacedist(/*A,b,m,n,C,d,k,w,distfunc,u,l,y*/);
extern realtype expv(/*realtype l, realtype u*/);
extern realtype univ(/*realtype l,realtype u*/);
#endif

#endif



