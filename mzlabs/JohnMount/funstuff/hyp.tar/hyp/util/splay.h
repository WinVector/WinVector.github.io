#ifndef SPLAY_INCLUDED
#define SPLAY_INCLUDED 

/* RCS  $Header: /home/cvs/cvsroot/c/util/splay.h,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $  */

typedef struct tree_node Tree;
struct tree_node {
    Tree *left, *right;
    gptr item;
};


#ifdef __STDC__
typedef int (*comparetype)(const gptr ,const gptr );
typedef void (*actiontype)(gptr );
extern Tree *splay(const gptr i, Tree *t,comparetype compare);
extern Tree *insert(const gptr i, Tree *t,int *size,comparetype compare);
extern Tree *delete(const gptr i, Tree *t,int *size,comparetype compare);
extern Tree *first(Tree *t,comparetype compare);
extern Tree *last(Tree *t,comparetype compare);
extern Tree *next(Tree *t,comparetype compare);
extern Tree *prev(Tree *t,comparetype compare);
extern void freetree(Tree *t,comparetype comapare, actiontype action);
#else
typedef int (*comparetype)(/*gptr ,gptr  */);
typedef int (*actiontype)(/*gptr  */);
extern Tree *splay(/*i,t,compare*/);
extern Tree *insert(/*i,t,size,compare*/);
extern Tree *delete(/*i,t,size,compare*/);
extern Tree *first(/*t,compare*/);
extern Tree *last(/*t,compare*/);
extern Tree *next(/*t,compare*/);
extern Tree *prev(/*t,compare*/);
extern void freetree(/*t,compare,action*/);
#endif

#endif

