
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/* RCS  $Header: /home/cvs/cvsroot/c/util/config.h,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $  */


#ifndef config_included
#define config_included

/* maximum dimension of our vector space (used to avoid some malloc calls) */
#define maxdim 2000
#define stlen 256
#define sqr(x) ((x)*(x))

/* floating point type, might as well be double since math.h is in doubles */
/* all the appropriate casts are in the code, so float should work here */
typedef double realtype;
/* type of floating point used by math library- don't change this! */
/* it is only here in case there are other libraries available */
typedef double mlibreal;
/* floating point for printf, don't change this without fixing formats */
typedef double printfreal;

#ifdef __STDC__
#define immediate_stringify(x) #x
#else
#define immediate_stringify(x) "x"
#define const
#define signed
#endif

#ifdef __STDC__
#define stringify(x) immediate_stringify(x)
#else
#define stringify(x) "can\'t expand lable"
#endif

#if defined(_AIX) || defined(_gcc)
/* #undef HANDLE_SIGNALS */
#undef HUGE
#endif

#ifdef __STDC__
extern mlibreal rint(mlibreal x);
#else
extern mlibreal rint(/*x*/);
#endif

#ifndef HUGE
#define HUGE 1.0e20
#endif

#define sys_rand 0
#define sys_random 1
#define sys_drand48 2

#ifdef __hpux
#define sysrand_name sys_drand48
#else 
#define sysrand_name sys_random
#endif

#if sysrand_name == sys_random
#define sysrand random()
#else
#if sysrand_name == sys_drand48
#define sysrand drand48()
#else
#define sysrand rand()
#endif
#endif

#define USE_SYSTEM_RANDOM

#ifdef USE_SYSTEM_RANDOM
#if (sysrand_name!=sys_drand48)
#define RAND_IS_INT
#endif
#define myrand sysrand
#else
/* user puts random number generator preference here */
#define myrand rand3()   /* our random number generator */
#endif


/* how many probes can be done (per level) when trying to set parameters */
/* total probes is probably about (3*max_parm_probes)^levels */
#define max_parm_probes 20

/* how many points to sweep per dim in setting radii */
#define r_probes 100

/* base for how accurate each stage of the parameter setter tries to get */
/* each one uses base_accuracy*10**(-2*levels_deep) */
#define base_accuracy 1.0e-10

/* trust the compiler to emit our nan code correclty? */
#define TRUST_COMPILER

#if (!defined(__hpux))&&(!defined(_AIX))&&(!defined(_gcc))
#define USE_OWN_NAN
#endif

#if defined(__hpux)
#define USE_OWN_LOG1P
#define rint my_rint
#endif

#define default_seed 1992

  
#ifdef __STDC__
typedef const void *qsortptr;
typedef void *qsortlist;
typedef size_t qsortint;
typedef void qsortret;
typedef int (*qsortfunc)(qsortptr,qsortptr);
#else
typedef char *qsortptr;
typedef char *qsortlist;
typedef int qsortint;
typedef int qsortret;
typedef int (*qsortfunc)();
#endif


#ifdef __STDC__
typedef void *gptr;
#else
typedef char *gptr;
#endif


#endif

