/*
                   An implementation of top-down splaying.
   		          D. Sleator, March 1992.

  This is adapted from simple top-down splay, at the bottom of page 669 of
  "Self-adjusting Binary Search Trees" by Sleator and Tarjan, JACM Volume 32,
  No 3, July 1985.

  The chief modification here is that the splay operation works even if the
  item being splayed is not in the tree, and even if the tree root of the
  tree is NULL.  So the line:

                              t = splay(i, t);

  causes it to search for item with key i in the tree rooted at t.  If it's
  there, it is splayed to the root.  If it isn't there, then the node put
  at the root is the last one before NULL that would have been reached in a
  normal binary search for i.  (It's a neighbor of i in the tree.)  This
  allows insertion, deletion, split and join to be easily implemented.
*/

static char rcsid[] = "$Header: /home/cvs/cvsroot/c/util/splay.c,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $" ;

/* modified to use an absrtact comparison function and added some wimpy
   traversal commands John Mount 9-3-93 (also uglified defs) */

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "config.h"
#include "myutil.h"
#include "splay.h"

#ifdef __STDC__
Tree *splay(const gptr i, Tree *t,comparetype compare) 
#else
Tree *splay(i,t,compare)
     gptr i;
     Tree *t;
     comparetype compare;
#endif
{
/* Simple top down splay, not requiring i to be in the tree t.  */
/* What it does is described above.                             */
    Tree N, *l, *r, *y;
    if (t == NULL) return t;
    N.left = N.right = NULL;
    l = r = &N;

    for (;;) {
	if (compare(i,t->item)<0) {
	    if (t->left == NULL) break;
	    if (compare(i,t->left->item)<0) {
		y = t->left;                           /* rotate right */
		t->left = y->right;
		y->right = t;
		t = y;
		if (t->left == NULL) break;
	    }
	    r->left = t;                               /* link right */
	    r = t;
	    t = t->left;
	} else if (compare(i,t->item)>0) {
	    if (t->right == NULL) break;
	    if (compare(i,t->right->item)>0) {
		y = t->right;                          /* rotate left */
		t->right = y->left;
		y->left = t;
		t = y;
		if (t->right == NULL) break;
	    }
	    l->right = t;                              /* link left */
	    l = t;
	    t = t->right;
	} else {
	    break;
	}
    }
    l->right = t->left;                                /* assemble */
    r->left = t->right;
    t->left = N.right;
    t->right = N.left;
    return t;
}

#ifdef __STDC__
Tree *insert(const gptr i, Tree *t,int *size,comparetype compare) 
#else
Tree *insert(i,t,size,compare)
     gptr i;
     int *size;
     Tree *t;
     comparetype compare;
#endif
{
/* Insert i into the tree t, unless it's already there.    */
/* Return a pointer to the resulting tree.                 */
    static Tree *ns = NULL;
    Tree *new;
    
    if(ns==NULL)
      myalloc(ns,Tree,1);
    new = ns;
    new->item = (gptr)i;
    if (t == NULL) {
	new->left = new->right = NULL;
	*size = 1;
        ns = NULL;
	return new;
    }
    t = splay(i,t,compare);
    if (compare(i,t->item)<0) {
	new->left = t->left;
	new->right = t;
	t->left = NULL;
	(*size)++;
        ns = NULL;
	return new;
    } else if (compare(i,t->item)>0) {
	new->right = t->right;
	new->left = t;
	t->right = NULL;
	(*size)++;
        ns = NULL;
	return new;
    } else { /* We get here if it's already in the tree */
             /* Don't add it again                      */
	return t;
    }
}


#ifdef __STDC__
Tree *delete(const gptr i, Tree *t,int *size,comparetype compare)
#else
Tree *delete(i,t,size,compare)
     gptr i;
     int *size;
     Tree *t;
     comparetype compare;
#endif
{
/* Deletes i from the tree if it's there.               */
/* Return a pointer to the resulting tree.              */
    Tree * x;
    if (t==NULL) return NULL;
    t = splay(i,t,compare);
    if (compare(i,t->item)==0) {               /* found it */
	if (t->left == NULL) {
	    x = t->right;
	} else {
	    x = splay(i, t->left,compare);
	    x->right = t->right;
	}
	(*size)--;
#ifndef NOFREE
	free(t);
#endif
	return x;
    }
    return t;                         /* It wasn't there */
}


#ifdef __STDC__
Tree *first(Tree *t,comparetype compare)
#else
Tree *first(t,compare)
     Tree *t;
     comparetype compare;
#endif
{
  Tree *p;

  if(t==NULL)
    return t;
  p = t;
  while(p->left!=NULL)
    p = p->left;
  return splay(p->item,t,compare);
}


#ifdef __STDC__
Tree *last(Tree *t,comparetype compare)
#else
Tree *last(t,compare)
     Tree *t;
     comparetype compare;
#endif
{
  Tree *p;

  if(t==NULL)
    return t;
  p = t;
  while(p->right!=NULL)
    p = p->right;
  return splay(p->item,t,compare);
}


#ifdef __STDC__
Tree *next(Tree *t,comparetype compare)
#else
Tree *next(t,compare)
     Tree *t;
     comparetype compare;
#endif
{
  Tree *p;

  if((t==NULL)||(t->right==NULL))
    return t;
  p = t->right;
  while(p->left!=NULL)
    p = p->left;
  return splay(p->item,t,compare);
}


#ifdef __STDC__
Tree *prev(Tree *t,comparetype compare)
#else
Tree *prev(t,compare)
     Tree *t;
     comparetype compare;
#endif
{
  Tree *p;

  if((t==NULL)||(t->left==NULL))
    return t;
  p = t->left;
  while(p->right!=NULL)
    p = p->right;
  return splay(p->item,t,compare);
}


#ifdef __STDC__
void freetree(Tree *t,comparetype compare, actiontype action)
#else
void freetree(t,compare,action)
     Tree *t;
     comparetype compare;
     actiontype action;
#endif
{
  int i= 0;
  gptr tmp= NULL;

  while(t!=NULL)
    {
      tmp = t->item;
      t = delete(t->item,t,&i,compare);
      if((action!=NULL)&&(tmp!=NULL))
        (*action)(tmp);  /* for freeing user stuff */        
    }
}
