
#ifndef nr_included
#define nr_included

/* RCS  $Header: /home/cvs/cvsroot/c/util/nr.h,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $  */

#ifdef __STDC__
/* 1 argument floating point function type */
typedef realtype (*realfunc)(realtype x);
extern void mysrandom(int seed);
extern realtype gasdev(realtype l,realtype u);
extern realtype golden(realtype ax,
                realtype bx,
                realtype cx,
                realfunc f,
                realtype tol,
                realtype *xmin);
extern realtype ran1(void);
extern realtype ran3(void);
extern realtype ran4(void);
extern void sran1(int idum);
extern void sran3(int idum);
extern void sran4(int idum);
extern mlibreal gammp(mlibreal a,mlibreal x);
extern mlibreal gammq(mlibreal a,mlibreal x);
#ifdef USE_OWN_ERF
extern mlibreal erf(mlibreal x);
#endif
extern int LP(const realtype * const A[],const realtype b[],const realtype c[],
	      int m,int n,realtype x[]);
extern int LPpos(const realtype * const A[],const realtype b[],
                 const realtype c[],
                 int m,int n,realtype x[]);
extern int LPposeq(const realtype * const A[],const realtype b[],
                 const realtype c[],
                 int m,int n,realtype x[]);
extern void svdcmp(realtype *a[],int m,int n,realtype w[],realtype *v[]);
extern realtype rtsafe(void (*funcd)(realtype,realtype *,realtype *),
                realtype x1,realtype x2,realtype xacc);
extern mlibreal gammln(mlibreal xx);
extern void ludcmp(realtype **a,int n,int *indx,realtype *d);
extern void lubksb(realtype **a,int n,int *indx,realtype b[]);

/* next 5 routines mnbrak,brent,linmin,powell,dfpmin still index from 1 */
/* also share static structures- so not mutually callable */
extern void mnbrak(double *ax, double *bx, double *cx, double *fa, double *fb,
            double *fc, double (*func)(double));
extern double brent(double ax, double bx, double cx, double (*f)(double),
             double tol, double *xmin);
extern void linmin(double p[], double xi[], int n, double *fret, 
            double (*func)(const double*));
extern void powell(double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*));
extern void nr_dfpmin(double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*), 
            void (*dfunc)(const double*,double*));
void inv(double **a, int am, double **b);
#else
/* floating point function type */
typedef realtype (*realfunc)();
extern void mysrandom();
extern realtype gasdev(/*l,u*/);
extern realtype golden();
extern realtype ran1();
extern realtype ran3();
extern realtype ran4();
extern void sran1(/*idum*/);
extern void sran3(/*idum*/);
extern void sran4(/*idum*/);
extern mlibreal gammp(/*mlibreal a,mlibreal x*/);
extern mlibreal gammq(/*mlibreal a,mlibreal x*/);
#ifdef USE_OWN_ERF
extern mlibreal erf(/*x*/);e
#endif
extern int LP(/*A,b,c,m,n,x*/);
extern int LPpos(/*A,b,c,m,n,x*/);
extern int LPposeq(/*A,b,c,m,n,x*/);
extern void svdcmp(/*a,m,n,w,v*/);
extern realtype rtsafe(/*funcd,x1,x2,xacc*/);
extern mlibreal gammln(/*mlibreal xx*/);
extern void ludcmp(/*realtype **a,int n,int *indx,realtype *d*/);
extern void lubksb(/*realtype **a,int n,int *indx,realtype b[]*/);

/* next 5 routines mnbrak,brent,linmin,powell,dfpmin still index from 1 */
/* also share static structures- so not mutually callable */
extern void mnbrak(/*double *ax, double *bx, double *cx, double *fa, double *fb,
            double *fc, double (*func)(double)*/);
extern double brent(/*double ax, double bx, double cx, double (*f)(double),
             double tol, double *xmin */);
extern void linmin(/*double p[], double xi[], int n, double *fret, 
            double (*func)(const double*) */);
extern void powell(/* double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*) */);
extern void nr_dfpmin(/*double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*), 
            void (*dfunc)(const double*,double*)*/);
void inv(/* double **a, int am, double **b */);
#endif


#endif
