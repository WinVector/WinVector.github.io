
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

static char rcsid[] = "$Header: /home/cvs/cvsroot/c/util/ptope.c,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $" ;

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#ifdef _AIX
#include <stdlib.h>
#endif
#ifdef DEBUG
#ifndef NOTIME
#include <sys/time.h>
#endif
#endif
#ifdef EARLYEXIT
#include <setjmp.h>
#endif
#include "config.h"
#include "ptope.h"
#include "dist.h"
#include "myutil.h"
#include "nr.h"


/* finds the smallest ellipsiod containing a section of the current ellipsiod */
/* taken from GLS p. 71 */
/* returns smallest Ap, ap s.t. {x | (x-ap)^t Ap^-1 (x-ap) <= 1} contains */
/* {x |(x-a)^t A^-1 (x-a) <=1 } intersect {x | c^t x <= gamm } */
/* can NOT have A,a and Ap,ap be identical pointers */
#ifdef __STDC__
void lowerjohn(realtype *A[],const realtype a[],
	       const realtype c[], realtype Gamma,int n,
	       realtype *Ap[], realtype ap[])
#else
void lowerjohn(A,a,c,Gamma,n,Ap,ap)
     realtype *A[],a[],c[],Gamma,*Ap[],ap[];
     int n;
#endif
{
  int i,j;
  realtype alpha,scale,*b,t1,t2;
  
  if((Ap==A)||(ap==a))
    punt("pointer dependence in lowerjohn");
  
  b = allocreal(n);
  scale = 1.0/((realtype)sqrt((mlibreal)(mdot(c,(const realtype * const *)A,
                                              c,n))));
  alpha = (mydot(c,a,n)-Gamma)*scale;
  if(alpha<=-1.0/(realtype)n)
    {                  /* no change */
      for(i=0;i<n;++i)
	{
	  ap[i] = a[i];
	  for(j=0;j<n;++j)
	    Ap[i][j] = A[i][j];
	}
    }
  else
    {
      if(alpha>=1)
	punt("empty elipsoid in lowerjohn");
      t1 = (1.0 + n*alpha)/((realtype)(n+1.0));
      for(i=0;i<n;++i)
	{
	  b[i] = scale*mydot(A[i],c,n);
	  ap[i] = a[i] - t1*b[i];
	}
      t1 = (n*n*(1-alpha*alpha))/((realtype)(n*n-1.0));
      t2 = t1*(2.0*(1.0+n*alpha))/((realtype)((n+1.0)*(1.0+alpha)));
      for(i=0;i<n;++i)
	for(j=0;j<n;++j)
	  Ap[i][j] = t1*A[i][j] - t2*b[i]*b[j];
    }
  freereal(b);
}


/* finds an initial ellipsiod containing Ax <= b */
/* by containing body in a rectangle and then putting the rectagle in */
/* an ellipse */
/* initial point is not necissarily feasible */
#ifdef __STDC__
void bigellipse(realtype *A[],const realtype b[],
               int m,int n,
	       realtype *Ap[], realtype ap[])
#else
void bigellipse(A,b,m,n,Ap,ap)
     realtype *A[],b[],*Ap[],ap[];
     int m,n;
#endif
{
  int i,j;
  realtype *c,*x,h,l;

  c = allocreal(n);
  x = allocreal(n);
  for(i=0;i<n;++i)
    {
      c[i] = 0.0;
      for(j=0;j<n;++j)
	Ap[i][j] = 0.0;
    }
  for(i=0;i<n;++i)
    {
      c[i] = -1;
      if(LP((const realtype * const *)A,(const realtype *)b,
            (const realtype *)c,m,n,x))
	punt("unbounded or infeas LP");
      l = x[i];
      c[i] = 1;
      if(LP((const realtype * const *)A,(const realtype *)b,
            (const realtype *)c,m,n,x))
	punt("unbounded or infeas LP");
      h = x[i];
      ap[i] = (h+l)/2.0;
      Ap[i][i] = (realtype)(n)*(h-l)*(h-l)/4.0;
      c[i] = 0;
    }
  freereal(x);
  freereal(c);
}


#define EPS 3.0e-7
/* choleski decompose positive definite symmetric square matrix A */
/* A = L L^t and L is lower diagonal, overwrite A 0 if good, -1 if bad */
/* data is clobbered if bad */
#ifdef __STDC__
int choleski(realtype *L[], int n)
#else
int choleski(L,n)
     realtype *L[];
     int n;
#endif
{
  int i,j,k;

  for(k=0;k<n;++k)
    {
      if(L[k][k]<=EPS)
        return -1;
      L[k][k] = (realtype)sqrt((mlibreal)L[k][k]);
      for(i=k+1;i<n;++i)
        {
          L[i][k] = L[i][k]/L[k][k];
          for(j=k+1;j<=i;++j)
            L[i][j] -= L[i][k]*L[j][k];
        }
    }
  for(k=0;k<n;++k)
    for(i=k+1;i<n;++i)
      L[k][i] = 0.0;
  return 0;
}
#undef EPS


/* brute round */
/* apply cuts until we can't shrink LJ ellipse any more- this isn't */
/* gauranteed to terminate quickly but when it does we will have */
/* K = {x | Ax<=b }  E = {x | (x-ap)^t Ap^-1 (x-ap) <= 1} with */
/* K contained E and (1/n) E contained in K */
/* returns F,p such that if B is the unit ball around the origin */
/* E = FB + p */
/* this routine is basicly the ellipsoid method (w/o stop conditions) */
#ifdef __STDC__
void greedyround(realtype *A[],const realtype b[],
               int m,int n,
	       realtype *F[], realtype p[])
#else
void greedyround(A,b,m,n,F,p)
     realtype *A[],b[],*F[],p[];
     int m,n;
#endif
{
  int bestindex,i,j;
  realtype alpha,best,**NewAp,*Newp,**Ap;
#ifdef SYMMETRICFACTOR
  realtype **U,*W,**V;
#endif

  bestindex = 0;
  best = 0.0;
  Ap = allocmat(n,n);
  Newp = allocreal(n);
  NewAp = allocmat(n,n);
  bigellipse(A,b,m,n,Ap,p); /* get an initial ellipsoid */
  do {
    /*find deepest cut(doesn't necisarily seperate center,could be shallow)*/
    for(i=0;i<m;++i)
      {
        alpha = (mydot(A[i],p,n)-b[i])/
          ((realtype)sqrt((mlibreal)(mdot(A[i],(const realtype * const *)Ap,
                                          A[i],n))));
        if((i==0)||(alpha>best))
          {
            bestindex = i;
            best = alpha;
          }
      }
    /* try to stop at (101/100) n rounding to avoid long conveging patterns*/
    lowerjohn(Ap,p,A[bestindex],b[bestindex],n,NewAp,Newp);
    for(i=0;i<n;++i)
      {
        p[i] = Newp[i];
        for(j=0;j<n;++j)
          Ap[i][j] = NewAp[i][j];
      }
  } while(best>=(-1.0 + 1.0/(100.0*n))/((realtype)n));
  freemat(NewAp,n);
  freereal(Newp);
#ifdef SYMMETRICFACTOR
  U = allocmat(n,n);
  V = allocmat(n,n);
  W = allocreal(n);
  for(i=0;i<n;++i)
    for(j=0;j<n;++j)
      U[i][j] = Ap[i][j];
  svdcmp(U,n,n,W,V);
  for(i=0;i<n;++i)
    W[i] = (realtype)sqrt((mlibreal)W[i]);
  for(i=0;i<n;++i)
    for(j=0;j<n;++j)
      {
        F[i][j] = 0.0;
        for(k=0;k<n;++k)
          F[i][j] += U[i][k]*W[k]*V[j][k];
      }
  freereal(W);
  freemat(V,n);
  freemat(U,n);
#else
  for(i=0;i<n;++i)
    for(j=0;j<n;++j)
      F[i][j] = Ap[i][j];
  if(choleski(F,n))
    punt("choleski failed");
#endif
  freemat(Ap,n);
}


/* find orthogonal componet of a vector to a given set- then renormalize */
/* if non-zero, return 1 if non-zero, 0 otherwise- the set must be */
/* orthanormal, works on empty set */
#ifdef __STDC__
int orthelim(realtype *v[],int m, int n,realtype nv[])
#else
int orthelim(v,m,n,nv)
     realtype *v[],nv[];
     int m,n;
#endif
{
  int j,k;
  realtype t;

  for(j=0;j<m;++j)
    {
      t = mydot(nv,v[j],n);
      for(k=0;k<n;++k)
        nv[k] -= t*v[j][k];
    }
  if((t = mydot(nv,nv,n))<=1.0e-10)
    return 0;
  /* else */
  t = sqrt(t);
  for(j=0;j<n;++j)
    nv[j] /= t;
  return 1;
}


/* find a directional vector not in the affine space based at v[0] */
/* with span v[1]-v[0] .. v[m]-v[0] */
/* ignore vector v[ignore] if ignore>= 0 (used v[1] as base otherwise) */
/* and use m-1 instead  of m in the ignore >= 0 case */
/* works with m = 0 ... n */
#ifdef __STDC__
void newdir(realtype *v[],int m,int n,realtype nv[],int ignore)
#else
void newdir(v,m,n,nv,ignore)
     realtype *v[],nv[];
     int m,n,ignore;
#endif
{
  int i,j,base,i2;
  realtype **b,t;

  /* build orthogonal basis for span v */
  b = allocmat(m,n);
  if(ignore==0)
    base = 1;
  else 
    base = 0;
  for(i=base+1,i2=0;i<m;++i,++i2)
    if(i!=ignore)
      {
        for(j=0;j<n;++j)
          b[i2][j] = v[i][j] - v[base][j];
        if(!orthelim(b,i2,n,b[i2]))
          punt("non independent set of vectors");
      }
    else
      --i2;  /* back up to get this entry */
  /* try ignored vector for first guess on direction */
  if((ignore>=0)&&(ignore<m))
    {
      t = sqrt(mydot(v[ignore],v[ignore],n));
      if(t>0.0)
        {
          for(j=0;j<n;++j)
            nv[j] = v[ignore][j]/t;
          if(orthelim(b,m-2,n,nv))
            {
              freemat(b,m-1);
              return;
            }
        }
    }
  /* try other directions */
  for(i=0;i<n;++i)
    {
      for(j=0;j<n;++j)
        nv[j] = 0.0;
      nv[i] = 1.0;
      if(ignore>=0)
        {
          if(orthelim(b,m-2,n,nv))
            {
              freemat(b,m-1);
              return;
            }
        }
      else
        {
          if(orthelim(b,m-1,n,nv))
            {
              freemat(b,m-1);
              return;
            }
        }
    }
  punt("no directions left");
}



/* David and Ravi's rounding technique- find a big simplex in the body and */
/* bloat it out */
#ifdef __STDC__
void bigsimplex(realtype *A[], const realtype b[], int m, int n,
             realtype *v[])
#else
void bigsimplex(A,b,m,n,v)
     realtype *A[],b[],*v[];
     int m,n;
#endif
{
  int i,j,furthest,bestindex;
  realtype *c,**e,ratio,maxratio,*bestvertex;


  bestindex = 0;
  maxratio = 0.0;
  /* get initial simplex */
  bestvertex = allocreal(n);
  c = allocreal(n);
  e = allocmat(2,n);
  for(i=0;i<n+1;++i)
    {
      /* get new direction to optimize in */
      newdir(v,i,n,c,-1);
      if(LP((const realtype * const *)A,(const realtype *)b,
            (const realtype *)c,m,n,e[0]))
        punt("unbounded or infeas LP");
      for(j=0;j<n;++j)
        c[j] = -c[j];
      if(LP((const realtype * const *)A,(const realtype *)b,
            (const realtype *)c,m,n,e[1]))
        punt("unbounded or infeas LP");
      if(i==0)
        furthest = 0;
      else
        {
          if(fabs((mlibreal)(mydot(e[0],c,n)-mydot(v[0],c,n)))>=
             fabs((mlibreal)(mydot(e[1],c,n)-mydot(v[0],c,n))))
            furthest = 0;
          else
            furthest = 1;
          if(fabs((mlibreal)(mydot(e[furthest],c,n)-mydot(v[0],c,n)))==0.0)
            punt("degenerate body");
        }
      for(j=0;j<n;++j)
        v[i][j] = e[furthest][j];
    }
  do {
    /* until the simplex is pretty bid keep trying to improve it */
    for(i=0;i<n+1;++i)
      {
        /* get perp direction to base of simplex */
        newdir(v,n+1,n,c,i);
        if(LP((const realtype * const *)A,(const realtype *)b,
              (const realtype *)c,m,n,e[0]))
          punt("unbounded or infeas LP");
        for(j=0;j<n;++j)
          c[j] = -c[j];
        if(LP((const realtype * const *)A,(const realtype *)b,
              (const realtype *)c,m,n,e[1]))
          punt("unbounded or infeas LP");
        if(i==0)
          j = 1;
        else 
          j = 0;
        if(fabs((mlibreal)(mydot(e[0],c,n)-mydot(v[j],c,n)))>=
           fabs((mlibreal)(mydot(e[1],c,n)-mydot(v[j],c,n))))
          furthest = 0;
        else
          furthest = 1;
        ratio = fabs((mlibreal)(mydot(e[furthest],c,n)-mydot(v[j],c,n)))/
          fabs((mlibreal)(mydot(v[i],c,n)-mydot(v[j],c,n)));
        if(ratio<1.0)
          punt("bad ratio");
        if((i==0)||(ratio>maxratio))
          {
            maxratio = ratio;
            bestindex = i;
            for(j=0;j<n;++j)
              bestvertex[j] = e[furthest][j];
          }
      }
    /* put in the improvement */
    for(j=0;j<n;++j)
      v[bestindex][j] = bestvertex[j];
  } while(maxratio>=1.0+1.0/(100.0*n));
  freemat(e,2);
  freereal(c);
  freereal(bestvertex);
}



/* like greedy round- but starts with simplex rounding */
#ifdef __STDC__
void l1round(realtype *A[],const realtype b[], int m, int n,
             realtype *F[], realtype p[],realtype *FI[])
#else
void l1round(A,b,m,n,F,p,FI)
     realtype *A[],b[],*F[],p[],*FI[];
     int m,n;
#endif
{
  realtype **v;

  v = allocmat(m+1,n);
  bigsimplex(A,b,m,n,v);
  
}



/* uniformly generate from the unit ball */
#ifdef __STDC__
void uball(int n,realtype x[])
#else
void uball(n,x)
     realtype x[];
     int n;
#endif
{
  int i;
  realtype d;

  /* generate n-dim gaussian */
  d = 0.0;
  for(i=0;i<n;++i)
    {
      x[i] = gasdev(-HUGE,HUGE);
      d += x[i]*x[i];
    }
  /* normalize and get proper radius distribution */
  d = (realtype)(pow((mlibreal)uniform(0.0,1.0),
                     1.0/(mlibreal)n)/sqrt((mlibreal)d));
  for(i=0;i<n;++i)
    x[i] = x[i]*d;
}


/* check if a point is feasible relative to a set of constraints */
#ifdef __STDC__
int feas(realtype *A[],const realtype b[],int m,int n,const realtype x[])
#else
int feas(A,b,m,n,x)
     realtype *A[],b[],x[];
     int m,n;
#endif
{
  int i;

  for(i=0;i<m;++i)
    if(mydot(A[i],x,n)>b[i])
      return 0;
  return 1;
}
