

  /* this file contains routines adapted from Numerical Recipe in C */
  /* which I do own a copy of */
  /* do not use it unless you have a copy */


static char rcsid[] = "$Header: /home/cvs/cvsroot/c/util/nr.c,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $" ;

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "config.h"
#include "myutil.h"
#include "dist.h"
#include "nr.h"



  /* generates a normal deviate of std dev 1, mean 0 */
  /* from num recipes in C */
  /* uses the unix improved random number generator as its base */
  /* modified to restrict to a subrange l,u uses rejection sampling */
  /* and a bit of code to generate efficiently in the tails- narrow */
  /* regions are the only potential problem */
static int iset=0;
static realtype gset,lastl,lastu;

#ifdef __STDC__
realtype gasdev(realtype l,realtype u)
#else
realtype gasdev(l,u)
     realtype l,u;
#endif
{
  realtype fac,r,v1,v2,m,a,result;

  do {
    if  ((iset == 0)||((l!=lastl)||(u!=lastu))) {
      /* code to generate out in the tails of the normal*/
      lastl = l;
      lastu = u;
      if((u<0)||(l>0))
        {
          m = max(l,-u);
          a = (realtype)exp((mlibreal)(-0.5*sqr(m)));
        }
      else
        a = 1.0;
      do {
        v1=uniform(-a,a);
        v2=uniform(-a,a);
        r=v1*v1+v2*v2;
      } while (r >= a);
      fac=sqrt(-2.0*log(r)/r);
      gset=v1*fac;
      iset=1;
      result = v2*fac;
    } else {
      iset=0;
      result = gset;
    }
    /* flip signs if we are generating a tail */
    if(((u<0)&&(result>0))||((l>0)&&(result<0)))
      result = -result;
  } while((result<l)||(result>u));
  return result;
}


#ifdef __STDC__
void mysrandom(int seed)
#else
void mysrandom(seed)
     int seed;
#endif
{
  /* clear all state out of random number gen */
  iset = 0;
#ifdef USE_SYSTEM_RANDOM
#if sysrand_name == sys_random
  srandom(seed);
#else
#if sysrand_name == sys_drand48
  srand48(seed);
#else
  srand(seed);
#endif
#endif
#else
  if(seed>0)
    seed = -seed;
  else
    {
      if(seed==0)
        seed = -1992;
    }
  /* restart them both- since we don't know which we are using */
  (void)sran1(seed);
  (void)sran3(seed);
  (void)sran4(seed);
#endif
}


#define R 0.61803399
#define C (1.0-R)
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d);

#define maxprobes 100

#ifdef __STDC__
realtype golden(realtype ax,
                realtype bx,
                realtype cx,
                realfunc f,
                realtype tol,
                realtype *xmin)
#else
realtype golden(ax,bx,cx,f,tol,xmin)
     realtype ax,bx,cx,tol,*xmin;
     realfunc f; 
#endif
{
  realtype f0,f1,f2,f3,x0,x1,x2,x3;
  int nprobes;

  x0=ax;
  x3=cx;
  if (fabs(cx-bx) > fabs(bx-ax)) {
    x1=bx;
    x2=bx+C*(cx-bx);
  } else {
    x2=bx;
    x1=bx-C*(bx-ax);
  }
  f1=(*f)(x1);
  f2=(*f)(x2);
  /* added absolute tolerance hack */
  nprobes = 0;
  while ((fabs(x3-x0) > max(tol*(fabs(x1)+fabs(x2)),tol*tol))&&
         (nprobes<maxprobes)) {
    if (f2 < f1) {
      SHFT(x0,x1,x2,R*x1+C*x3)
      SHFT(f0,f1,f2,(*f)(x2))
    } else {
      SHFT(x3,x2,x1,R*x2+C*x0)
      SHFT(f3,f2,f1,(*f)(x1))
      }
    ++nprobes;
  }
  if (f1 < f2) {
    *xmin=x1;
    return f1;
  } else {
    *xmin=x2;
    return f2;
  }
}


#undef SHFT


#define M1 259200
#define IA1 7141
#define IC1 54773
#define RM1 (1.0/M1)
#define M2 134456
#define IA2 8121
#define IC2 28411
#define RM2 (1.0/M2)
#define M3 243000
#define IA3 4561
#define IC3 51349


static long ran1_ix1,ran1_ix2,ran1_ix3;
static realtype ran1_r[98];
   
#ifdef __STDC__
realtype ran1(void)
#else
realtype ran1()
#endif
{
  register realtype temp;
  register int j;

  ran1_ix1=(IA1*ran1_ix1+IC1) % M1;
  ran1_ix2=(IA2*ran1_ix2+IC2) % M2;
  ran1_ix3=(IA3*ran1_ix3+IC3) % M3;
  j=1 + ((97*ran1_ix3)/M3);
  if (j > 97 || j < 1) 
    punt("RAN1: This cannot happen.");
  temp=ran1_r[j];
  ran1_r[j]=(ran1_ix1+ran1_ix2*RM2)*RM1;
  return temp;
}


#ifdef __STDC__
void sran1(int idum)
#else
void sran1(idum)
     int idum;
#endif
{
  int j;

  ran1_ix1=(IC1-(idum)) % M1;
  ran1_ix1=(IA1*ran1_ix1+IC1) % M1;
  ran1_ix2=ran1_ix1 % M2;
  ran1_ix1=(IA1*ran1_ix1+IC1) % M1;
  ran1_ix3=ran1_ix1 % M3;
  for (j=1;j<=97;j++) {
    ran1_ix1=(IA1*ran1_ix1+IC1) % M1;
    ran1_ix2=(IA2*ran1_ix2+IC2) % M2;
    ran1_r[j]=(ran1_ix1+ran1_ix2*RM2)*RM1;
  }
}

#undef M1
#undef IA1
#undef IC1
#undef RM1
#undef M2
#undef IA2
#undef IC2
#undef RM2
#undef M3
#undef IA3
#undef IC3


#define MBIG 1000000000
#define MSEED 161803398
#define MZ 0
#define FAC (1.0/MBIG)


static int ran3_inext,ran3_inextp;
static long ran3_ma[56];

#ifdef __STDC__
realtype ran3(void)
#else
realtype ran3()
#endif
{
  register long mj;
  
  if (++ran3_inext == 56) ran3_inext=1;
  if (++ran3_inextp == 56) ran3_inextp=1;
  mj=ran3_ma[ran3_inext]-ran3_ma[ran3_inextp];
  if (mj < MZ) mj += MBIG;
  ran3_ma[ran3_inext]=mj;
  return mj*FAC;
}

#ifdef __STDC__
void sran3(int idum)
#else
void sran3(idum)
     int idum;
#endif
{
  long mj,mk;
  int i,ii,k;

  mj=MSEED-(idum < 0 ? -idum : idum);
  mj %= MBIG;
  ran3_ma[55]=mj;
  mk=1;
  for (i=1;i<=54;i++) {
    ii=(21*i) % 55;
    ran3_ma[ii]=mk;
    mk=mj-mk;
    if (mk < MZ) mk += MBIG;
    mj=ran3_ma[ii];
  }
  for (k=1;k<=4;k++)
    for (i=1;i<=55;i++) {
      ran3_ma[i] -= ran3_ma[1+(i+30) % 55];
      if (ran3_ma[i] < MZ) ran3_ma[i] += MBIG;
    }
  ran3_inext=0;
  ran3_inextp=31;
}


#undef MBIG
#undef MSEED
#undef MZ
#undef FAC


static unsigned long bit[33];	/* defining declaration */

typedef struct IMMENSE {unsigned long l,r;} immense;
typedef struct GREAT {unsigned short l,c,r;} great;

#ifdef __STDC__
static unsigned long getbit(immense source,int bitno,int nbits)
#else
static unsigned long getbit(source,bitno,nbits)
     immense source;
     int bitno,nbits;
#endif
{
  if (bitno <= nbits)
    return bit[bitno] & source.r ? 1L : 0L;
  else
    return bit[bitno-nbits] & source.l ? 1L : 0L;
}


#ifdef __STDC__
static void ks(immense key,int n,great *kn)
#else
static void ks(key,n,kn)
     immense key;
     great *kn;
     int n;
#endif
{
  static immense icd;
  static const char ipc1[57]={0,57,49,41,33,25,17,9,1,58,50,
                          42,34,26,18,10,2,59,51,43,35,27,19,11,3,60,
                          52,44,36,63,55,47,39,31,23,15,7,62,54,46,38,
                          30,22,14,6,61,53,45,37,29,21,13,5,28,20,12,4};
  static const char ipc2[49]={0,14,17,11,24,1,5,3,28,15,6,21,
                          10,23,19,12,4,26,8,16,7,27,20,13,2,41,52,31,
                          37,47,55,30,40,51,45,33,48,44,49,39,56,34,
                          53,46,42,50,36,29,32};
  int it,i,j,k,l;
  
  if (n == 1) {
    icd.r=icd.l=0L;
    for(j=28,k=56;j>=1;j--,k--) {
      icd.r = (icd.r <<= 1) | getbit(key,ipc1[j],32);
      icd.l = (icd.l <<= 1) | getbit(key,ipc1[k],32);
    }
  }
  if (n == 1 || n == 2 || n == 9 || n == 16) it=1;
  else it=2;
  for(i=1;i<=it;i++) {
    icd.r = (icd.r | ((icd.r & 1L) << 28)) >> 1;
    icd.l = (icd.l | ((icd.l & 1L) << 28)) >> 1;
  }
  (*kn).r=(*kn).c=(*kn).l=0;
  for(j=16,k=32,l=48;j>=1;j--,k--,l--) {
    (*kn).r=((*kn).r <<= 1) | (unsigned short)
      getbit(icd,ipc2[j],28);
    (*kn).c=((*kn).c <<= 1) | (unsigned short)
      getbit(icd,ipc2[k],28);
    (*kn).l=((*kn).l <<= 1) | (unsigned short)
      getbit(icd,ipc2[l],28);
  }
}


#ifdef __STDC__
static void cyfun(unsigned long ir,great k,unsigned long *iout)
#else
static void cyfun(ir,k,iout)
     unsigned long ir,*iout;
     great k;
#endif
{
  static const unsigned char iet[49]={0,32,1,2,3,4,5,4,5,6,7,8,9,8,9,
                         10,11,12,13,12,13,14,15,16,17,16,17,18,19,
                         20,21,20,21,22,23,24,25,24,25,26,27,28,29,
                         28,29,30,31,32,1};
  static const unsigned char ipp[33]={0,16,7,20,21,29,12,28,17,1,15,
                         23,26,5,18,31,10,2,8,24,14,32,27,3,9,19,13,
                         30,6,22,11,4,25};
  static const unsigned char is[16][4][9]={
    0,14,15,10,7,2,12,4,13,0,0,3,13,13,14,10,13,1,
    0,4,0,13,10,4,9,1,7,0,15,13,1,3,11,4,6,2,
    0,4,1,0,13,12,1,11,2,0,15,13,7,8,11,15,0,15,
    0,1,14,6,6,2,14,4,11,0,12,8,10,15,8,3,11,1,
    0,13,8,9,14,4,10,2,8,0,7,4,0,11,2,4,11,13,
    0,14,7,4,9,1,15,11,4,0,8,10,13,0,12,2,13,14,
    0,1,14,14,3,1,15,14,4,0,4,7,9,5,12,2,7,8,
    0,8,11,9,0,11,5,13,1,0,2,1,0,6,7,12,8,7,
    0,2,6,6,0,7,9,15,6,0,14,15,3,6,4,7,4,10,
    0,13,10,8,12,10,2,12,9,0,4,3,6,10,1,9,1,4,
    0,15,11,3,6,10,2,0,15,0,2,2,4,15,7,12,9,3,
    0,6,4,15,11,13,8,3,12,0,9,15,9,1,14,5,4,10,
    0,11,3,15,9,11,6,8,11,0,13,8,6,0,13,9,1,7,
    0,2,13,3,7,7,12,7,14,0,1,4,8,13,2,15,10,8,
    0,8,4,5,10,6,8,13,1,0,1,14,10,3,1,5,10,4,
    0,11,1,0,13,8,3,14,2,0,7,2,7,8,13,10,7,13,
    0,3,9,1,1,8,0,3,10,0,10,12,2,4,5,6,14,12,
    0,15,5,11,15,15,7,10,0,0,5,11,4,9,6,11,9,15,
    0,10,7,13,2,5,13,12,9,0,6,0,8,7,0,1,3,5,
    0,12,8,1,1,9,0,15,6,0,11,6,15,4,15,14,5,12,
    0,6,2,12,8,3,3,9,3,0,12,1,5,2,15,13,5,6,
    0,9,12,2,3,12,4,6,10,0,3,7,14,5,0,1,0,9,
    0,12,13,7,5,15,4,7,14,0,11,10,14,12,10,14,12,11,
    0,7,6,12,14,5,10,8,13,0,14,12,3,11,9,7,15,0,
    0,5,12,11,11,13,14,5,5,0,9,6,12,1,3,0,2,0,
    0,3,9,5,5,6,1,0,15,0,10,0,11,12,10,6,14,3,
    0,9,0,4,12,0,7,10,0,0,5,9,11,10,9,11,15,14,
    0,10,3,10,2,3,13,5,3,0,0,5,5,7,4,0,2,5,
    0,0,5,2,4,14,5,6,12,0,3,11,15,14,8,3,8,9,
    0,5,2,14,8,0,11,9,5,0,6,14,2,2,5,8,3,6,
    0,7,10,8,15,9,11,1,7,0,8,5,1,9,6,8,6,2,
    0,0,15,7,4,14,6,2,8,0,13,9,12,14,3,13,12,11};
  static const char ibin[16]={0,8,4,12,2,10,6,14,1,9,5,13,3,11,7,15};
  great ie;
  unsigned long itmp,ietmp1,ietmp2;
  char unsigned iec[9];
  int jj,irow,icol,iss,j,l,m;
  
  ie.r=ie.c=ie.l=0;
  for(j=16,l=32,m=48;j>=1;j--,l--,m--) {
    ie.r = (ie.r <<= 1) | (bit[iet[j]] & ir ? 1 : 0);
    ie.c = (ie.c <<= 1) | (bit[iet[l]] & ir ? 1 : 0);
    ie.l = (ie.l <<= 1) | (bit[iet[m]] & ir ? 1 : 0);
  }
  ie.r ^= k.r;
  ie.c ^= k.c;
  ie.l ^= k.l;
  ietmp1=((unsigned long) ie.c << 16)+(unsigned long) ie.r;
  ietmp2=((unsigned long) ie.l << 8)+((unsigned long) ie.c >> 8);
  for(j=1,m=5;j<=4;j++,m++) {
    iec[j]=ietmp1 & 0x3fL;
    iec[m]=ietmp2 & 0x3fL;
    ietmp1 >>= 6;
    ietmp2 >>= 6;
  }
  itmp=0L;
  for(jj=8;jj>=1;jj--) {
    j=iec[jj];
    irow=((j & 0x1) << 1)+((j & 0x20) >> 5);
    icol=((j & 0x2) << 2)+(j & 0x4)
      +((j & 0x8) >> 2)+((j & 0x10) >> 4);
    iss=is[icol][irow][jj];
    itmp = (itmp <<= 4) | ibin[iss];
  }
  *iout=0L;
  for(j=32;j>=1;j--)
    *iout = (*iout <<= 1) | (bit[ipp[j]] & itmp ? 1 : 0);
}


#ifdef __STDC__
static void des(immense inp,immense key,int *newkey,int isw,immense *out)
#else
static void des(inp,key,newkey,isw,out)
     immense inp,key,*out;
     int *newkey,isw;
#endif
{
  static unsigned char ip[65]=
    {0,58,50,42,34,26,18,10,2,60,52,44,36,
       28,20,12,4,62,54,46,38,30,22,14,6,64,56,48,40,
       32,24,16,8,57,49,41,33,25,17,9,1,59,51,43,35,
       27,19,11,3,61,53,45,37,29,21,13,5,63,55,47,39,
       31,23,15,7};
  static unsigned char ipm[65]=
    {0,40,8,48,16,56,24,64,32,39,7,47,15,
       55,23,63,31,38,6,46,14,54,22,62,30,37,5,45,13,
       53,21,61,29,36,4,44,12,52,20,60,28,35,3,43,11,
       51,19,59,27,34,2,42,10,50,18,58,26,33,1,41,9,
       49,17,57,25};
  static great kns[17];
  static int initflag=1;
  int ii,i,j,k;
  unsigned long ic,shifter;
  immense itmp;
  
  if (initflag) {
    initflag=0;
    bit[1]=shifter=1L;
    for(j=2;j<=32;j++) bit[j] = (shifter <<= 1);
  }
  if (*newkey) {
    *newkey=0;
    for(i=1;i<=16;i++) ks(key,i,&kns[i]);
  }
  itmp.r=itmp.l=0L;
  for(j=32,k=64;j>=1;j--,k--) {
    itmp.r = (itmp.r <<= 1) | getbit(inp,ip[j],32);
    itmp.l = (itmp.l <<= 1) | getbit(inp,ip[k],32);
  }
  for(i=1;i<=16;i++) {
    ii = (isw == 1 ? 17-i : i);
    cyfun(itmp.l,kns[ii],&ic);
    ic ^= itmp.r;
    itmp.r=itmp.l;
    itmp.l=ic;
  }
  ic=itmp.r;
  itmp.r=itmp.l;
  itmp.l=ic;
  (*out).r=(*out).l=0L;
  for(j=32,k=64;j>=1;j--,k--) {
    (*out).r = ((*out).r <<= 1) | getbit(itmp,ipm[j],32);
    (*out).l = ((*out).l <<= 1) | getbit(itmp,ipm[k],32);
  }
}


#define IM 11979
#define IA 430
#define IC 2531
#define NACC 24
#define IB1 1L
#define IB3 4L
#define IB4 8L
#ifdef __STDC__
#define IB32 (0x80000000UL)
#else
#define IB32 ((unsigned long int)0x80000000L)
#endif
#define MASK (IB1+IB3+IB4)

static int ran4_newkey;
static immense ran4_inp,ran4_key,ran4_jot;
static realtype ran4_pw[66];

#ifdef __STDC__
realtype ran4()
#else
realtype ran4()
#endif
{
  register unsigned long isav;
  register int j;
  register realtype r4;
  
  isav=ran4_inp.r & IB32;
  if (isav) isav=1L;
  if (ran4_inp.l & IB32)
    ran4_inp.r=((ran4_inp.r ^ MASK) << 1) | IB1;
  else
    ran4_inp.r <<= 1;
  ran4_inp.l=(ran4_inp.l << 1) | isav;
  des(ran4_inp,ran4_key,&ran4_newkey,0,&ran4_jot);
  r4=0.0;
  for (j=1;j<=NACC;j++) {
    if (ran4_jot.r & IB1) r4 += ran4_pw[j];
    ran4_jot.r >>= 1;
  }
  return r4;
}

#ifdef __STDC__
void sran4(int idum)
#else
void sran4(idum)
     int idum;
#endif
{
  unsigned long isav,isav2;
  int j;

  idum %= IM;
  if (idum < 0) idum += IM;
  ran4_pw[1]=0.5;
  ran4_key.r=ran4_key.l=ran4_inp.r=ran4_inp.l=0L;
  for (j=1;j<=64;j++) {
    idum = ((long) (idum)*IA+IC) % IM;
    isav=2*(unsigned long)(idum)/IM;
    if (isav) isav=IB32;
    isav2=(4*(unsigned long)(idum)/IM) % 2;
    if (isav2) isav2=IB32;
    if (j <= 32) {
      ran4_key.r=(ran4_key.r >>= 1) | isav;
      ran4_inp.r=(ran4_inp.r >>= 1) | isav2;
    } else {
      ran4_key.l=(ran4_key.l >>= 1) | isav;
      ran4_inp.l=(ran4_inp.l >>= 1) | isav2;
    }
    ran4_pw[j+1]=0.5*ran4_pw[j];
  }
  ran4_newkey=1;
}

#undef IM
#undef IA
#undef IC
#undef NACC
#undef IB1
#undef IB3
#undef IB4
#undef IB32
#undef MASK

#ifndef M_PI
#define M_PI 3.14159265358979323846264338328
#endif

#ifdef __STDC__
mlibreal gammln(mlibreal xx)
#else
mlibreal gammln(xx)
     mlibreal xx;
#endif
{
  mlibreal x,tmp,ser;
  static mlibreal cof[6]={76.18009173,-86.50532033,24.01409822,
                            -1.231739516,0.120858003e-2,-0.536382e-5};
  int j;
  
  if(xx<=1.0)
    {
      if((fabs(xx)<1.0e-10)||(fabs(xx-1.0)<1.0e-10))
        return 0.0;
      /*else */
      return log(M_PI*(1.0-xx)/sin(M_PI*(1.0-xx)))-gammln(2.0-xx);
    }

  x=xx-1.0;
  tmp=x+5.5;
  tmp -= (x+0.5)*log(tmp);
  ser=1.0;
  for (j=0;j<=5;j++) {
    x += 1.0;
    ser += cof[j]/x;
  }
  return -tmp+log(2.50662827465*ser);
}



#define ITMAX 100
#define EPS 3.0e-7

#ifdef __STDC__
static void gser(mlibreal *gamser,mlibreal a,mlibreal x,mlibreal *gln)
#else
static void gser(gamser,a,x,gln)
     mlibreal a,x,*gamser,*gln;
#endif
{
  int n;
  mlibreal sum,del,ap;
  
  *gln=gammln(a);
  if (x <= 0.0) {
    if (x < 0.0) punt("x less than 0 in routine GSER");
    *gamser=0.0;
    return;
  } else {
    ap=a;
    del=sum=1.0/a;
    for (n=1;n<=ITMAX;n++) {
      ap += 1.0;
      del *= x/ap;
      sum += del;
      if (fabs(del) < fabs(sum)*EPS) {
        *gamser=sum*exp(-x+a*log(x)-(*gln));
        return;
      }
    }
    /*    punt("a too large, ITMAX too small in routine GSER");*/
    return;
  }
}

#undef ITMAX
#undef EPS


#define ITMAX 100
#define EPS 3.0e-7

#ifdef __STDC__
static void gcf(mlibreal *gammcf,mlibreal a,mlibreal x,mlibreal *gln)
#else
static void gcf(gammcf,a,x,gln)
     mlibreal a,x,*gammcf,*gln;
#endif
{
  int n;
  mlibreal gold=0.0,g,fac=1.0,b1=1.0;
  mlibreal b0=0.0,anf,ana,an,a1,a0=1.0;
  
  *gln=gammln(a);
  a1=x;
  for (n=1;n<=ITMAX;n++) {
    an=(mlibreal) n;
    ana=an-a;
    a0=(a1+a0*ana)*fac;
    b0=(b1+b0*ana)*fac;
    anf=an*fac;
    a1=x*a0+anf*a1;
    b1=x*b0+anf*b1;
    if (a1) {
      fac=1.0/a1;
      g=b1*fac;
      if (fabs((g-gold)/g) < EPS) {
        *gammcf=exp(-x+a*log(x)-(*gln))*g;
        return;
      }
      gold=g;
    }
  }
  (void)printf("\na=%e x=%e\n",a,x);
  punt("a too large, ITMAX too small in routine GCF");
}

#undef ITMAX
#undef EPS


#ifdef __STDC__
mlibreal gammp(mlibreal a,mlibreal x)
#else
mlibreal gammp(a,x)
     mlibreal a,x;
#endif
{
  mlibreal gamser,gammcf,gln;
  
  if (x < 0.0 || a <= 0.0) punt("Invalid arguments in routine GAMMP");
  if (x < (a+1.0)) {
    gser(&gamser,a,x,&gln);
    return gamser;
  } else {
    gcf(&gammcf,a,x,&gln);
    return 1.0-gammcf;
  }
}

#ifdef __STDC__
mlibreal gammq(mlibreal a,mlibreal x)
#else
mlibreal gammq(a,x)
    mlibreal a,x;
#endif
{
  mlibreal gamser,gammcf,gln;
  
  if (x < 0.0 || a <= 0.0) punt("Invalid arguments in routine GAMMQ");
  if (x < (a+1.0)) {
    gser(&gamser,a,x,&gln);
    return 1.0-gamser;
  } else {
    gcf(&gammcf,a,x,&gln);
    return gammcf;
  }
}

#ifdef USE_OWN_ERF
#ifdef __STDC__
mlibreal erf(mlibreal x)
#else
mlibreal erf(x)
     mlibreal x;
#endif
{
  return x < 0.0 ? -gammp(0.5,x*x) : gammp(0.5,x*x);
}
#endif /*use owne erf*/



#ifdef __STDC__
static void simp1(const realtype * const *a,int mm,const int ll[],
                  int nll,int iabf,int *kp,
		  realtype *bmax)
#else
static void simp1(a,mm,ll,nll,iabf,kp,bmax)
     realtype **a,*bmax;
     int mm,ll[],nll,iabf,*kp;
#endif
{
  int k;
  realtype test;
  
  *kp=ll[1];
  *bmax=a[mm+1][*kp+1];
  for (k=2;k<=nll;k++) {
    if (iabf == 0)
      test=a[mm+1][ll[k]+1]-(*bmax);
    else
      test=fabs(a[mm+1][ll[k]+1])-fabs(*bmax);
    if (test > 0.0) {
      *bmax=a[mm+1][ll[k]+1];
      *kp=ll[k];
    }
  }
}

#define EPS 1.0e-12

#ifdef __STDC__
static void simp2(const realtype * const *a,int n,const int l2[],const int nl2,
                  int *ip,
                  int kp,
		  realtype *q1)
#else
static void simp2(a,n,l2,nl2,ip,kp,q1)
     int n,l2[],nl2,*ip,kp;
     realtype **a,*q1;
#endif
{
  int k,ii,i;
  realtype qp,q0,q;
  
  qp = q0 = 0.0;
  *ip=0;
  for (i=1;i<=nl2;i++) {
    if (a[l2[i]+1][kp+1] < -EPS) {
      *q1 = -a[l2[i]+1][1]/a[l2[i]+1][kp+1];
      *ip=l2[i];
      for (i=i+1;i<=nl2;i++) {
	ii=l2[i];
	if (a[ii+1][kp+1] < -EPS) {
	  q = -a[ii+1][1]/a[ii+1][kp+1];
	  if (q < *q1) {
	    *ip=ii;
	    *q1=q;
	  } else if (q == *q1) {
	    for (k=1;k<=n;k++) {
	      qp = -a[*ip+1][k+1]/a[*ip+1][kp+1];
	      q0 = -a[ii+1][k+1]/a[ii+1][kp+1];
	      if (q0 != qp) break;
	    }
	    if (q0 < qp) *ip=ii;
	  }
	}
      }
    }
  }
}

#undef EPS


#ifdef __STDC__
static void simp3(realtype **a,int i1,int k1,int ip,int kp)
#else
static void simp3(a,i1,k1,ip,kp)
     int i1,k1,ip,kp;
     realtype **a;
#endif
{
  int kk,ii;
  realtype piv;
  
  piv=1.0/a[ip+1][kp+1];
  for (ii=1;ii<=i1+1;ii++)
    if (ii-1 != ip) {
      a[ii][kp+1] *= piv;
      for (kk=1;kk<=k1+1;kk++)
	if (kk-1 != kp)
	  a[ii][kk] -= a[ip+1][kk]*a[ii][kp+1];
    }
  for (kk=1;kk<=k1+1;kk++)
    if (kk-1 != kp) a[ip+1][kk] *= -piv;
  a[ip+1][kp+1]=piv;
}

#define EPS 1.0e-6
#define FREEALL freeint(l3);freeint(l2);\
  freeint(l1);

#ifdef __STDC__
static void simplx(realtype **a,int m,int n,int m1,int m2,int m3,int *icase,
                   int izrov[],int iposv[])
#else
static void simplx(a,m,n,m1,m2,m3,icase,izrov,iposv)
     int m,n,m1,m2,m3,*icase,izrov[],iposv[];
     realtype **a;
#endif
{
  int i,ip,ir,is,k,kh,kp,m12,nl1,nl2;
  int *l1,*l2,*l3;
  realtype q1,bmax;
  
  if (m != (m1+m2+m3)) punt("Bad input constraint counts in SIMPLX");
  l1=allocint(n+3);
  l2=allocint(m+2);
  l3=allocint(m+2);
  nl1=n;
  for (k=1;k<=n;k++) l1[k]=izrov[k]=k;
  nl2=m;
  for (i=1;i<=m;i++) {
    if (a[i+1][1] < 0.0) punt("Bad input tableau in SIMPLX");
    l2[i]=i;
    iposv[i]=n+i;
  }
  for (i=1;i<=m2;i++) l3[i]=1;
  ir=0;
  if (m2+m3) {
    ir=1;
    for (k=1;k<=(n+1);k++) {
      q1=0.0;
      for (i=m1+1;i<=m;i++) q1 += a[i+1][k];
      a[m+2][k] = -q1;
    }
    do {
      simp1((const realtype * const *)a,m+1,(const int *)l1,nl1,0,&kp,&bmax);
      if (bmax <= EPS && a[m+2][1] < -EPS) {
	*icase = -1;
	FREEALL return;
      } else if (bmax <= EPS && a[m+2][1] <= EPS) {
	m12=m1+m2+1;
	if (m12 <= m) {
	  for (ip=m12;ip<=m;ip++) {
	    if (iposv[ip] == (ip+n)) {
	      simp1((const realtype * const *)a,ip,(const int *)l1,
		    nl1,1,&kp,&bmax);
	      if (bmax > 0.0)
		goto one;
	    }
	  }
	}
	ir=0;
	--m12;
	if (m1+1 <= m12)
	  for (i=m1+1;i<=m12;i++)
	    if (l3[i-m1] == 1)
	      for (k=1;k<=n+1;k++)
		a[i+1][k] = -a[i+1][k];
	break;
      }
      simp2((const realtype * const *)a,n,(const int *)l2,nl2,&ip,kp,&q1);
      if (ip == 0) {
	*icase = -1;
	FREEALL return;
      }
    one:		simp3(a,m+1,n,ip,kp);
      if (iposv[ip] >= (n+m1+m2+1)) {
	for (k=1;k<=nl1;k++)
	  if (l1[k] == kp) break;
	--nl1;
	for (is=k;is<=nl1;is++) l1[is]=l1[is+1];
	a[m+2][kp+1] += 1.0;
	for (i=1;i<=m+2;i++) a[i][kp+1] = -a[i][kp+1];
      } else {
	if (iposv[ip] >= (n+m1+1)) {
	  kh=iposv[ip]-m1-n;
	  if (l3[kh]) {
	    l3[kh]=0;
	    a[m+2][kp+1] += 1.0;
	    for (i=1;i<=m+2;i++)
	      a[i][kp+1] = -a[i][kp+1];
	  }
	}
      }
      is=izrov[kp];
      izrov[kp]=iposv[ip];
      iposv[ip]=is;
    } while (ir);
  }
  for (;;) {
    simp1((const realtype * const *)a,0,(const int *)l1,nl1,0,&kp,&bmax);
    if (bmax <= 0.0) {
      *icase=0;
      FREEALL return;
    }
    simp2((const realtype * const *)a,n,(const int *)l2,nl2,&ip,kp,&q1);
    if (ip == 0) {
      *icase=1;
      FREEALL return;
    }
    simp3(a,m,n,ip,kp);
    is=izrov[kp];
    izrov[kp]=iposv[ip];
    iposv[ip]=is;
  }
}

#undef EPS
#undef FREEALL


/* hack to call NR routine easily */
/* return x maximizing c.x subject to Ax <= b */
/* return value is 0 if optimal feasible, -1 if infeasbile, 1 if unbounded */
#ifdef __STDC__
int LP(const realtype * const A[],const realtype b[],const realtype c[],
	      int m,int n,realtype x[])
#else
int LP(A,b,c,m,n,x)
     realtype *A[],b[],c[],x[];
     int m,n;
#endif
{
  realtype **a;
  int m1,m2,m3,*izrov,*iposv,i,j,icase;

  myalloc(a,realtype *,m+5);
  for(i=0;i<m+5;++i)
    a[i] = allocreal(2*n+5);
  izrov = allocint(2*n+5);
  iposv = allocint(m+5);
  a[1][0] = 0.0;
  a[1][1] = 0.0;
  for(j=0;j<n;++j)
    a[1][j+2] = c[j];
  for(j=n;j<2*n;++j)
    a[1][j+2] = -c[j-n];
  m1 = 0;
  for(i=0;i<m;++i)
    if(b[i]>=0)
      {
	++m1;
	a[m1+1][1] = b[i];
	for(j=0;j<n;++j)
	  a[m1+1][j+2] = -A[i][j];
	for(j=n;j<2*n;++j)
	  a[m1+1][j+2] = A[i][j-n];
      }
  m2 = 0;
  for(i=0;i<m;++i)
    if(b[i]<0)
      {
	++m2;
	a[m1+m2+1][1] = -b[i];
	for(j=0;j<n;++j)
	  a[m1+m2+1][j+2] = A[i][j];
	for(j=n;j<2*n;++j)
	  a[m1+m2+1][j+2] = -A[i][j-n];
      }
  m3 = 0;
  simplx(a,m,2*n,m1,m2,m3,&icase,izrov,iposv);
  for(i=0;i<n;++i)
    x[i] = 0.0;
  for(j=1;j<=m;++j)
    if(iposv[j]<=2*n)
      {
	if(iposv[j]<=n)
	  x[iposv[j]-1] += a[j+1][1];
	else
	  x[iposv[j]-1-n] -= a[j+1][1];
      }
  freeint(iposv);
  freeint(izrov);
  for(i=0;i<m+5;++i)
    freereal(a[i]);
  free(a);
  return icase;
}



/* hack to call NR routine easily */
/* return x maximizing c.x subject to Ax <= b, x >=0 */
/* return value is 0 if optimal feasible, -1 if infeasbile, 1 if unbounded */
#ifdef __STDC__
int LPpos(const realtype * const A[],const realtype b[],const realtype c[],
	      int m,int n,realtype x[])
#else
int LPpos(A,b,c,m,n,x)
     realtype *A[],b[],c[],x[];
     int m,n;
#endif
{
  realtype **a;
  int m1,m2,m3,*izrov,*iposv,i,j,icase;

  myalloc(a,realtype *,m+5);
  for(i=0;i<m+5;++i)
    a[i] = allocreal(n+5);
  izrov = allocint(n+5);
  iposv = allocint(m+5);
  a[1][0] = 0.0;
  a[1][1] = 0.0;
  for(j=0;j<n;++j)
    a[1][j+2] = c[j];
  m1 = 0;
  for(i=0;i<m;++i)
    if(b[i]>=0)
      {
	++m1;
	a[m1+1][1] = b[i];
	for(j=0;j<n;++j)
	  a[m1+1][j+2] = -A[i][j];
      }
  m2 = 0;
  for(i=0;i<m;++i)
    if(b[i]<0)
      {
	++m2;
	a[m1+m2+1][1] = -b[i];
	for(j=0;j<n;++j)
	  a[m1+m2+1][j+2] = A[i][j];
      }
  m3 = 0;
  simplx(a,m,n,m1,m2,m3,&icase,izrov,iposv);
  for(i=0;i<n;++i)
    x[i] = 0.0;
  for(j=1;j<=m;++j)
    if(iposv[j]<=n)
      x[iposv[j]-1] += a[j+1][1];
  freeint(iposv);
  freeint(izrov);
  for(i=0;i<m+5;++i)
    freereal(a[i]);
  free(a);
  return icase;
}



/* hack to call NR routine easily */
/* return x maximizing c.x subject to Ax = b, x >=0 */
/* return value is 0 if optimal feasible, -1 if infeasbile, 1 if unbounded */
#ifdef __STDC__
int LPposeq(const realtype * const A[],const realtype b[],const realtype c[],
	      int m,int n,realtype x[])
#else
int LPposeq(A,b,c,m,n,x)
     realtype *A[],b[],c[],x[];
     int m,n;
#endif
{
  realtype **a;
  int m1,m2,m3,*izrov,*iposv,i,j,icase;

  myalloc(a,realtype *,m+5);
  for(i=0;i<m+5;++i)
    a[i] = allocreal(n+5);
  izrov = allocint(n+5);
  iposv = allocint(m+5);
  a[1][0] = 0.0;
  a[1][1] = 0.0;
  for(j=0;j<n;++j)
    a[1][j+2] = c[j];
  m1 = 0;
  m2 = 0;
  m3 = 0;
  for(i=0;i<m;++i)
    if(b[i]>=0.0)
      {
        ++m3;
        a[m1+m2+m3+1][1] = b[i];
        for(j=0;j<n;++j)
          a[m1+m2+m3+1][j+2] = -A[i][j];
      }      
    else
      {
        ++m3;
        a[m1+m2+m3+1][1] = -b[i];
        for(j=0;j<n;++j)
          a[m1+m2+m3+1][j+2] = A[i][j];
      }      
  simplx(a,m,n,m1,m2,m3,&icase,izrov,iposv);
  for(i=0;i<n;++i)
    x[i] = 0.0;
  for(j=1;j<=m;++j)
    if(iposv[j]<=n)
      x[iposv[j]-1] += a[j+1][1];
  freeint(iposv);
  freeint(izrov);
  for(i=0;i<m+5;++i)
    freereal(a[i]);
  free(a);
  return icase;
}



/* modified to address arrays properly */
static realtype at,bt,ct;
#define PYTHAG(a,b) ((at=fabs(a)) > (bt=fabs(b)) ? \
     (ct=bt/at,at*sqrt(1.0+ct*ct)) : (bt ? (ct=at/bt,bt*sqrt(1.0+ct*ct)): 0.0))

static realtype maxarg1,maxarg2;
#define MAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ?\
		  (maxarg1) : (maxarg2))
#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))

#ifdef __STDC__
void svdcmp(realtype *a[],int m,int n,realtype w[],realtype *v[])
#else
void svdcmp(a,m,n,w,v)
     realtype *a[],w[],*v[];
     int m,n;
#endif
{
  int flag,i,its,j,jj,k,l,nm;
  realtype c,f,h,s,x,y,z;
  realtype anorm=0.0,g=0.0,scale=0.0;
  realtype *rv1;
  
  l = nm = 0;
  if (m < n) punt("SVDCMP: You must augment A with extra zero rows");
  rv1=allocreal(n+1);
  for (i=1;i<=n;i++) {
    l=i+1;
    rv1[i-1]=scale*g;
    g=s=scale=0.0;
    if (i <= m) {
      for (k=i;k<=m;k++) scale += fabs(a[k-1][i-1]);
      if (scale) {
	for (k=i;k<=m;k++) {
	  a[k-1][i-1] /= scale;
	  s += a[k-1][i-1]*a[k-1][i-1];
	}
	f=a[i-1][i-1];
	g = -SIGN(sqrt(s),f);
	h=f*g-s;
	a[i-1][i-1]=f-g;
	if (i != n) {
	  for (j=l;j<=n;j++) {
	    for (s=0.0,k=i;k<=m;k++) s += a[k-1][i-1]*a[k-1][j-1];
	    f=s/h;
	    for (k=i;k<=m;k++) a[k-1][j-1] += f*a[k-1][i-1];
	  }
	}
	for (k=i;k<=m;k++) a[k-1][i-1] *= scale;
      }
    }
    w[i-1]=scale*g;
    g=s=scale=0.0;
    if (i <= m && i != n) {
      for (k=l;k<=n;k++) scale += fabs(a[i-1][k-1]);
      if (scale) {
	for (k=l;k<=n;k++) {
	  a[i-1][k-1] /= scale;
	  s += a[i-1][k-1]*a[i-1][k-1];
	}
	f=a[i-1][l-1];
	g = -SIGN(sqrt(s),f);
	h=f*g-s;
	a[i-1][l-1]=f-g;
	for (k=l;k<=n;k++) rv1[k-1]=a[i-1][k-1]/h;
	if (i != m) {
	  for (j=l;j<=m;j++) {
	    for (s=0.0,k=l;k<=n;k++) s += a[j-1][k-1]*a[i-1][k-1];
	    for (k=l;k<=n;k++) a[j-1][k-1] += s*rv1[k-1];
	  }
	}
	for (k=l;k<=n;k++) a[i-1][k-1] *= scale;
      }
    }
    anorm=MAX(anorm,(fabs(w[i-1])+fabs(rv1[i-1])));
  }
  for (i=n;i>=1;i--) {
    if (i < n) {
      if (g) {
	for (j=l;j<=n;j++)
	  v[j-1][i-1]=(a[i-1][j-1]/a[i-1][l-1])/g;
	for (j=l;j<=n;j++) {
	  for (s=0.0,k=l;k<=n;k++) s += a[i-1][k-1]*v[k-1][j-1];
	  for (k=l;k<=n;k++) v[k-1][j-1] += s*v[k-1][i-1];
	}
      }
      for (j=l;j<=n;j++) v[i-1][j-1]=v[j-1][i-1]=0.0;
    }
    v[i-1][i-1]=1.0;
    g=rv1[i-1];
    l=i;
  }
  for (i=n;i>=1;i--) {
    l=i+1;
    g=w[i-1];
    if (i < n)
      for (j=l;j<=n;j++) a[i-1][j-1]=0.0;
    if (g) {
      g=1.0/g;
      if (i != n) {
	for (j=l;j<=n;j++) {
	  for (s=0.0,k=l;k<=m;k++) s += a[k-1][i-1]*a[k-1][j-1];
	  f=(s/a[i-1][i-1])*g;
	  for (k=i;k<=m;k++) a[k-1][j-1] += f*a[k-1][i-1];
	}
      }
      for (j=i;j<=m;j++) a[j-1][i-1] *= g;
    } else {
      for (j=i;j<=m;j++) a[j-1][i-1]=0.0;
    }
    ++a[i-1][i-1];
  }
  for (k=n;k>=1;k--) {
    for (its=1;its<=30;its++) {
      flag=1;
      for (l=k;l>=1;l--) {
	nm=l-1;
	if (fabs(rv1[l-1])+anorm == anorm) {
	  flag=0;
	  break;
	}
	if (fabs(w[nm-1])+anorm == anorm) break;
      }
      if (flag) {
	c=0.0;
	s=1.0;
	for (i=l;i<=k;i++) {
	  f=s*rv1[i-1];
	  if (fabs(f)+anorm != anorm) {
	    g=w[i-1];
	    h=PYTHAG(f,g);
	    w[i-1]=h;
	    h=1.0/h;
	    c=g*h;
	    s=(-f*h);
	    for (j=1;j<=m;j++) {
	      y=a[j-1][nm-1];
	      z=a[j-1][i-1];
	      a[j-1][nm-1]=y*c+z*s;
	      a[j-1][i-1]=z*c-y*s;
	    }
	  }
	}
      }
      z=w[k-1];
      if (l == k) {
	if (z < 0.0) {
	  w[k-1] = -z;
	  for (j=1;j<=n;j++) v[j-1][k-1]=(-v[j-1][k-1]);
	}
	break;
      }
      if (its == 30) punt("No convergence in 30 SVDCMP iterations");
      x=w[l-1];
      nm=k-1;
      y=w[nm-1];
      g=rv1[nm-1];
      h=rv1[k-1];
      f=((y-z)*(y+z)+(g-h)*(g+h))/(2.0*h*y);
      g=PYTHAG(f,1.0);
      f=((x-z)*(x+z)+h*((y/(f+SIGN(g,f)))-h))/x;
      c=s=1.0;
      for (j=l;j<=nm;j++) {
	i=j+1;
	g=rv1[i-1];
	y=w[i-1];
	h=s*g;
	g=c*g;
	z=PYTHAG(f,h);
	rv1[j-1]=z;
	c=f/z;
	s=h/z;
	f=x*c+g*s;
	g=g*c-x*s;
	h=y*s;
	y=y*c;
	for (jj=1;jj<=n;jj++) {
	  x=v[jj-1][j-1];
	  z=v[jj-1][i-1];
	  v[jj-1][j-1]=x*c+z*s;
	  v[jj-1][i-1]=z*c-x*s;
	}
	z=PYTHAG(f,h);
	w[j-1]=z;
	if (z) {
	  z=1.0/z;
	  c=f*z;
	  s=h*z;
	}
	f=(c*g)+(s*y);
	x=(c*y)-(s*g);
	for (jj=1;jj<=m;jj++) {
	  y=a[jj-1][j-1];
	  z=a[jj-1][i-1];
	  a[jj-1][j-1]=y*c+z*s;
	  a[jj-1][i-1]=z*c-y*s;
	}
      }
      rv1[l-1]=0.0;
      rv1[k-1]=f;
      w[k-1]=x;
    }
  }
  freereal(rv1);
}

#undef SIGN
#undef MAX
#undef PYTHAG


#define MAXIT 100

#ifdef __STDC__ 
realtype rtsafe(void (*funcd)(realtype,realtype *,realtype *),
                realtype x1,realtype x2,realtype xacc)
#else
realtype rtsafe(funcd,x1,x2,xacc)
     realtype x1,x2,xacc;
     void (*funcd)(); /*ANSI: void (*funcd)(realtype,realtype *,realtype *);*/
#endif
{
  int j;
  realtype df,dx,dxold,f,fh,fl;
  realtype swap,temp,xh,xl,rts;
  
  (*funcd)(x1,&fl,&df);
  (*funcd)(x2,&fh,&df);
  if (fl*fh >= 0.0) punt("Root must be bracketed in RTSAFE");
  if (fl < 0.0) {
    xl=x1;
    xh=x2;
  } else {
    xh=x1;
    xl=x2;
    swap=fl;
    fl=fh;
    fh=swap;
  }
  rts=0.5*(x1+x2);
  dxold=fabs(x2-x1);
  dx=dxold;
  (*funcd)(rts,&f,&df);
  for (j=1;j<=MAXIT;j++) {
    if ((((rts-xh)*df-f)*((rts-xl)*df-f) >= 0.0)
        || (fabs(2.0*f) > fabs(dxold*df))) {
      dxold=dx;
      dx=0.5*(xh-xl);
      rts=xl+dx;
      if (xl == rts) return rts;
    } else {
      dxold=dx;
      dx=f/df;
      temp=rts;
      rts -= dx;
      if (temp == rts) return rts;
    }
    if (fabs(dx) < xacc) return rts;
    (*funcd)(rts,&f,&df);
    if (f < 0.0) {
      xl=rts;
      fl=f;
    } else {
      xh=rts;
      fh=f;
    }
  }
  punt("Maximum number of iterations exceeded in RTSAFE");
  return 0.0;
}

#undef MAXIT


    
#define TINY 1.0e-14


/* set *d to zero if singular */
#ifdef __STDC__
void ludcmp(realtype **a,int n,int *indx,realtype *d)
#else
void ludcmp(a,n,indx,d)
     int n,*indx;
     realtype **a,*d;
#endif
{
  int i,imax,j,k;
  realtype big,dum,sum,temp;
  realtype *vv;
    
  imax = 0;
  vv=allocreal(n);
  *d=1.0;
  for (i=0;i<n;i++) {
    big=0.0;
    for (j=0;j<n;j++)
      if ((temp=fabs(a[i][j])) > big) big=temp;
    if (fabs(big)<=TINY)
      {
        *d = 0.0;
        goto ludcmp_exit;
      }
    vv[i]=1.0/big;
  }
  for (j=0;j<n;j++) {
    for (i=0;i<j;i++) {
      sum=a[i][j];
      for (k=0;k<i;k++) sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
    }
    big=0.0;
    for (i=j;i<n;i++) {
      sum=a[i][j];
      for (k=0;k<j;k++)
        sum -= a[i][k]*a[k][j];
      a[i][j]=sum;
      if ( (dum=vv[i]*fabs(sum)) >= big) {
        big=dum;
        imax=i;
      }
    }
    if (j != imax) {
      for (k=0;k<n;k++) {
        dum=a[imax][k];
        a[imax][k]=a[j][k];
        a[j][k]=dum;
      }
      *d = -(*d);
      vv[imax]=vv[j];
    }
    indx[j]=imax;
    if (fabs(a[j][j])<=TINY) 
      {
        *d = 0.0;
        goto ludcmp_exit;
      }
    if (j != n) {
      dum=1.0/(a[j][j]);
      for (i=j+1;i<n;i++) a[i][j] *= dum;
    }
  }
 ludcmp_exit:
  freereal(vv);
}

#undef TINY


#ifdef __STDC__
void lubksb(realtype **a,int n,int *indx,realtype b[])
#else
void lubksb(a,n,indx,b)
     realtype **a,b[];
     int n,*indx;
#endif
{
  int i,ii= -1,ip,j;
  realtype sum;
    
  for (i=0;i<n;i++) {
    ip=indx[i];
    sum=b[ip];
    b[ip]=b[i];
    if (ii>=0)
      for (j=ii;j<=i-1;j++) sum -= a[i][j]*b[j];
    else if (sum) ii=i;
    b[i]=sum;
  }
  for (i=n-1;i>=0;i--) {
    sum=b[i];
    for (j=i+1;j<n;j++) sum -= a[i][j]*b[j];
    b[i]=sum/a[i][i];
  }
}


/* next 5 routines mnbrak,brent,linmin,powell,dfpmin still index from 1 */
/* also share static structures- so not mutually callable */


#define GOLD 1.618034
#define GLIMIT 100.0
#define TINY 1.0e-20
#define MAX(a,b) ((a) > (b) ? (a) : (b))
#define SIGN(a,b) ((b) > 0.0 ? fabs(a) : -fabs(a))
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d)

#ifdef __STDC__
void mnbrak(double *ax, double *bx, double *cx, double *fa, double *fb,
            double *fc, double (*func)(double))
#else    
void mnbrak(ax,bx,cx,fa,fb,fc,func)
  double *ax,*bx,*cx,*fa,*fb,*fc;
  double (*func)();	/* ANSI: double (*func)(double); */
#endif
{
  double ulim,u,r,q,fu,dum;
    
  *fa=(*func)(*ax);
  *fb=(*func)(*bx);
  if (*fb > *fa) {
    SHFT(dum,*ax,*bx,dum);
    SHFT(dum,*fb,*fa,dum);
  }
  *cx=(*bx)+GOLD*(*bx-*ax);
  *fc=(*func)(*cx);
  while (*fb > *fc) {
    double denom;

    r=(*bx-*ax)*(*fb-*fc);
    q=(*bx-*cx)*(*fb-*fa);
    denom = (2.0*SIGN(MAX(fabs(q-r),TINY),q-r));
    if(fabs(denom)<TINY)
      punt("TINY denom in mnbrak");
    u=(*bx)-((*bx-*cx)*q-(*bx-*ax)*r)/denom;
    ulim=(*bx)+GLIMIT*(*cx-*bx);
    if ((*bx-u)*(u-*cx) > 0.0) {
      fu=(*func)(u);
      if (fu < *fc) {
        *ax=(*bx);
        *bx=u;
        *fa=(*fb);
        *fb=fu;
        return;
      } else if (fu > *fb) {
        *cx=u;
        *fc=fu;
        return;
      }
      u=(*cx)+GOLD*(*cx-*bx);
      fu=(*func)(u);
    } else if ((*cx-u)*(u-ulim) > 0.0) {
      fu=(*func)(u);
      if (fu < *fc) {
        SHFT(*bx,*cx,u,*cx+GOLD*(*cx-*bx));
        SHFT(*fb,*fc,fu,(*func)(u));
      }
    } else if ((u-ulim)*(ulim-*cx) >= 0.0) {
      u=ulim;
      fu=(*func)(u);
    } else {
      u=(*cx)+GOLD*(*cx-*bx);
      fu=(*func)(u);
    }
    SHFT(*ax,*bx,*cx,u);
    SHFT(*fa,*fb,*fc,fu);
  }
}
    
#undef GOLD
#undef GLIMIT
#undef TINY
#undef MAX
#undef SIGN
#undef SHFT


#define ITMAX 100
#define CGOLD 0.3819660
#define ZEPS 1.0e-10
#define SIGN(a,b) ((b) > 0.0 ? fabs(a) : -fabs(a))
#define SHFT(a,b,c,d) (a)=(b);(b)=(c);(c)=(d)
    
#ifdef __STDC__
double brent(double ax, double bx, double cx, double (*f)(double),
             double tol, double *xmin)
#else
double brent(ax,bx,cx,f,tol,xmin)
  double ax,bx,cx,tol,*xmin;
  double (*f)();	/* ANSI: double (*f)(double); */
#endif
{
  int iter;
  double a,b,d=0.0,etemp,fu,fv,fw,fx,p,q,r,tol1,tol2,u,v,w,x,xm;
  double e=0.0;
    
  a=((ax < cx) ? ax : cx);
  b=((ax > cx) ? ax : cx);
  x=w=v=bx;
  fw=fv=fx=(*f)(x);
  for (iter=1;iter<=ITMAX;iter++) {
    xm=0.5*(a+b);
    tol2=2.0*(tol1=tol*fabs(x)+ZEPS);
    if (fabs(x-xm) <= (tol2-0.5*(b-a))) {
      goto brent_exit;
    }
    if (fabs(e) > tol1) {
      r=(x-w)*(fx-fv);
      q=(x-v)*(fx-fw);
      p=(x-v)*q-(x-w)*r;
      q=2.0*(q-r);
      if (q > 0.0) p = -p;
      q=fabs(q);
      etemp=e;
      e=d;
      if (fabs(p) >= fabs(0.5*q*etemp) || p <= q*(a-x) || p >= q*(b-x))
        d=CGOLD*(e=(x >= xm ? a-x : b-x));
      else {
        if(fabs(q)<1.0e-14)
          goto brent_exit;
        d=p/q;
        u=x+d;
        if (u-a < tol2 || b-u < tol2)
          d=SIGN(tol1,xm-x);
      }
    } else {
      d=CGOLD*(e=(x >= xm ? a-x : b-x));
    }
    u=(fabs(d) >= tol1 ? x+d : x+SIGN(tol1,d));
    fu=(*f)(u);
    if (fu <= fx) {
      if (u >= x) a=x; else b=x;
      SHFT(v,w,x,u);
      SHFT(fv,fw,fx,fu);
    } else {
      if (u < x) a=u; else b=u;
      if (fu <= fw || w == x) {
        v=w;
        w=u;
        fv=fw;
        fw=fu;
      } else if (fu <= fv || v == x || v == w) {
        v=u;
        fv=fu;
      }
    }
  }
  (void)fprintf(stderr,"Too many iterations in BRENT\n");
brent_exit:
  *xmin=x;
  return fx;
}
    
#undef ITMAX
#undef CGOLD
#undef ZEPS
#undef SIGN
#undef SHFT



static int ncom=0;
static int nalloc=0;
static double *pcom=NULL,*xicom=NULL;
#ifdef __STDC__
static double (*nrfunc)(const double*);
#else
static double (*nrfunc)();
#endif


#ifdef __STDC__
static double f1dim(double x)
#else
static double f1dim(x)
  double x;
#endif
{
  int j;
  double f;
  static double *xt = NULL;
  static int nxt = 0;

  if((xt==NULL)||(ncom>nxt))
    {
      if(xt!=NULL)
        freereal(xt);
      xt = allocreal(ncom+1);
      nxt = ncom;
    }
  for (j=1;j<=ncom;j++) xt[j]=pcom[j]+x*xicom[j];
  f=(*nrfunc)(xt);
  return f;
}




#define TOL 1.0e-12

#ifdef __STDC__    
void linmin(double p[], double xi[], int n, double *fret, 
            double (*func)(const double*))
#else
void linmin(p,xi,n,fret,func)
  double p[],xi[],*fret,(*func)();
  int n;
#endif
{
  int j;
  double xx,xmin,fx,fb,fa,bx,ax;
    
  if((n>nalloc)||(pcom==NULL))
    {
      if(pcom!=NULL)
        {
          freereal(pcom);
          freereal(xicom);
        }
      nalloc = n;
      pcom=allocreal(n+1);
      xicom=allocreal(n+1);
    }
  ncom=n;
  nrfunc=func;
  for (j=1;j<=n;j++) {
    pcom[j]=p[j];
    xicom[j]=xi[j];
  }
  ax=0.0;
  xx=1.0;
  bx=2.0;
  mnbrak(&ax,&xx,&bx,&fa,&fx,&fb,f1dim);
  *fret=brent(ax,xx,bx,f1dim,TOL,&xmin);
  for (j=1;j<=n;j++) {
    xi[j] *= xmin;
    p[j] += xi[j];
  }
}
    
#undef TOL




#define ITMAX 200
#define SQR(a) ((a)*(a))
    
#ifdef __STDC__
void powell(double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*))
#else
void powell(p,n,ftol,iter,fret,func)
  double p[],ftol,*fret,(*func)();
  int n,*iter;
#endif
{
  int i,ibig,j;
  double t,fptt,fp,del;
  double *pt,*ptt,*xit;
  double **xi;
    
  xi = allocmat(n+1,n+1);
  for(i=0;i<n+1;++i)
    for(j=1;j<n+1;++j)
      xi[i][j] = 0.0;
  for(i=0;i<n+1;++i)
    xi[i][i] = 1.0;

  pt=allocreal(n+1);
  ptt=allocreal(n+1);
  xit=allocreal(n+1);
  *fret=(*func)(p);
  for (j=1;j<=n;j++) pt[j]=p[j];
  for (*iter=1;;(*iter)++) {
    fp=(*fret);
    ibig=0;
    del=0.0;
    for (i=1;i<=n;i++) {
      for (j=1;j<=n;j++) xit[j]=xi[j][i];
      fptt=(*fret);
      linmin(p,xit,n,fret,func);
      if (fabs(fptt-(*fret)) > del) {
        del=fabs(fptt-(*fret));
        ibig=i;
      }
    }
    if ((2.0*fabs(fp-(*fret)) <= ftol*(fabs(fp)+fabs(*fret)))||
        (*iter >= ITMAX)){
      freemat(xi,n+1);
      freereal(xit);
      freereal(ptt);
      freereal(pt);
      if(*iter >= ITMAX)
        fprintf(stderr,"Too many iterations in routine POWELL\n");
      return;
    }
    for (j=1;j<=n;j++) {
      ptt[j]=2.0*p[j]-pt[j];
      xit[j]=p[j]-pt[j];
      pt[j]=p[j];
    }
    fptt=(*func)(ptt);
    if (fptt < fp) {
      t=2.0*(fp-2.0*(*fret)+fptt)*SQR(fp-(*fret)-del)-del*SQR(fp-fptt);
      if (t < 0.0) {
        linmin(p,xit,n,fret,func);
        for (j=1;j<=n;j++) xi[j][ibig]=xit[j];
      }
    }
  }
}
    
#undef ITMAX
#undef SQR


    
#define ITMAX 200
#define EPS 1.0e-10
    
#ifdef __STDC__
void nr_dfpmin(double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*), 
            void (*dfunc)(const double*,double*))
#else
void nr_dfpmin(p,n,ftol,iter,fret,func,dfunc)
  double p[],ftol,*fret,(*func)();
  void (*dfunc)();
  int n,*iter;
#endif
{
  int j,i,its;
  double fp,fae,fad,fac;
  double *xi,*g,*dg,*hdg;
  double **hessin;
    
  hessin=allocmat(n+1,n+1);
  xi=allocreal(n+1);
  g=allocreal(n+1);
  dg=allocreal(n+1);
  hdg=allocreal(n+1);
  fp=(*func)(p);
  (*dfunc)(p,g);
  for (i=1;i<=n;i++) {
    for (j=1;j<=n;j++) hessin[i][j]=0.0;
    hessin[i][i]=1.0;
    xi[i] = -g[i];
  }
  for (its=1;its<=ITMAX;its++) {
    *iter=its;
    linmin(p,xi,n,fret,func);
    if (2.0*fabs(*fret-fp) <= ftol*(fabs(*fret)+fabs(fp)+EPS))
      goto do_return;
    fp=(*fret);
    for (i=1;i<=n;i++) dg[i]=g[i];
    *fret=(*func)(p);
    (*dfunc)(p,g);
    for (i=1;i<=n;i++) dg[i]=g[i]-dg[i];
    for (i=1;i<=n;i++) {
      hdg[i]=0.0;
      for (j=1;j<=n;j++) hdg[i] += hessin[i][j]*dg[j];
    }
    fac=fae=0.0;
    for (i=1;i<=n;i++) {
      fac += dg[i]*xi[i];
      fae += dg[i]*hdg[i];
    }
    if((fabs(fac)<=1.0e-12)||(fabs(fae)<=1.0e-12))
      {
        *iter = -1;  /* bad accident sentinal */
        goto do_return;  /* this happens */
      }
    fac=1.0/fac;
    fad=1.0/fae;
    for (i=1;i<=n;i++) dg[i]=fac*xi[i]-fad*hdg[i];
    for (i=1;i<=n;i++)
      for (j=1;j<=n;j++)
        hessin[i][j] += fac*xi[i]*xi[j]
          -fad*hdg[i]*hdg[j]+fae*dg[i]*dg[j];
    for (i=1;i<=n;i++) {
      xi[i]=0.0;
      for (j=1;j<=n;j++) xi[i] -= hessin[i][j]*g[j];
    }
  }
  (void)fprintf(stderr,"Too many iterations in DFPMIN");
do_return:
  freereal(hdg);
  freereal(dg);
  freereal(g);
  freereal(xi);
  freemat(hessin,n+1);
}
    
#undef ITMAX
#undef EPS




static int nograd_n;
#ifdef __STDC__
static double (*nograd_func)(const double*);
#else
static double (*nograd_func)();
#endif

/* they numeric hack I said I would never do */
static void nograd_grad(const double *parms, double *grad)
{
  static double *pb = NULL;
  static int nalloc = 0;
  int want;
  int i;
  double dt,si;

  want = nograd_n+1;
  if((pb==NULL)||(nalloc<want))
    {
      if(pb!=NULL)
        free(pb);
      nalloc = want;
      if((pb=malloc(sizeof(double)*want))==NULL)
        punt("malloc");
    }
  si = nograd_func(parms);
  dt = 0.01;
  for(i=1;i<nograd_n+1;++i)
    pb[i] = parms[i];
#if 0
restart_point:
#endif
  for(i=1;i<nograd_n+1;++i)
    {
      double dx;
      
      pb[i] = parms[i] + dt;
      dx = nograd_func(pb)-si;
      pb[i] = parms[i];

#if 0
      if(fabs(dx)>100.0)
        {
          dt /= 2;
          goto restart_point;
        }
#endif
      if(fabs(dx)<=1.0e-7)
        grad[i] = 0.0;
      else
        grad[i] = dx/dt;
    }
}


#ifdef __STDC__
void nograd_dfpmin(double p[], int n, double ftol, int *iter, double *fret,
            double (*func)(const double*))
#else
void nograd_dfpmin(p,n,ftol,iter,fret,func,dfunc)
  double p[],ftol,*fret,(*func)();
  int n,*iter;
#endif
{
  static int nalloc=0;
  static double *op = NULL;
  int want,i;

  want = n+1;
  if((op==NULL)||(want>nalloc))
    {
      if(op!=NULL)
        freereal(op);
      nalloc = want;
      op = allocreal(want);
    }
  nograd_n = n;
  nograd_func = func;
  for(i=1;i<n+1;++i)
    op[i] = p[i];
  nr_dfpmin(p,n,ftol,iter,fret,func,nograd_grad);
  if(*iter<=1) /* error try to clean up */
    {
#if 0
      (void)printf("problem\n");
      (void)fflush(stdout);
#endif
      for(i=1;i<n+1;++i)
        p[i] = op[i];
      powell(p,n,10.0*ftol,iter,fret,func);
#if 0
      (void)printf("recovered\n");
      (void)fflush(stdout);
#endif
    }
}

void inv(double **a, int am, double **b)
{
  int i,j;
  double **t,*c,d;
  int *indx;

  t = allocmat(am,am);
  indx = allocint(am+1);
  c = allocreal(am);
  for(i=0;i<am;++i) {
    for(j=0;j<am;++j) {
      t[i][j] = a[i][j];
    }
  }
  ludcmp(t,am,indx,&d);
  for(j=0;j<am;++j) {
    for(i=0;i<am;++i) {
      c[i] = 0.0;
    }
    c[j] = 1.0;
    lubksb(t,am,indx,c);
    for(i=0;i<am;++i) {
      b[i][j] = c[i];
    }
  }
  freereal(c);
  freeint(indx);
  freemat(t,am);
}
