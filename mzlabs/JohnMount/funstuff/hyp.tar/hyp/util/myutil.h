
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

/* RCS  $Header: /home/cvs/cvsroot/c/util/myutil.h,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $  */

#ifndef util_included
#define util_included

typedef struct {
  int n;
  realtype sumx,sumx2,mean,stddev,high,low;
  } stat_type;


extern int saw_newline;

#define punt(mesg) dopunt(mesg, __LINE__, __FILE__)
#define CPOINT (void)printf("\nCheckPoint at \"%s\":%d\n",__FILE__,__LINE__)
#define myalloc(ptr,type,num) do { if(((ptr)=(type*)malloc((unsigned)(sizeof(type)*(num))))==NULL) punt("malloc"); } while(0)
#define mycalloc(ptr,type,num) do { if(((ptr)=(type*)calloc((unsigned)(num),(unsigned)(sizeof(type))))==NULL) punt("malloc"); } while(0)
#define myrealloc(ptr,type,num) do { if(((ptr)=(type*)realloc((char *)(ptr),(unsigned)(sizeof(type)*(num))))==NULL) punt("realloc"); } while(0)
#define myfopen(ptr,name,op) do { if(((ptr)=fopen(name,op))==NULL) { (void)fprintf(stderr,"\nfopen: \"%s\" mode \"%s\" failed.",name,op); punt("fopen"); } } while(0)

#ifdef __STDC__
extern char *mydate(void);
extern long now(void);
extern void start_up(int quiet);
extern void dopunt(const char s[],int line,const char file[]);
extern void pvec(FILE *f,
          const realtype x[],
          int d);
extern void eatline(FILE *f);
extern int nchar(FILE *f);
extern int getint(FILE *f);
extern int getreal(FILE *f,realtype *r);
extern void rvec(FILE *f,
          realtype **x,
          int *n);
extern void pmat(FILE *f,
          const realtype * const A[],
          int m,
          int n);
extern void rmat(FILE *f,
          realtype ***A,
          int *m,
          int *n);
extern realtype mydot(const realtype a[],
             const realtype b[],
             int n);
extern realtype mdot(const realtype a[],
	     const realtype * const A[],
             const realtype b[],
             int n);
extern realtype *allocreal(int n);
extern void freereal(realtype *p);
extern realtype **allocmat(int m, int n);
extern void freemat(realtype **A,int m);
extern int *allocint(int n);
extern void freeint(int *p);
extern realtype max(realtype a,realtype b);
extern realtype min(realtype a,realtype b);
extern void finish_up(int quiet);
extern void reset_stat(stat_type *a);
extern void collect_stat(stat_type *a,realtype p);
extern void calc_stat(stat_type *a);
extern mlibreal my_rint(mlibreal x);
extern int isnan(mlibreal x);
extern mlibreal log1p(mlibreal x);
#else
extern long now();
extern char *mydate();
extern void pvec(/*f,x,d*/);
extern void pmat(/*f,A,m,n*/);
extern realtype mydot(/*a,b,n*/);
extern realtype mdot(/*a,A,b,n*/);
extern void dopunt(/*s,line,file*/);
extern realtype *allocreal(/*n*/);
extern void freereal(/*p*/);
extern int *allocint(/*n*/);
extern void freeint(/*p*/);
extern realtype **allocmat(/*m,n*/);
extern void freemat(/* A,m */);
extern void rvec(/* *f, **x, *n */);
extern void rmat(/* *f, ***A, *m,*n */);
extern int getint(/* *f*/);
extern int getreal(/* *f,*r*/);
extern void eatline(/* *f*/);
extern int nchar(/* *f*/);
extern realtype max(/*a,b*/);
extern realtype min(/*a,b*/);
extern void start_up(/*quiet*/);
extern void finish_up(/*quiet*/);
extern void reset_stat(/*stat_type *a*/);
extern void collect_stat(/*stat_type *a,realtype p*/);
extern void calc_stat(/*stat_type *a*/);
extern mlibreal my_rint(/*x*/);
extern int isnan(/*x*/);
extern mlibreal log1p(/*x*/);
#endif

#endif


