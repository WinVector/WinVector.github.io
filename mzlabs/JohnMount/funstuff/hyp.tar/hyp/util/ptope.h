
/*
    <util, utility routines>
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/
/* RCS  $Header: /home/cvs/cvsroot/c/util/ptope.h,v 1.1.1.1 2004/02/21 20:34:57 jmount Exp $  */

#ifndef ptope_included
#define ptope_included

#ifdef __STDC__
extern void lowerjohn(realtype *A[],const realtype a[],
	       const realtype c[], realtype Gamma,int n,
	       realtype *Ap[], realtype ap[]);
extern void bigellipse(realtype *A[],const realtype b[],
               int m,int n,
	       realtype *Ap[], realtype ap[]);
extern void greedyround(realtype *A[],const realtype b[],
               int m,int n,
	       realtype *F[], realtype p[]);
extern void uball(int n, realtype x[]);
extern int feas(realtype *A[],const realtype b[],int m,int n,
		const realtype x[]);
extern int choleski(realtype *L[], int n);
extern void bigsimplex(realtype *A[], const realtype b[], int m, int n,
             realtype *v[]);
extern int orthelim(realtype *v[],int m, int n,realtype nv[]);
void newdir(realtype *v[],int m,int n,realtype nv[],int ignore);
extern void l1round(realtype *A[],const realtype b[], int m, int n,
             realtype *F[], realtype p[],realtype *FI[]);
#else
extern void lowerjohn(/*A,a,c,Gamma,n,Ap,ap*/);
extern void bigellipse(/*A,b,m,n,Ap,ap*/);
extern void greedyround(/*A,b,m,n,F,p*/);
extern void uball(/*n,x*/);
extern int feas(/*A,b,m,n,x*/);
extern int choleski(/*L,n*/);
extern void bigsimplex(/*A,b,m,n,v*/);
extern int orthelim(/*realtype *v[],int m, int n,realtype nv[]*/);
extern void newdir(/*realtype *v[],int m,int n,realtype nv[],int ignore*/);
extern void l1round(/*A,b,m,n,F,p,FI*/);
#endif


#endif


