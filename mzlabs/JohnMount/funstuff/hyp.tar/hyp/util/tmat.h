#ifndef tmat_h
#define tmat_h

extern double det3(double (*m)[3][3]);
extern void inv3(double (*m)[3][3], double (*r)[3][3]);
extern void mul3(double (*a)[3][3], double (*b)[3][3], double (*r)[3][3]);
extern void mulv3(double (*a)[3][3], const double v[], double r[]);
extern void pmat3(double (*a)[3][3]);
extern void orthxform(const double a[], const double bin[], 
               const double ap[], const double bpin[],
	       double (*m)[3][3]);
extern void orthmap(const double vin[], double (*m)[3][3]);
extern void tran3(double (*a)[3][3], double (*b)[3][3]);
extern void tet_maps(double (*m)[12][3][3]);

#endif

