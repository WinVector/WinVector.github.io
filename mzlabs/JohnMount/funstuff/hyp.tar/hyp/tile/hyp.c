
/*
    <xtile, hcom: hyperbolic tile sketch pad >
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif


#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "config.h"
#include "util.h"
#include "splay.h"
#include "nr.h"
#include "dist.h"
#include "hyp.h"


#define Sqrt(a) sqrt((mlibreal)a)
#define sq(a) ((a)*(a))

#ifdef __STDC__
static realtype Power(realtype a, int b)
#else
static realtype Power(a,b)
     realtype a; 
     int b;
#endif
{
  switch(b)
    {
    case 2: return a*a;
    case 3: return a*a*a;
    case 4: a= a*a; return a*a;
    default: punt("bad arg to power");
    }
}


/* have to work in PSL/(+-1) and with floating point errors  */
#ifdef __STDC__
void Hcanonicalize(realtype **a)
#else
void Hcanonicalize(a)
     realtype **a;
#endif
{
  if(fabs(a[0][0])<=float_tol)
    a[0][0] = 0.0;
  if(fabs(a[0][1])<=float_tol)
    a[0][1] = 0.0;
  if(fabs(a[1][0])<=float_tol)
    a[1][0] = 0.0;
  if(fabs(a[1][1])<=float_tol)
    a[1][1] = 0.0;
  if((a[0][0]<0.0)||((a[0][0]==0.0)&&(a[0][1]<0.0))||
     ((a[0][0]==0)&&(a[0][1]==0.0)&&(a[1][0]<0.0)))
    {
      a[0][0] = -a[0][0];
      a[0][1] = -a[0][1];
      a[1][0] = -a[1][0];
      a[1][1] = -a[1][1];
    }
}


/* find xform that send (0,0) to (a,b) */
#ifdef __STDC__
static void Hsend(realtype a, realtype b, realtype **m)
#else
static void Hsend(a,b,m)
     realtype a,b,**m;
#endif
{
  realtype x,y,d;

  x = 2.0*a/(a*a+(b-1.0)*(b-1.0));
  y = (1.0-a*a-b*b)/(a*a+(b-1.0)*(b-1.0));
  d = 0.0;  /* d can be anything s.t. |d| < sqrt(1/y) */
  m[0][0] = d*y - x*sqrt(1/y-d*d);
  m[0][1] = d*x + sqrt(y - d*d*y*y);
  m[1][0] = -sqrt(1/y-d*d);
  m[1][1] = d;
  Hcanonicalize(m);
}



#ifdef __STDC__
realtype det(realtype **a)
#else
realtype det(a)
     realtype **a;
#endif
{
  return a[0][0]*a[1][1] - a[1][0]*a[0][1];
}


/* know det(a) = +1.0 */
#ifdef __STDC__
void Hinverse(realtype **a,realtype **b)
#else
void Hinverse(a,b)
     realtype **a,**b;
#endif
{
  b[0][0] = a[1][1];
  b[0][1] = -a[0][1];
  b[1][0] = -a[1][0];
  b[1][1] = a[0][0];
  Hcanonicalize(b);
}


#ifdef __STDC__
void Hcompose(realtype **a,realtype **b,realtype **c)
#else
void Hcompose(a,b,c)
     realtype **a,**b,**c;
#endif
{
  c[0][0] = a[0][0]*b[0][0] + a[0][1]*b[1][0];
  c[0][1] = a[0][0]*b[0][1] + a[0][1]*b[1][1];
  c[1][0] = a[1][0]*b[0][0] + a[1][1]*b[1][0];
  c[1][1] = a[1][0]*b[0][1] + a[1][1]*b[1][1];
  Hcanonicalize(c);
}


/* send (0,0) to (a,b) fixing the midpoint, orientation preserving */
#ifdef __STDC__
void HFsend(realtype a, realtype b, realtype **m)
#else
void HFsend(a,b,m)
     realtype a,b,**m;
#endif
{
  static int initted = 0;
  static realtype *f[2],*fi[2],*t[2],*rot[2];
  int i;
  realtype l,xm,ym;

  if((fabs(a)<=float_tol)&&(fabs(b)<=float_tol))
    {
      m[0][0] = 1.0;
      m[0][1] = 0.0;
      m[1][0] = 0.0;
      m[1][1] = 1.0;
      return;
    }
  if(!initted)
    {
      for(i=0;i<2;++i)
        {
          if((f[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          if((fi[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          if((t[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");      
          if((rot[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
        }
      rot[0][0] = 0.0;
      rot[0][1] = 1.0;
      rot[1][0] = -1.0;
      rot[1][1] = 0.0;
      initted = 1;
    }
  /* find midpoint */
  l = (1-sqrt(1-a*a-b*b))/(a*a+b*b);
  xm = l*a;      /* point to be fixed by xform */
  ym = l*b;
  /* send midpoint to (0,0), apply 180 turn, send (0,0) back */
  Hsend(xm,ym,f);
  Hinverse(f,fi);
  Hcompose(rot,fi,t);
  Hcompose(f,t,m);
}


/* some monitonic function hyperbolic distance */
#ifdef __STDC__
realtype HFdist(realtype px, realtype py, realtype qx, realtype qy)
#else
realtype HFdist(px,py,qx,qy)
     realtype px,py,qx,qy;
#endif
{
return  (Power(px,2) + Power(py,2) - 2*px*qx + Power(qx,2) - 2*py*qy +
       Power(qy,2))/
    ((-1 + Power(px,2) + Power(py,2))*(-1 + Power(qx,2) + Power(qy,2)));
}



/* find intersection of 2 geodesics presented such that */
/* they are the points equidistant from (rx,ry)-(0,0) and (sx,xy)-(0,0) */
#ifdef __STDC__
int Hintersect(realtype rx,realtype ry,realtype sx, realtype sy,
                      realtype *x,realtype *y)
#else
int Hintersect(rx,ry,sx,sy,x,y)
     realtype rx,ry,sx,sy,*x,*y;
#endif
{
  realtype s1,s2,d1,d2;

  s1 = Power(Power(rx,2)*sx + Power(ry,2)*sx - rx*Power(sx,2) - 
              rx*Power(sy,2),2)*
            (-(Power(rx,4)*Power(sx,2)) + Power(ry,2)*Power(sx,2) - 
              2*Power(rx,2)*Power(ry,2)*Power(sx,2) - 
              Power(ry,4)*Power(sx,2) + 2*Power(rx,3)*Power(sx,3) + 
              2*rx*Power(ry,2)*Power(sx,3) - Power(rx,2)*Power(sx,4) - 
              Power(ry,2)*Power(sx,4) - 2*rx*ry*sx*sy + 
              2*Power(rx,2)*ry*Power(sx,2)*sy + 
              2*Power(ry,3)*Power(sx,2)*sy + Power(rx,2)*Power(sy,2) - 
              Power(rx,4)*Power(sy,2) - 
              2*Power(rx,2)*Power(ry,2)*Power(sy,2) - 
              Power(ry,4)*Power(sy,2) + 2*Power(rx,3)*sx*Power(sy,2) + 
              2*rx*Power(ry,2)*sx*Power(sy,2) - 
              2*Power(rx,2)*Power(sx,2)*Power(sy,2) - 
              2*Power(ry,2)*Power(sx,2)*Power(sy,2) + 
              2*Power(rx,2)*ry*Power(sy,3) + 2*Power(ry,3)*Power(sy,3) - 
             Power(rx,2)*Power(sy,4) - Power(ry,2)*Power(sy,4));
  s2 = -4*(Power(rx,2) + Power(ry,2))*(Power(sx,2) + Power(sy,2))*
            (Power(rx,2) + Power(ry,2) - 2*rx*sx + Power(sx,2) - 2*ry*sy + 
              Power(sy,2))*Power(-(Power(rx,2)*sx) - Power(ry,2)*sx + 
              rx*Power(sx,2) + rx*Power(sy,2),2) + 
           4*Power(Power(rx,2)*ry*Power(sx,2) + Power(ry,3)*Power(sx,2) - 
              rx*ry*Power(sx,3) - Power(rx,3)*sx*sy - rx*Power(ry,2)*sx*sy + 
              Power(rx,2)*Power(sx,2)*sy - rx*ry*sx*Power(sy,2) + 
              Power(rx,2)*Power(sy,3),2);
  d1 = ((Power(rx,2) + Power(ry,2))*(Power(sx,2) + Power(sy,2))*
         (Power(rx,2) + Power(ry,2) - 2*rx*sx + Power(sx,2) - 2*ry*sy + 
           Power(sy,2))*(Power(rx,2)*sx + Power(ry,2)*sx - rx*Power(sx,2) - 
           rx*Power(sy,2)));
  d2 = (2*(Power(rx,2) + Power(ry,2))*(Power(sx,2) + Power(sy,2))*
         (Power(rx,2) + Power(ry,2) - 2*rx*sx + Power(sx,2) - 2*ry*sy + 
           Power(sy,2)));

  if((s1>=0.0)&&(s2>=0.0)&&(d1!=0.0)&&(d2!=0.0))
    {
      s1 = Sqrt(s1);
      s2 = Sqrt(s2);
      *x = (ry*Power(sx,2) - Power(rx,2)*sy - Power(ry,2)*sy + 
          ry*Power(sy,2))*(Power(rx,2)*ry*Power(sx,2) + 
          Power(ry,3)*Power(sx,2) - rx*ry*Power(sx,3) - Power(rx,3)*sx*sy - 
          rx*Power(ry,2)*sx*sy + Power(rx,2)*Power(sx,2)*sy - 
          rx*ry*sx*Power(sy,2) + Power(rx,2)*Power(sy,3) - s1 )/d1;
      *y =    (2*Power(rx,2)*ry*Power(sx,2) + 2*Power(ry,3)*Power(sx,2) - 
         2*rx*ry*Power(sx,3) - 2*Power(rx,3)*sx*sy - 2*rx*Power(ry,2)*sx*sy + 
         2*Power(rx,2)*Power(sx,2)*sy - 2*rx*ry*sx*Power(sy,2) + 
         2*Power(rx,2)*Power(sy,3) - 
         s2)/d2;
      if(((*x)*(*x)+(*y)*(*y))<=1.0)
        return 1;

      *x = (ry*Power(sx,2) - Power(rx,2)*sy - Power(ry,2)*sy + ry*Power(sy,2))*
        (Power(rx,2)*ry*Power(sx,2) + Power(ry,3)*Power(sx,2) - 
          rx*ry*Power(sx,3) - Power(rx,3)*sx*sy - rx*Power(ry,2)*sx*sy + 
          Power(rx,2)*Power(sx,2)*sy - rx*ry*sx*Power(sy,2) + 
          Power(rx,2)*Power(sy,3) + 
          s1 )/d1;
      *y =   (2*Power(rx,2)*ry*Power(sx,2) + 2*Power(ry,3)*Power(sx,2) - 
         2*rx*ry*Power(sx,3) - 2*Power(rx,3)*sx*sy - 2*rx*Power(ry,2)*sx*sy + 
         2*Power(rx,2)*Power(sx,2)*sy - 2*rx*ry*sx*Power(sy,2) + 
         2*Power(rx,2)*Power(sy,3) + 
         s2)/d2;
      if(((*x)*(*x)+(*y)*(*y))<=1.0)
        return 1;
    }
  /*else*/
  return 0;
}


/* find axis of transformation */
#ifdef __STDC__
void Hboundary(realtype tx, realtype ty,realtype *px,realtype *py,
                      realtype *qx, realtype *qy)
#else
void Hboundary(tx,ty,px,py,qx,qy)
     realtype tx,ty,*px,*py,*qx,*qy;
#endif
{
  if((fabs(tx)>float_tol)||(fabs(ty)>float_tol))
    {  /* moves origin- easy case use seperator between origin and image */
      if(tx!=0.0)
        {
          *px = (Power(tx,4) + Power(tx,2)*Power(ty,2) -
               ty*Sqrt(Power(tx,2)*(Power(tx,2) - Power(tx,4) + Power(ty,2) -
                                    2*Power(tx,2)*Power(ty,2) - Power(ty,4))))/
                                      (Power(tx,3) + tx*Power(ty,2));
          *py = (Power(tx,2)*ty + Power(ty,3) +
               Sqrt(Power(tx,2)*(Power(tx,2) - Power(tx,4) + Power(ty,2) -
                                 2*Power(tx,2)*Power(ty,2) - Power(ty,4))))/
                                   (Power(tx,2) + Power(ty,2));
          *qx = (Power(tx,4) + Power(tx,2)*Power(ty,2) +
               ty*Sqrt(Power(tx,2)*(Power(tx,2) - Power(tx,4) + Power(ty,2) -
                                    2*Power(tx,2)*Power(ty,2) - Power(ty,4))))/
                                      (Power(tx,3) + tx*Power(ty,2));
          *qy = (Power(tx,2)*ty + Power(ty,3) -
               Sqrt(Power(tx,2)*(Power(tx,2) - Power(tx,4) + Power(ty,2) -
                                 2*Power(tx,2)*Power(ty,2) - Power(ty,4))))/
                                   (Power(tx,2) + Power(ty,2));
        }
      else
        {
          *px = -sqrt(1-ty*ty);
          *py = ty;
          *qx = sqrt(1-ty*ty);
          *qy = ty;
        }
    }
  else
    punt("Elliptic xform through origin");
}


/* get closest pass of a line (not seg) through two points to the origin */
#ifdef __STDC__
realtype Lclose(realtype ax, realtype ay, realtype bx, realtype by)
#else
realtype Lclose(ax,ay,bx,by)
     realtype ax,ay,bx,by;
#endif
{
  realtype t;

  if((ax==bx)||(ay==by))
    {
      if(ax==bx)
        return fabs(ax);
      return fabs(ay);
    }
  t= (Power(ax,2) + Power(ay,2) - ax*bx - ay*by)/
    (Power(ax,2) + Power(ay,2) - 2*ax*bx + Power(bx,2) - 2*ay*by +
     Power(by,2));
  return sqrt(min((ax+(bx-ax)*t)*(ax+(bx-ax)*t)+(ay+(by-ay)*t)*(ay+(by-ay)*t),
                  min(ax*ax+ay*ay,bx*bx+by*by)));
}



/* get closest pass of a line segment through two points to the origin */
#ifdef __STDC__
realtype Lsegclose(realtype ax, realtype ay, realtype bx, realtype by)
#else
realtype Lsegclose(ax,ay,bx,by)
     realtype ax,ay,bx,by;
#endif
{
  realtype t;

  if((ax==bx)||(ay==by))
    {
      if(ax==bx)
        return fabs(ax);
      return fabs(ay);
    }
  t= (Power(ax,2) + Power(ay,2) - ax*bx - ay*by)/
    (Power(ax,2) + Power(ay,2) - 2*ax*bx + Power(bx,2) - 2*ay*by +
     Power(by,2));
  if((t<=0.0)||(t>=1.0))
    return sqrt(min(sq(ax)+sq(ay),sq(bx)+sq(by)));
  /*else */
  return sqrt(min((ax+(bx-ax)*t)*(ax+(bx-ax)*t)+(ay+(by-ay)*t)*(ay+(by-ay)*t),
                  min(ax*ax+ay*ay,bx*bx+by*by)));
}


/* get center and radius of geodesic */
#ifdef __STDC__
void Hconvert(realtype rx, realtype ry, realtype *r, 
                realtype *cx, realtype *cy)
#else
void Hconvert(rx,ry,r,cx,cy)
     realtype rx,ry,*r,*cx,*cy;
#endif
{
  realtype px,py,qx,qy;

  *r = Sqrt(-1 + 1/(Power(rx,2) + Power(ry,2)));
  *cx = rx/(Power(rx,2) + Power(ry,2));
  *cy = ry/(Power(rx,2) + Power(ry,2));
}


#ifdef __STDC__
void Hgeodesic(realtype x1, realtype y1, realtype x2, realtype y2,
                      realtype *rx, realtype *ry)
#else
void Hgeodesic(x1,y1,x2,y2,rx,ry)
     realtype x1,y1,x2,y2,*rx,*ry;
#endif
{
  if(Lclose(x1,y1,x2,y2)<=float_tol)
    {
      *rx = 0.0;
      *ry = 0.0;
      return;
    }
  *rx = 2*(x2*Power(y1,2) + Power(x2,3)*Power(y1,2) - x1*y1*y2 - 
          x2*y1*y2 - Power(x1,2)*x2*y1*y2 - x1*Power(x2,2)*y1*y2 - 
          x2*Power(y1,3)*y2 + x1*Power(y2,2) + Power(x1,3)*Power(y2,2) + 
          x1*Power(y1,2)*Power(y2,2) + x2*Power(y1,2)*Power(y2,2) - 
          x1*y1*Power(y2,3))/
       (Power(x1,2) - 2*x1*x2 - 2*Power(x1,3)*x2 + Power(x2,2) + 
         4*Power(x1,2)*Power(x2,2) + Power(x1,4)*Power(x2,2) - 
         2*x1*Power(x2,3) - 2*Power(x1,3)*Power(x2,3) + 
         Power(x1,2)*Power(x2,4) + Power(y1,2) - 2*x1*x2*Power(y1,2) + 
         4*Power(x2,2)*Power(y1,2) + 2*Power(x1,2)*Power(x2,2)*Power(y1,2) - 
         2*x1*Power(x2,3)*Power(y1,2) + Power(x2,4)*Power(y1,2) + 
         Power(x2,2)*Power(y1,4) - 2*y1*y2 - 2*Power(x1,2)*y1*y2 - 
         2*Power(x2,2)*y1*y2 - 2*Power(x1,2)*Power(x2,2)*y1*y2 - 
         2*Power(y1,3)*y2 - 2*Power(x2,2)*Power(y1,3)*y2 + Power(y2,2) + 
         4*Power(x1,2)*Power(y2,2) + Power(x1,4)*Power(y2,2) - 
         2*x1*x2*Power(y2,2) - 2*Power(x1,3)*x2*Power(y2,2) + 
         2*Power(x1,2)*Power(x2,2)*Power(y2,2) + 4*Power(y1,2)*Power(y2,2) + 
         2*Power(x1,2)*Power(y1,2)*Power(y2,2) - 
         2*x1*x2*Power(y1,2)*Power(y2,2) + 
         2*Power(x2,2)*Power(y1,2)*Power(y2,2) + Power(y1,4)*Power(y2,2) - 
         2*y1*Power(y2,3) - 2*Power(x1,2)*y1*Power(y2,3) - 
         2*Power(y1,3)*Power(y2,3) + Power(x1,2)*Power(y2,4) + 
         Power(y1,2)*Power(y2,4));
  *ry = 2*(-(x1*x2*y1) + Power(x2,2)*y1 + Power(x1,2)*Power(x2,2)*y1 - 
          x1*Power(x2,3)*y1 + Power(x2,2)*Power(y1,3) + Power(x1,2)*y2 - 
          x1*x2*y2 - Power(x1,3)*x2*y2 + Power(x1,2)*Power(x2,2)*y2 - 
          x1*x2*Power(y1,2)*y2 - x1*x2*y1*Power(y2,2) + 
          Power(x1,2)*Power(y2,3))/
       (Power(x1,2) - 2*x1*x2 - 2*Power(x1,3)*x2 + Power(x2,2) + 
         4*Power(x1,2)*Power(x2,2) + Power(x1,4)*Power(x2,2) - 
         2*x1*Power(x2,3) - 2*Power(x1,3)*Power(x2,3) + 
         Power(x1,2)*Power(x2,4) + Power(y1,2) - 2*x1*x2*Power(y1,2) + 
         4*Power(x2,2)*Power(y1,2) + 2*Power(x1,2)*Power(x2,2)*Power(y1,2) - 
         2*x1*Power(x2,3)*Power(y1,2) + Power(x2,4)*Power(y1,2) + 
         Power(x2,2)*Power(y1,4) - 2*y1*y2 - 2*Power(x1,2)*y1*y2 - 
         2*Power(x2,2)*y1*y2 - 2*Power(x1,2)*Power(x2,2)*y1*y2 - 
         2*Power(y1,3)*y2 - 2*Power(x2,2)*Power(y1,3)*y2 + Power(y2,2) + 
         4*Power(x1,2)*Power(y2,2) + Power(x1,4)*Power(y2,2) - 
         2*x1*x2*Power(y2,2) - 2*Power(x1,3)*x2*Power(y2,2) + 
         2*Power(x1,2)*Power(x2,2)*Power(y2,2) + 4*Power(y1,2)*Power(y2,2) + 
         2*Power(x1,2)*Power(y1,2)*Power(y2,2) - 
         2*x1*x2*Power(y1,2)*Power(y2,2) + 
         2*Power(x2,2)*Power(y1,2)*Power(y2,2) + Power(y1,4)*Power(y2,2) - 
         2*y1*Power(y2,3) - 2*Power(x1,2)*y1*Power(y2,3) - 
         2*Power(y1,3)*Power(y2,3) + Power(x1,2)*Power(y2,4) + 
         Power(y1,2)*Power(y2,4));
}


/*get the distance from the closest point on a geodesic segment to the */
/* origin (in euclidian norm) */
/* (x1,y1), (x2,y2) endpoints (gx,gy) point rep of geodesic */
#ifdef __STDC__
realtype Hvisdist(realtype x1, realtype y1,realtype x2, realtype y2,
                       realtype tol)
#else
realtype Hvisdist(x1,y1,x2,y2,tol)
     realtype x1,y1,x2,y2,tol;
#endif
{
  realtype cx,cy,r,gx,gy;

  if((Lclose(x1,y1,x2,y2)<=10.0*float_tol)||
    ((uscaleddiff(x1,x2)<=tol)&&(uscaleddiff(y1,y2)<=tol)))
    return Lsegclose(x1,y1,x2,y2);
  /* arc interscec the line from (0,0) to (gx,gy) is closest */
  Hgeodesic(x1,y1,x2,y2,&gx,&gy);
  if(isnan(gx)||isnan(gy)||(gx*gx+gy*gy>=1.0-float_tol))
    return Lsegclose(x1,y1,x2,y2);
  Hconvert(gx,gy,&r,&cx,&cy);
  if(isnan(cx)||isnan(cy)||isnan(r)||
     (((-cy)*x1+cx*y1)*((-cy)*x2+cx*y2)>=0.0)||((cx*cx+cy*cy)<=float_tol))
    return Lsegclose(x1,y1,x2,y2);
  return sqrt(cx*cx+cy*cy)-r;
}



#ifdef __STDC__
void Hmap(realtype c[], realtype x, realtype y, 
                 realtype *qx, realtype *qy)
#else
void Hmap(c,x,y,qx,qy)
     realtype c[],x,y,*qx,*qy;
#endif
{
  realtype denom,re,im;

  denom = c[0] + (c[1] + c[2]*x)*x + (c[3] + c[4]*y)*y;
  re = c[5] + (c[6] + c[7]*x)*x + (c[8] + c[9]*y)*y;
  im = c[10] + (c[11] + c[12]*x)*x + (c[13] + c[14]*y)*y;
  *qx = re/denom;
  *qy = im/denom;
}



#ifdef __STDC__
void Hcompile(realtype **m,realtype *c)
#else
void Hcompile(m,c)
     realtype **m,*c;
#endif
{
  realtype denom,re,im,x,y;

  c[0] =  m[0][0]*m[0][0] + m[0][1]*m[0][1] - 2*m[0][1]*m[1][0] + 
    m[1][0]*m[1][0] + 2*m[0][0]*m[1][1] + m[1][1]*m[1][1];
  c[1] = 4*m[0][0]*m[0][1] + 4*m[1][0]*m[1][1];
  c[2] = m[0][0]*m[0][0] + m[0][1]*m[0][1] + 2*m[0][1]*m[1][0] + 
    m[1][0]*m[1][0] - 2*m[0][0]*m[1][1] + m[1][1]*m[1][1];
  c[3] = 2*m[0][0]*m[0][0] - 2*m[0][1]*m[0][1] + 2*m[1][0]*m[1][0] - 
    2*m[1][1]*m[1][1];
  c[4] =  m[0][0]*m[0][0] + m[0][1]*m[0][1] + 2*m[0][1]*m[1][0] + 
    m[1][0]*m[1][0] - 2*m[0][0]*m[1][1] + m[1][1]*m[1][1];

  c[5] = 2*m[0][0]*m[1][0] + 2*m[0][1]*m[1][1];
  c[6] = 4*m[0][1]*m[1][0] + 4*m[0][0]*m[1][1]; 
  c[7] = 2*m[0][0]*m[1][0] + 2*m[0][1]*m[1][1];
  c[8] = 4*m[0][0]*m[1][0] - 4*m[0][1]*m[1][1];
  c[9] = 2*m[0][0]*m[1][0] + 2*m[0][1]*m[1][1];

  c[10] = m[0][0]*m[0][0] + m[0][1]*m[0][1] - m[1][0]*m[1][0] - 
    m[1][1]*m[1][1];
  c[11] = 4*m[0][0]*m[0][1] - 4*m[1][0]*m[1][1];
  c[12] = m[0][0]*m[0][0] + m[0][1]*m[0][1] - m[1][0]*m[1][0] - 
    m[1][1]*m[1][1];
  c[13] = 2*m[0][0]*m[0][0] - 2*m[0][1]*m[0][1] - 2*m[1][0]*m[1][0] + 
    2*m[1][1]*m[1][1];
  c[14] = m[0][0]*m[0][0] + m[0][1]*m[0][1] - m[1][0]*m[1][0] - 
    m[1][1]*m[1][1];
}



#ifdef __STDC__
void Happly(realtype **m,realtype x,realtype y,
                   realtype *qx,realtype *qy)
#else
void Happly(m,x,y,qx,qy)
     realtype **m,x,y,*qx,*qy;
#endif
{
  realtype c[comlen];
  
  Hcompile(m,c);
  Hmap(c,x,y,qx,qy);
}


#ifdef __STDC__
realtype Qapply(realtype **m,realtype *qx,realtype *qy)
#else
realtype Qapply(m,qx,qy)
     realtype **m,*qx,*qy;
#endif
{
  realtype denom,re,im;

  denom = m[0][0]*m[0][0] + m[0][1]*m[0][1] - 2*m[0][1]*m[1][0] + 
    m[1][0]*m[1][0] + 2*m[0][0]*m[1][1] + m[1][1]*m[1][1];
  *qx = (2*m[0][0]*m[1][0] + 2*m[0][1]*m[1][1])/denom;
  *qy = (m[0][0]*m[0][0] + m[0][1]*m[0][1] - m[1][0]*m[1][0] - 
        m[1][1]*m[1][1])/denom;
  return (*qx)*(*qx)+(*qy)*(*qy);
}


/* get distance ofclosest point to origing (Euclid norm) of */
/* image of group patch */
#ifdef __STDC__
realtype Hpdist(toptype *op, int npair,optype *m,
                       realtype cx,realtype cy,
                       realtype tol)
#else
realtype Hpdist(op,npair,m,cx,cy,tol)
     toptype *op;
     int npair;
     optype *m;
     realtype cx,cy,tol;
#endif
{
  int i;
  realtype r,tx,ty,x1,y1,x2,y2;
  
  Hmap(m->c,cx,cy,&tx,&ty);
  r = sqrt(tx*tx + ty*ty);
  for(i=0;i<npair;++i)
    {
      Hmap(m->c,op[i].vx[0],op[i].vy[0],&x1,&y1);
      Hmap(m->c,op[i].vx[1],op[i].vy[1],&x2,&y2);
      if((!isnan(x1))&&(!isnan(x2))&&(!isnan(y1))&&(!isnan(y2)))
        r = min(r,Hvisdist(x1,y1,x2,y2,tol));
    }
  return r;
}


#ifdef __STDC__
int near(realtype **a,realtype **b)
#else
int near(a,b)
     realtype **a,**b;
#endif
{
  if(((uscaleddiff(a[0][0],b[0][0])<=float_tol)&&
      (uscaleddiff(a[0][1],b[0][1])<=float_tol)&&
      (uscaleddiff(a[1][0],b[1][0])<=float_tol)&&
      (uscaleddiff(a[1][1],b[1][1])<=float_tol))||
     ((uscaleddiff(a[0][0],-b[0][0])<=float_tol)&&
      (uscaleddiff(a[0][1],-b[0][1])<=float_tol)&&
      (uscaleddiff(a[1][0],-b[1][0])<=float_tol)&&
      (uscaleddiff(a[1][1],-b[1][1])<=float_tol)))
    return 1;
  /*else*/
  return 0;
}


#define quant 10000000.0
/* do a meaninful comparision of a,b */
/* and make damn sure it is transitive (don't allow interactions) */
/* doesn't deal with sign reduction */
#ifdef __STDC__
static int Mcompare(optype *a,optype *b)
#else
static int Mcompare(a,b)
     optype *a,*b;
#endif
{
  realtype da,db,tx,ty;
  int i,j;

  /* first sort on meaningful difference of how far 0 is sent */
  if(a->psindex>b->psindex)
    return 1;
  if(a->psindex<b->psindex)
    return -1;
  /* then sort on meaningful difference in entries */
  for(i=0;i<2;++i)
    for(j=0;j<2;++j)
      {
        da = floor(quant*a->a[i][j]);
        db = floor(quant*b->a[i][j]);
        if(da>db)
          return 1;
        if(da<db)
          return -1;
      }
  return 0; /* no meaningful difference- but not necisarily unique */
}


/* a useful sorting function for H operators */
#ifdef __STDC__
int Hcompare(const gptr ain,const gptr bin)
#else
int Hcompare(ain,bin)
     void *ain,*bin;
#endif
{
  optype *a,*b;
  realtype da,db;
  int i,j;

  a = (optype *)ain;
  b = (optype *)bin;
  if((i = Mcompare(a,b))!=0)
    return i;
  /* then sort on entries just to get uniqueness */
  for(i=0;i<2;++i)
    for(j=0;j<2;++j)
      {
        if(a->a[i][j]>b->a[i][j])
          return 1;
        if(b->a[i][j]>a->a[i][j])
          return -1;
      }
  return 0; /* identical */
}



/* alters data structure */
/* leave dirty pointing at near match item */
#ifdef __STDC__
int not_covered(Tree **t,optype *m)
#else
int not_covered(t,m)
     Tree **t;
     optype *m;
#endif
{
  Tree *o;
  int i;

  o = NULL;
  *t = splay((gptr)m,*t,Hcompare);
  /* back off to start of block */
  /* must skip 2 to avoid rounding accidents */
  while((*t!=o)&&(m->psindex-((optype *)(*t)->item)->psindex<2)&&
        ((m->psindex-((optype *)(*t)->item)->psindex!=1)||
         (uscaleddiff(((optype *)(*t)->item)->a[0][0],m->a[0][0])<=float_tol)))
    {
      if(near(((optype *)(*t)->item)->a,m->a))
        return 0;
      o = *t;
      *t = prev(*t,Hcompare);
    }
  /* walk over all possible matches */
  *t = splay((gptr)m,*t,Hcompare);
  o = NULL;
  while((*t!=o)&&(((optype *)(*t)->item)->psindex-m->psindex<2)&&
        ((((optype *)(*t)->item)->psindex-m->psindex!=1)||
         (uscaleddiff(((optype *)(*t)->item)->a[0][0],m->a[0][0])<=float_tol)))
    {
      if(near(((optype *)(*t)->item)->a,m->a))
        return 0;
      o = *t;
      *t = next(*t,Hcompare);
    }
  return 1;  /* no close match */
}


#ifdef __STDC__
realtype ***readgen(int *ngens,FILE *in)
#else
realtype ***readgen(ngens,in)
     int *ngens;
     FILE *in;
#endif
{
  realtype ***t;
  int i,m,n;

  *ngens = getint(in);
  if(*ngens<=0)
    punt("bad gen count");
  if((t=(realtype ***)malloc((unsigned)(sizeof(realtype **)*(*ngens))))==NULL)
    punt("malloc");
  for(i=0;i<*ngens;++i)
    {
      rmat(in,&(t[i]),&m,&n);
      if((m!=2)||(n!=2))
        punt("bad matrix");
    }
  return t;
}


/* generate a square with k neighbors per corner (k>4) */
/* seems to work for 8 & 12 */
#ifdef __STDC__
realtype ***sgroup(int *ngens,int dtouch)
#else
realtype ***sgroup(ngens,dtouch)
     int *ngens,dtouch;
#endif
{
  realtype ***t,z,gx,gy;
  int i,j;

  if(dtouch<5)
    punt("sgroup must have parm >=5");
  *ngens = 4;
  if((t=(realtype ***)malloc((unsigned)(sizeof(realtype **)*(*ngens))))==NULL)
    punt("malloc");
  for(i=0;i<*ngens;++i)
    {
      if((t[i] = (realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((t[i][j] = (realtype *)malloc((unsigned)(sizeof(realtype)*2)))==
           NULL)
          punt("malloc");
    }
  z = sqrt(0.5-1.0/(1.0+1.0/tan(M_PI/((realtype)dtouch))));
  Hgeodesic(z,-z,z,z,&gx,&gy);
  HFsend(gx,gy,t[0]);
  Hgeodesic(z,z,-z,z,&gx,&gy);
  HFsend(gx,gy,t[1]);
  Hgeodesic(-z,z,-z,-z,&gx,&gy);
  HFsend(gx,gy,t[2]);
  Hgeodesic(-z,-z,z,-z,&gx,&gy);
  HFsend(gx,gy,t[3]);
  for(i=0;i<*ngens;++i)
      Hcanonicalize(t[i]);
  return t;
}


/* generate a triangle  meeting k at each vertex */
#ifdef __STDC__
realtype ***tgroup(int *ngens,int dtouch)
#else
realtype ***tgroup(ngens,dtouch)
     int *ngens,dtouch;
#endif
{
  realtype ***t,gx,gy,z;
  int i,j;

  if(dtouch<4)
    punt("triangle group must have parm >= 4");
  *ngens = 3;
  if((t=(realtype ***)malloc((unsigned)(sizeof(realtype **)*(*ngens))))==NULL)
    punt("malloc");
  for(i=0;i<*ngens;++i)
    {
      if((t[i] = (realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((t[i][j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
          punt("malloc");
    }
  z = sqrt((-1.0*sqrt(3.0)+1.0/tan(M_PI/(2.0*dtouch)))/
           (sqrt(3.0)+1.0/tan(M_PI/(2.0*dtouch))));
  Hgeodesic(0.0,z,z*sqrt(3.0)/2.0,-z/2.0,&gx,&gy);
  HFsend(gx,gy,t[0]);
  Hgeodesic(z*sqrt(3.0)/2.0,-z/2.0,-z*sqrt(3.0)/2.0,-z/2.0,&gx,&gy);
  HFsend(gx,gy,t[1]);
  Hgeodesic(-z*sqrt(3.0)/2.0,-z/2.0,0.0,z,&gx,&gy);
  HFsend(gx,gy,t[2]);
  for(i=0;i<*ngens;++i)
      Hcanonicalize(t[i]);
  return t;
}



/* rotate around a point */
#ifdef __STDC__
static void rot(realtype x,realtype y,realtype a,realtype **o)
#else
static void rot(x,y,a,o)
     realtype x,y,a,**o;
#endif
{
  static realtype *t[2],*m[2],*mi[2];
  static int ready = 0;
  int i;

  if(!ready)
    {
      for(i=0;i<2;++i)
        {
          if((t[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          if((m[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          if((mi[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
        }
      ready = 1;
    }
  HFsend(x,y,m);
  Hinverse(m,mi);
  o[0][0] = cos(a);
  o[0][1] = sin(a);
  o[1][0] = -sin(a);
  o[1][1] = cos(a);
  Hcanonicalize(o);
  Hcompose(o,mi,t);
  Hcompose(m,t,o);
}



/* generate a triangle group with angles 2 pi/p, 2 pi/q, 2 pi/r p>3 */
#ifdef __STDC__
realtype ***trigroup(int *ngens,int p,int q, int r)
#else
realtype ***trigroup(ngens,p,q,r)
     int *ngens,p,q,r;
#endif
{
  realtype ***t,vx,vy,x,z,theta[2];
  int i,j;

  if((p&1)&&(q!=r))
    punt("must haved even number of vertices to alternate angles");
  theta[0] = 2*M_PI/((realtype)q);
  theta[1] = 2*M_PI/((realtype)r);
  *ngens = p;
  if((t=(realtype ***)malloc((unsigned)(sizeof(realtype **)*(*ngens))))==NULL)
    punt("malloc");
  for(i=0;i<*ngens;++i)
    {
      if((t[i] = (realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((t[i][j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
          punt("malloc");
    }
  for(i=0;i<p;++i)
    {
      if(i&1)
        {
          x = (cos(2.0*M_PI/((realtype)p))*cos(2.0*M_PI/((realtype)q))+
               cos(2.0*M_PI/((realtype)r)))/
                 (sin(2.0*M_PI/((realtype)p))*sin(2.0*M_PI/((realtype)q)));
          z = sqrt(fabs((x-1.0)/2.0)/(1.0+fabs((x-1.0)/2.0)));
        }
      else
        {
          x = (cos(2.0*M_PI/((realtype)p))*cos(2.0*M_PI/((realtype)r))+
               cos(2.0*M_PI/((realtype)q)))/
                 (sin(2.0*M_PI/((realtype)p))*sin(2.0*M_PI/((realtype)r)));
          z = sqrt(fabs((x-1.0)/2.0)/(1.0+fabs((x-1.0)/2.0)));
        }
      vx = z*cos((mlibreal)(i*2*M_PI/((realtype)p)));
      vy = z*sin((mlibreal)(i*2*M_PI/((realtype)p)));
      rot(vx,vy,theta[i&1],t[i]);
    }
  for(i=0;i<*ngens;++i)
      Hcanonicalize(t[i]);
  return t;
}



#define maxgen 100

/* assumes (0,0) is not a fixed point of anything */
#ifdef __STDC__
static int Himportant(toptype *op,int npair,int check)
#else
static int Himportant(op,npair,check)
     toptype *op;
     int npair,check;
#endif
{
  static realtype xi[maxgen+2],yi[maxgen+2],tx,ty;
  int good,i,ni,k,l;

  /* see if we go in */
  ni = 0;
  for(i=0;i<npair;++i)
    {
      if(i!=check)
        {
          if((fabs(op[check].gx-op[i].gx)<=float_tol)&&
             (fabs(op[check].gy-op[i].gy)<=float_tol))
            return 0;  /* already generated this side */
          if(Hintersect(op[check].gx,op[check].gy,op[i].gx,op[i].gy,
                        xi+ni,yi+ni))
            if(1.0-xi[ni]*xi[ni]+yi[ni]*yi[ni]>=float_tol)
              {
                good = 1;
                /* get rid of duplicate crossings and dominated crossings */
                for(k=0;(k<npair)&&(good);++k)
                  if(k!=check)
                    {
                      /* relax this one a bit */
                      if(HFdist(xi[ni],yi[ni],0.0,0.0)>=
                         HFdist(xi[ni],yi[ni],op[k].gx,op[k].gy)+float_tol)
                        good = 0;  /* crossing below a curve */
                      else
                        {
                          for(l=k+1;(l<npair)&&(good);++l)
                            if(l!=check)
                              {
                                if(Hintersect(op[l].gx,op[l].gy,
                                              op[k].gx,op[k].gy,&tx,&ty))
                                  {
                                    if((fabs(tx-xi[ni])<float_tol)&&
                                       (fabs(tx-xi[ni])<float_tol))
                                      good = 0; /* too near a crossing */
                                  }
                              }
                        }
                    }
                if(good)
                  ++ni;
              }
        }
    }
  if(ni==0)
    {  /* check if we are an important curve or not */
      for(i=0;i<npair;++i)
        if(i!=check)
          {
            if(HFdist(op[check].gx,op[check].gy,0,0)>=
               HFdist(op[check].gx,op[check].gy,op[i].gx,op[i].gy)-float_tol)
              return 0;
          }
    }

  return 1;
}


/* sorts into cyclic order */
#ifdef __STDC__
static int opcompare(const void *ain,const void *bin)
#else
static int opcompare(ain,bin)
     void *ain,*bin;
#endif
{
  toptype *a,*b;
  realtype t1,t2;

  a = (toptype *)ain;
  b = (toptype *)bin;
  t1 = atan2(a->gy,a->gx);
  t2 = atan2(b->gy,b->gx);
  if(t1>t2)
    return 1;
  if(t1<t2)
    return -1;
  /*else */
  return 0;
}


/* check if a boundary point is outside closure of origin side of geodesic */
/* given by boundary intersections */
/* assume non-colinear boundary */
#ifdef __STDC__
static int Hbsep(realtype x,realtype y,realtype ax,realtype ay,
                 realtype bx,realtype by)
#else
static int Hbsep(x,y,ax,ay,bx,by)
     realtype x,y,ax,ay,bx,by;
#endif
{
  if(((0.0-ax)*(ay-by)+(0.0-ay)*(bx-ax))*((x-ax)*(ay-by)+(y-ay)*(bx-ax))>=0.0)
    return 0;
  return 1;
}


/* operator def */
#ifdef __STDC__
int HinOfund(toptype *op, int npair,realtype centerx, realtype centery,
                   realtype x,realtype y,realtype slop)
#else
int HinOfund(op,npair,centerx,centery,x,y,slop)
     toptype *op;
     int npair;
     realtype centerx,centery,x,y,slop;
#endif
{
  int i;
  realtype cx,cy,d1;

  if(x*x+y*y>1.0-slop)
    return 0;
  d1 = HFdist(centerx,centery,x,y);
  for(i=0;i<npair;++i)
    {
      Hmap(op[i].c,centerx,centery,&cx,&cy);
      if(d1>HFdist(cx,cy,x,y)-slop)
        return 0;
    }
  return 1;
}


/* edge def */
#ifdef __STDC__
int HinEfund(toptype *op, int npair,realtype centerx, realtype centery,
                   realtype x,realtype y,realtype slop)
#else
int HinEfund(op,npair,centerx,centery,x,y,slop)
     toptype *op;
     int npair;
     realtype centerx,centery,x,y,slop;
#endif
{
  int i;
  realtype cx,cy,d1;

  if(x*x+y*y>1.0-fabs(slop))
    return 0;
  d1 = HFdist(0.0,0.0,x,y);
  for(i=0;i<npair;++i)
    {
      if((fabs(op[i].gx)<float_tol)&&(fabs(op[i].gy)<float_tol))
        {
          if(((fabs(x)>slop)||(fabs(y)>slop))&&
             (((op[i].ay-op[i].by)*(x)+(op[i].bx-op[i].ax)*(y))*
             ((op[i].ay-op[i].by)*(centerx)+(op[i].bx-op[i].ax)*(centery))<=
             -slop))
            return 0;
        }
      else
        {
          if(d1>=HFdist(op[i].gx,op[i].gy,x,y)+slop)
            return 0;
        }
    }
  return 1;
}



/* compile a (suspect) set of generators into side pairing relations, */
/* Dirichlet region and a patch of tiles */
#define spill 20
#define multiple 2
#ifdef __STDC__
void HdoGroup(realtype ***gen,int ngens,
                     toptype **top,int *rnpair,int *conjugated,
                     realtype *cx,realtype *cy,
              int conserveconj,int stayconjugated)
#else
void HdoGroup(gen,ngens,top,rnpair,conjugated,cx,cy,conserveconj,
              stayconjugated)
     realtype ***gen;
     int ngens;
     toptype **top;
     int *rnpair,*conjugated;
     realtype *cx,*cy;
     int conserveconj,stayconjugated;
#endif
{
  int i,j,k,l,*flist,multidrops,good;
  realtype *m[2],*ident[2],*conj[2],*temp[2];
  realtype tx,ty,md,d,x,y;
  int Nclean,Ndirty,totstore,index,oi,npair;
  Tree *clean,*dirty;
  optype *r,*t;
  toptype *op;
  toptype temp_op;
  
  /* generate a large (hopefuly) contiguous fragment of the group around 0,0*/
  /* alloc return first so our intermediates are allocated after */
  if((op=(toptype *)malloc((unsigned)(sizeof(toptype)*maxgen)))==NULL)
    punt("malloc");
  for(i=0;i<maxgen;++i)
    {
      if((op[i].a=(realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==
         NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((op[i].a[j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==
           NULL)
          punt("malloc");
    }
  
  if((r=(optype *)malloc((unsigned)(sizeof(optype)*
                                    (maxgen+spill))))
     ==NULL)
    punt("malloc");
  for(i=0;i<maxgen+spill;++i)
    {
      if((r[i].a=(realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((r[i].a[j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==
           NULL)
          punt("malloc");
    }
  totstore = 10*maxgen; /*can always empty to 2*maxgen */
  clean = NULL;
  Nclean = 0;
  dirty = NULL;
  Ndirty = 0;
  if((m[0]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((m[1]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((temp[0]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((temp[1]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((conj[0]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((conj[1]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((ident[0]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((ident[1]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  ident[0][0] = 1.0;
  ident[0][1] = 0.0;
  ident[1][0] = 0.0;
  ident[1][1] = 1.0;
  if((t=(optype *)malloc((unsigned)(sizeof(optype)*
                                     (totstore+spill))))==NULL)
    punt("malloc");
  for(i=0;i<totstore+spill;++i)
    {
      if((t[i].a=(realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((t[i].a[j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==
           NULL)
          punt("malloc");
    }
  if((flist=(int *)malloc((unsigned)(sizeof(int)*
                                     (totstore+spill))))==NULL)
    punt("malloc");
  for(i=0;i<(totstore+spill);++i)
    flist[i] = i;


  /* canonicalize generators */
  for(i=0;i<ngens;++i)
    Hcanonicalize(gen[i]);

  if(conserveconj)
    {
      *conjugated = 0;
      for(i=0;(i<ngens)&&(!*conjugated);++i)
        if(Qapply(gen[i],&tx,&ty)<=float_tol)
          {
            *conjugated = 1;
#ifdef debug_hyp
            (void)printf(".symmetry at (0,0)\n");
#endif
          }
    }
  else
    *conjugated = 1;
  if(*conjugated)
    {  /* (0,0) is a symmetry point- conjugate away */
      do { 
        /* somewhat random xform */
        ++*conjugated;
        tx = uniform(-0.2,0.2);
        ty = uniform(-0.2,0.2);
        md = 1.0;
        for(i=0;(i<ngens)&&(md>float_tol);++i)
          {
            Happly(gen[i],tx,ty,&x,&y);
            if((d=HFdist(tx,ty,x,y))<md)
              md = d;
          }
      } while(md<=float_tol);
      if(!stayconjugated)
        {
          *cx = tx;
          *cy = ty;
        }
      else
        {
          *cx = 0.0;
          *cy = 0.0;
        }
      HFsend(tx,ty,conj);
      Hinverse(conj,m);
#ifdef debug_hyp
      (void)printf(".conj(0,0)->(%g,%g) [[%g,%g],[%g,%g]]\n",tx,ty,
                   conj[0][0],conj[0][1],conj[1][0],conj[1][1]);
#endif
      for(i=0;i<ngens;++i)
        {
#ifdef debug_hyp
          (void)printf("[[%g,%g],[%g,%g]] -> ",gen[i][0][0],gen[i][0][1],
                       gen[i][1][0],gen[i][1][1]);
#endif
          Hcompose(conj,gen[i],temp);
          Hcompose(temp,m,gen[i]);
#ifdef debug_hyp
          (void)printf("[[%g,%g],[%g,%g]]\n",gen[i][0][0],gen[i][0][1],
                       gen[i][1][0],gen[i][1][1]);
#endif
        }
#if debug_hyp>=2
      (void)printf("  conjugated generators %d times\n",conjugated-1);
#endif
    }
  else
    {
      *cx = 0.0;
      *cy = 0.0;
    }

  /* put in generators */
  for(i=0;i<ngens;++i)
    {
      if(uscaleddiff(det(gen[i]),1.0)>float_tol)
        punt("bad generator determinant");
      for(j=0;j<2;++j)
        for(k=0;k<2;++k)
          t[flist[Ndirty]].a[j][k] = gen[i][j][k];
      t[flist[Ndirty]].psindex = 
        floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
      if((!near(ident,gen[i]))&&not_covered(&dirty,t+flist[Ndirty]))
        dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
    }
  /* put in inverses */
  for(i=0;i<ngens;++i)
    {
      Hinverse(gen[i],t[flist[Ndirty]].a);
      t[flist[Ndirty]].psindex = 
        floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
      if((!near(ident,gen[i]))&&not_covered(&dirty,t+flist[Ndirty]))
        dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
    }
  multidrops = 0;

  /* move stuff from dirty heap to clean heap */
  while(Nclean<maxgen)
    {
      /* pull up least new element */
      do {
        if(Ndirty<=0)
          punt("exhausted group");
        dirty = first(dirty,Hcompare);
        index = ((optype *)dirty->item) - t;
        dirty = delete(dirty->item,dirty,&Ndirty,Hcompare);
        flist[Ndirty] = index;  /* reclaim entry */
        if(!not_covered(&clean,t+index))
          {
#ifdef debug_hyp
            (void)printf(" Mdrop: [[%g %g][%g %g]]\n",
                         t[index].a[0][0],t[index].a[0][1],
                         t[index].a[1][0],t[index].a[1][1]);
#endif
            ++multidrops;
            if(multidrops>=2*ngens)
              punt("oops");
          }
        else
          {
#if debug_hyp>=2
      (void)printf(" -: [[%g %g][%g %g]]\n",
                   t[index].a[0][0],t[index].a[0][1],
                   t[index].a[1][0],t[index].a[1][1]);
#endif
          }
      } while(!not_covered(&clean,t+index));
      /* put it in */
      for(i=0;i<2;++i)
        for(j=0;j<2;++j)
          r[Nclean].a[i][j] = t[index].a[i][j];
      r[Nclean].psindex = t[index].psindex;
      clean = insert((gptr)(r+Nclean),clean,&Nclean,Hcompare);
      if(Qapply(r[Nclean-1].a,&tx,&ty)<=float_tol)
        punt("symmetry at (0,0)");
#if debug_hyp>=2
      (void)printf("%d(%g): [[%g %g][%g %g]]\n",Nclean,
                   Qapply(r[Nclean-1].a,&tx,&ty),
                   r[Nclean-1].a[0][0],r[Nclean-1].a[0][1],
                   r[Nclean-1].a[1][0],r[Nclean-1].a[1][1]);
#endif
      /* make sure inverse comes with it (for niceness of group fragment)*/
      Hinverse(t[index].a,r[Nclean].a);
      r[Nclean].psindex = floor(quant*Qapply(r[Nclean].a,&tx,&ty));
      index = Nclean;
      if(not_covered(&clean,r+Nclean))
        {
          /* put it in */
          clean = insert((gptr)(r+Nclean),clean,&Nclean,Hcompare);
#if debug_hyp>=2
          (void)printf("%d(%g): [[%g %g][%g %g]].\n",Nclean,
                       Qapply(r[Nclean-1].a,&tx,&ty),
                       r[Nclean-1].a[0][0],r[Nclean-1].a[0][1],
                       r[Nclean-1].a[1][0],r[Nclean-1].a[1][1]);
#endif
        }
      /* exploit that dirty will point to matching item */
      if(!not_covered(&dirty,r+index))
        {
          i = ((optype *)dirty->item) - t;
          dirty = delete(dirty->item,dirty,&Ndirty,Hcompare);
          flist[Ndirty] = i; /* reclaim entry */
#if debug_hyp>=2
          (void)printf(" -- [[%g %g][%g %g]]\n",
                       t[i].a[0][0],t[i].a[0][1],
                       t[i+1].a[1][0],t[i+1].a[1][1]);
#endif

        }
      /* enque all of its friends into dirty */
      /* friends of f are f^-1, f*f, f^-1*f^-1, */
      /* f*c, c*f, f^-1*c, c*f^-1 for any clean c */
      Hinverse(r[index].a,t[flist[Ndirty]].a);
      if(not_covered(&clean,t+flist[Ndirty])&&
         not_covered(&dirty,t+flist[Ndirty]))
        dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
      Hinverse(r[index].a,m);
      for(l=0;l<Nclean;++l)
        {
          Hcompose(r[index].a,r[index].a,t[flist[Ndirty]].a);
          t[flist[Ndirty]].psindex = 
            floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
          if(not_covered(&clean,t+flist[Ndirty])&&
             not_covered(&dirty,t+flist[Ndirty])&&
             (!near(ident,t[flist[Ndirty]].a)))
            dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
          Hcompose(r[index].a,r[l].a,t[flist[Ndirty]].a);
          t[flist[Ndirty]].psindex = 
            floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
          if(not_covered(&clean,t+flist[Ndirty])&&
             not_covered(&dirty,t+flist[Ndirty])&&
             (!near(ident,t[flist[Ndirty]].a)))
            dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
          Hcompose(r[l].a,r[index].a,t[flist[Ndirty]].a);
          t[flist[Ndirty]].psindex = 
            floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
          if(not_covered(&clean,t+flist[Ndirty])&&
             not_covered(&dirty,t+flist[Ndirty])&&
             (!near(ident,t[flist[Ndirty]].a)))
            dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
          Hcompose(m,m,t[flist[Ndirty]].a);
          t[flist[Ndirty]].psindex = 
            floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
          if(not_covered(&clean,t+flist[Ndirty])&&
             not_covered(&dirty,t+flist[Ndirty])&&
             (!near(ident,t[flist[Ndirty]].a)))
            dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
          Hcompose(m,r[l].a,t[flist[Ndirty]].a);
          t[flist[Ndirty]].psindex = 
            floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
          if(not_covered(&clean,t+flist[Ndirty])&&
             not_covered(&dirty,t+flist[Ndirty])&&
             (!near(ident,t[flist[Ndirty]].a)))
            dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
          Hcompose(r[l].a,m,t[flist[Ndirty]].a);
          t[flist[Ndirty]].psindex = 
            floor(quant*Qapply(t[flist[Ndirty]].a,&tx,&ty));
          if(not_covered(&clean,t+flist[Ndirty])&&
             not_covered(&dirty,t+flist[Ndirty])&&
             (!near(ident,t[flist[Ndirty]].a)))
            dirty = insert((gptr)(t+flist[Ndirty]),dirty,&Ndirty,Hcompare);
          if(Ndirty>=totstore)
            {
#if debug_hyp>=2
              (void)printf("draining que\n");
#endif
              if(Ndirty>=totstore+spill)
                punt("que overran");
              /* drop all but usable potion of que */
              while(Ndirty>maxgen-Nclean+2+ngens)
                {
                  dirty = last(dirty,Hcompare);
                  i = ((optype *)dirty->item) - t;
                  dirty = delete(dirty->item,dirty,&Ndirty,Hcompare);
                  flist[Ndirty] = i;
#if debug_hyp>=2
                  (void)printf(" ---- [%g %g][%g %g]]\n",
                               t[i].a[0][0],t[i].a[0][1],
                               t[i+1].a[1][0],t[i+1].a[1][1]);
#endif

                }
            }
        }
    }
#ifndef NOFREE
  freetree(dirty,Hcompare,NULL);
  free(flist);
  for(i=totstore+spill-1;i>=0;--i)
    {
      for(j=1;j>=0;--j)
        free(t[i].a[j]);
      free(t[i].a);
    }
  free(t);
#endif

#ifdef debug_hyp
  (void)printf("deriving Dirichlet polygon and side pairing operations\n");
#endif

  /* try to find Dirichlet polygon and side pairing maps */
  npair = 0;
  for(oi=0;oi<maxgen;++oi)
    {
      (void)Qapply(r[oi].a,&(op[npair].gx),&(op[npair].gy));
      if(Himportant(op,npair,npair))
        {  /* curve goes in */
          for(i=0;i<2;++i)
            for(j=0;j<2;++j)
              op[npair].a[i][j] = r[oi].a[i][j];
          ++npair;
          if(npair>=maxgen)
            punt("too many relations");
          for(i=0;i<npair;++i)
            if(!Himportant(op,npair,i))
              {  /* somebody comes out */
                temp_op = op[npair-1];
                op[npair-1] = op[i];
                op[i] = temp_op;
                --npair;
                --i;
              }
        }
    }
  /* get boundary of side pairing relations */
  /* before deconjugating */
  /* sort sides into cyclic order */
  qsort((void *)op,(size_t)npair,(size_t)sizeof(toptype),opcompare);
  for(i=0;i<npair;++i)
    {
      Hcompile(op[i].a,op[i].c);
      if((op[i].ai=(realtype **)malloc((unsigned)(sizeof(realtype *)*2)))
         ==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((op[i].ai[j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))
           ==NULL)
          punt("malloc");
      Hinverse(op[i].a,op[i].ai);
      Hcompile(op[i].ai,op[i].ci);
      Hmap(op[i].c,0.0,0.0,&(op[i].fcx),&(op[i].fcy));
      Hboundary(op[i].gx,op[i].gy,&(op[i].ax),&(op[i].ay),
                &(op[i].bx),&(op[i].by));
      op[i].nv = 0;
      if(Hintersect(op[i].gx,op[i].gy,
                    op[(i<=0)?npair-1:i-1].gx,op[(i<=0)?npair-1:i-1].gy,
                    &(op[i].vx[op[i].nv]),&(op[i].vy[op[i].nv])))
        ++op[i].nv;
      if(Hintersect(op[i].gx,op[i].gy,
                    op[(i>=npair-1)?0:i+1].gx,op[(i>=npair-1)?0:i+1].gy,
                    &(op[i].vx[op[i].nv]),&(op[i].vy[op[i].nv])))
        ++op[i].nv;
    }
  for(i=0;i<npair;++i)
    {
      if(op[i].nv==0)
        {
          op[i].vx[0] = op[i].ax;
          op[i].vy[0] = op[i].ay;
          op[i].vx[1] = op[i].bx;
          op[i].vy[1] = op[i].by;
          op[i].nv = 2;
        }
      else
        {
          if(op[i].nv==1)
            {
              if((uscaleddiff(op[i].bx,op[i].vx[0])<=sqrt(float_tol))&&
                 (uscaleddiff(op[i].by,op[i].vy[0])<=sqrt(float_tol)))
                good = 0;
              else
                {
                  op[i].vx[1] = op[i].bx;
                  op[i].vy[1] = op[i].by;
                  good = 1;
                  for(j=0;(j<npair)&&good;++j)
                    if(j!=i)
                      {
                        if(Hbsep(op[i].vx[1],op[i].vy[1],op[j].ax,op[j].ay,
                                 op[j].bx,op[j].by))
                          good = 0;
                      }
                }
              if(!good)
                {
                  op[i].vx[1] = op[i].ax;
                  op[i].vy[1] = op[i].ay;
                }
              op[i].nv = 2;
            }
        }
    }
  /* sort crossings */
  for(i=0;i<npair;++i)
    {
      if(((fabs(op[i].vx[1]-op[(i<=0)?npair-1:i-1].vx[0])<=float_tol)&&
          (fabs(op[i].vy[1]-op[(i<=0)?npair-1:i-1].vy[0])<=float_tol))||
         ((fabs(op[i].vx[1]-op[(i<=0)?npair-1:i-1].vx[1])<=float_tol)&&
          (fabs(op[i].vy[1]-op[(i<=0)?npair-1:i-1].vy[1])<=float_tol)))
        { /* swap */
          tx = op[i].vx[0];
          op[i].vx[0] = op[i].vx[1];
          op[i].vx[1] = tx;
          ty = op[i].vy[0];
          op[i].vy[0] = op[i].vy[1];
          op[i].vy[1] = ty;
        }
    }

  /*can't unconjugate group until we are done with tree- changes key values*/
#ifndef NOFREE
  freetree(clean,Hcompare,NULL);
#endif
  Nclean = 0;
  clean = NULL;

  /* unconjugate group */
  if((!stayconjugated)&&(*conjugated))
    {
#ifdef debug_hyp
      (void)printf("unconjugating group\n");
#endif
      Hinverse(conj,m);
      for(i=0;i<npair;++i)
        {
#ifdef debug_hyp
          (void)printf("g%d [[%g,%g],[%g,%g]] -> ",i
                       ,op[i].a[0][0],op[i].a[0][1],
                       op[i].a[1][0],op[i].a[1][1]);
#endif
          Hcompose(m,op[i].a,temp);
          Hcompose(temp,conj,op[i].a);
#ifdef debug_hyp
          (void)printf("[[%g,%g],[%g,%g]]\n",op[i].a[0][0],op[i].a[0][1],
                       op[i].a[1][0],op[i].a[1][1]);
#endif
          Hcompile(op[i].a,op[i].c);
          Hinverse(op[i].a,op[i].ai);
          Hcompile(op[i].ai,op[i].ci);
          Hmap(op[i].c,*cx,*cy,&(op[i].fcx),&(op[i].fcy));
          Happly(m,op[i].ax,op[i].ay,&(op[i].ax),&(op[i].ay));
          Happly(m,op[i].bx,op[i].by,&(op[i].bx),&(op[i].by));
          Hgeodesic(op[i].ax,op[i].ay,op[i].bx,op[i].by,&(op[i].gx),
                    &(op[i].gy));
          for(j=0;j<op[i].nv;++j)
            Happly(m,op[i].vx[j],op[i].vy[j],&(op[i].vx[j]),&(op[i].vy[j]));
        }
    }

#ifndef NOFREE
  freetree(clean,Hcompare,NULL);
  for(i=maxgen+spill-1;i>=0;--i)
    {
      for(j=1;j>=0;--j)
        free(r[i].a[j]);
      free(r[i].a);
    }
  free(r);
  free(ident[1]);
  free(ident[0]);
  free(conj[1]);
  free(conj[0]);
  free(temp[1]);
  free(temp[0]);
  free(m[1]);
  free(m[0]);
#endif
  *top = op;
  *rnpair = npair;
}



#ifdef __STDC__
void HextendPatch(toptype *op, int npair, realtype cx, realtype cy,int nops, 
                  realtype tol, optype **rlist, 
                  optype *inlist, int nin)
#else
void HextendPatch(op,npair,cx,cy,nops,tol,rlist,inlist,nin)
     toptype *op;
     int npair; 
     realtype cx,cy;
     int nops;
     realtype tol;
     optype **rlist;
     optype *inlist;
     int nin;
#endif
{
  int i,j,k,Nclean,*flist,index;
  realtype *ident[2],tx,ty;
  optype *r;
  Tree *clean;

#ifdef debug_hyp
  (void)printf("extending group patch\n");
#endif
  if((*rlist=(optype *)malloc((unsigned)(sizeof(optype)*nops)))==NULL)
    punt("malloc");
  for(i=0;i<nops;++i)
    {
      if(((*rlist)[i].a = 
          (realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==
         NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if(((*rlist)[i].a[j]=
            (realtype *)malloc((unsigned)(sizeof(realtype)*2)))==
           NULL)
          punt("malloc");
    }
  if((r=(optype *)malloc((unsigned)(sizeof(optype)*
                                    (multiple*nops+spill))))
     ==NULL)
    punt("malloc");
  for(i=0;i<multiple*nops+spill;++i)
    {
      if((r[i].a=(realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        if((r[i].a[j]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==
           NULL)
          punt("malloc");
    }
  /* add to the patch */
  if((flist=(int *)malloc((unsigned)(sizeof(int)*(multiple*nops+spill))))==
     NULL)
    punt("malloc");
  for(i=0;i<nops*multiple+spill;++i)
    flist[i] = i;
  clean = NULL;
  Nclean = 0;
  if((ident[0]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  if((ident[1]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
    punt("malloc");
  ident[0][0] = 1.0;
  ident[0][1] = 0.0;
  ident[1][0] = 0.0;
  ident[1][1] = 1.0;

  /* put pairing relations in que */
  for(i=0;i<npair;++i)
    {
      for(j=0;j<2;++j)
        for(k=0;k<2;++k)
          r[flist[Nclean]].a[j][k] = op[i].a[j][k];
      Hcompile(r[flist[Nclean]].a,r[flist[Nclean]].c);
      r[flist[Nclean]].psindex = 
        floor(quant*Hpdist(op,npair,r+flist[Nclean],cx,cy,tol));
      clean = insert((gptr)(r+flist[Nclean]),clean,&Nclean,Hcompare);
    }
  /* put inlist in que */
  if(inlist!=NULL)
    for(i=0;i<npair;++i)
      {
        for(j=0;j<2;++j)
          for(k=0;k<2;++k)
            r[flist[Nclean]].a[j][k] = inlist[i].a[j][k];
        Hcompile(r[flist[Nclean]].a,r[flist[Nclean]].c);
        r[flist[Nclean]].psindex = 
          floor(quant*Hpdist(op,npair,r+flist[Nclean],cx,cy,tol));
        clean = insert((gptr)(r+flist[Nclean]),clean,&Nclean,Hcompare);
      }
  /* sweep que to generate rest of patch */
  i = 0;
  while(i<nops*multiple)
    {
      for(j=0;j<npair;++j)
        {
          Hcompose(r[i].a,op[j].a,r[flist[Nclean]].a);
          Hcompile(r[flist[Nclean]].a,r[flist[Nclean]].c);
          r[flist[Nclean]].psindex = 
            floor(quant*Hpdist(op,npair,r+flist[Nclean],cx,cy,tol));
          if(not_covered(&clean,r+flist[Nclean])&&
             (!near(ident,r[flist[Nclean]].a)))
            {
              Hmap(r[flist[Nclean]].c,cx,cy,&tx,&ty);
              if(HinEfund(op,npair,cx,cy,tx,ty,-float_tol))
                punt("moved into Dirichlet tile (group not discrete?)");
              clean = 
                insert((gptr)(r+flist[Nclean]),clean,&Nclean,Hcompare);
            }
          while(Nclean>nops*multiple)
            {
              clean = last(clean,Hcompare);
              index = ((optype *)clean->item) - r;
              clean = delete(clean->item,clean,&Nclean,Hcompare);
              flist[Nclean] = index;  /* reclaim entry */
            }
        }
      ++i;
#if debug_hyp>=2
      (void)printf(".");
      fflush(stdout);
#endif
    }
#if debug_hyp>=2
  (void)printf("\n");
#endif

  /* compile all our operators */
  for(i=0;i<nops;++i)
    {
      clean = first(clean,Hcompare);
      index = ((optype *)clean->item) - r;
      clean = delete(clean->item,clean,&Nclean,Hcompare);
      for(j=0;j<2;++j)
        for(k=0;k<2;++k)
          (*rlist)[i].a[j][k] = r[index].a[j][k];
      Hcompile((*rlist)[i].a,(*rlist)[i].c);
    }

#ifndef NOFREE
  freetree(clean,Hcompare,NULL);
  free(ident[1]);
  free(ident[0]);
  free(flist);
  for(i=nops*multiple+spill-1;i>=0;--i)
    {
      for(j=1;j>=0;--j)
        free(r[i].a[j]);
      free(r[i].a);
    }
  free(r);
#endif
}


#ifdef __STDC__
void writeops(FILE *f,toptype *op, int npair,int conjugated,
              realtype centerx, realtype centery, optype *oplist, int nops)
#else
void writeops(f,op,npair,conjugated,centerx,centery,oplist,nops)
     FILE *f;
     toptype *op;
     int npair,conjugated;
     realtype centerx,centery;
     optype *oplist;
     int nops;
#endif
{
  int i,j,k;
  if(fwrite((void *)&npair,sizeof(int),1,f)!=1)
    punt("fwrite");
  /* write out pointers even though they are useless */
  if(fwrite((void *)op,sizeof(toptype),npair,f)!=npair)
    punt("fwrite");
  for(i=0;i<npair;++i)
    for(j=0;j<2;++j)
      for(k=0;k<2;++k)
        if(fwrite((void *)&(op[i].a[j][k]),sizeof(realtype),1,f)!=1)
          punt("fwrite");
  if(fwrite((void *)&conjugated,sizeof(int),1,f)!=1)
    punt("fwrite");
  if(fwrite((void *)&centerx,sizeof(realtype),1,f)!=1)
    punt("fwrite");
  if(fwrite((void *)&centery,sizeof(realtype),1,f)!=1)
    punt("fwrite");
  if(fwrite((void *)&nops,sizeof(int),1,f)!=1)
    punt("fwrite");
  for(i=0;i<nops;++i)
    for(j=0;j<2;++j)
      for(k=0;k<2;++k)
        if(fwrite((void *)&(oplist[i].a[j][k]),sizeof(realtype),1,f)!=1)
          punt("fwrite");
}


#ifdef __STDC__
void readops(FILE *f,toptype **op, int *npair,int *conjugated,
             realtype *centerx, realtype *centery, optype **oplist,
             int *nops)
#else
void readops(f,op,npair,conjugated,centerx,centery,oplist,nops)
     FILE *f;
     toptype **op;
     int *npair,*conjugated;
     realtype *centerx,*centery;
     optype **oplist;
     int *nops;
#endif
{
  int i,j,k;
  if(fread((void *)npair,sizeof(int),1,f)!=1)
    punt("fread");
  if((*op=(toptype *)malloc((unsigned)(sizeof(toptype)*(*npair))))==NULL)
    punt("malloc");
  if(fread((void *)(*op),sizeof(toptype),*npair,f)!=*npair)
    punt("fread");
  for(i=0;i<*npair;++i)
    {
      if(((*op)[i].a=
          (realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      if(((*op)[i].ai=
          (realtype **)malloc((unsigned)(sizeof(realtype *)*2)))==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        {
          if(((*op)[i].a[j]=
              (realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          if(((*op)[i].ai[j]=
              (realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          for(k=0;k<2;++k)
            if(fread((void *)&((*op)[i].a[j][k]),sizeof(realtype),1,f)!=1)
              punt("fread");
        }
      Hcompile((*op)[i].a,(*op)[i].c);
      Hinverse((*op)[i].a,(*op)[i].ai);
      Hcompile((*op)[i].ai,(*op)[i].ci);
    }
  if(fread((void *)conjugated,sizeof(int),1,f)!=1)
    punt("fread");
  if(fread((void *)centerx,sizeof(realtype),1,f)!=1)
    punt("fread");
  if(fread((void *)centery,sizeof(realtype),1,f)!=1)
    punt("fread");
  if(fread((void *)nops,sizeof(int),1,f)!=1)
    punt("fread");
  if((*oplist=(optype *)malloc((unsigned)(sizeof(optype)*(*nops))))==NULL)
    punt("malloc");
  for(i=0;i<*nops;++i)
    {
      if(((*oplist)[i].a=(realtype **)malloc((unsigned)(sizeof(realtype *)*2)))
         ==NULL)
        punt("malloc");
      for(j=0;j<2;++j)
        {
          if(((*oplist)[i].a[j] = 
              (realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
            punt("malloc");
          for(k=0;k<2;++k)
            if(fread((void *)&((*oplist)[i].a[j][k]),sizeof(realtype),1,f)!=1)
              punt("fread");
        }
      (*oplist)[i].psindex = 0.0;
      Hcompile((*oplist)[i].a,(*oplist)[i].c);
    }
}


/* build a map that pulls (x,y) into the fundemental region */
#ifdef __STDC__
void HPmap(toptype *op, int npair, realtype centerx, realtype centery,
                  realtype x, realtype y, realtype **f,realtype tol)
#else
void HPmap(op,npair,centerx,centery,x,y,f,tol)
     toptype *op;
     int npair;
     realtype centerx,centery,x,y,**f,tol;
#endif
{
  static realtype *t[2] = {NULL,NULL};
  realtype c[comlen],td,md;
  int i,j,index;

  if(t[0]==NULL)
    {
      for(i=0;i<2;++i)
        if((t[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
          punt("malloc");
    }
  f[0][0] = 1.0;
  f[0][1] = 0.0;
  f[1][0] = 0.0;
  f[1][1] = 1.0;
  while(!HinEfund(op,npair,centerx,centery,x,y,tol))
    {
      /* find direction to step */
      for(i=0;i<npair;++i)
        {
          td = HFdist(x,y,op[i].fcx,op[i].fcy);
          if((i==0)||(td<md))
            {
              md = td;
              index = i;
            }
        }
      /* pull back */
      Hmap(op[index].ci,x,y,&x,&y);
      /* compose operator */
      Hcompose(op[index].ai,f,t);
      f[0][0] = t[0][0];
      f[0][1] = t[0][1];
      f[1][0] = t[1][0];
      f[1][1] = t[1][1];
    }
}


#ifdef __STDC__
int rmsuffix(char s[],char suf[])
#else
int rmsuffix(s,suf)
     char s[],suf[];
#endif
{
  int i,j;
  i = strlen(s)-1;
  j = strlen(suf)-1;
  while((i>=0)&&(j>=0)&&(s[i]==suf[j]))
    {
      --i;
      --j;
    }
  if(j<0)
    {
      s[i+1] = 0;
      return 1;
    }
  return 0;
}
