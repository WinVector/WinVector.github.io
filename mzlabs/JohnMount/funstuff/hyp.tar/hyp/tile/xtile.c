
/*
    <xtile, hcom: hyperbolic tile sketch pad >
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif


#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

/* this is left out on purpose */
#ifdef USEPBM
#ifdef __hpux
#define SVR4
#endif
#include "../xv/xv.h"
#endif


#include <X11/X.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>
#ifdef DOSHAPE
#include <Xm/Xm.h>
#include <Xm/DrawingA.h>
#include <Xm/BulletinB.h>
#include <Xm/Scale.h>
#include <X11/extensions/shape.h>  /* R4 header required */
#include <Xm/MwmUtil.h>      /* mwm decoration */
#endif
#include "config.h"
#include "util.h"
#include "splay.h"
#include "nr.h"
#include "dist.h"
#include "hyp.h"
#include "icon.bitmap"


#define stlen 256


/*********** X stuff *************************/

#define rgbmax 255
#define initcolors 2
#define maxcolors (rgbmax+initcolors+2+500)
const static int Emask = (Button1MotionMask|Button2MotionMask|ButtonPressMask|
                    KeyPressMask|ExposureMask);
static Display *display;
static int screen;
static GC gc1,gcerase;
static XColor COLORVEC[maxcolors];
static int cindex[maxcolors];
static int w_height,w_width,display_width,display_height,ncolors,nrefs;
static Tree *colortree;
static XFontStruct *theFont;
static Window theWindow;
static Colormap cmap;
static Pixmap pm;
static int pm_in = 0;
static XImage *xim = NULL;
static Cursor curs,wait;



typedef struct {
  unsigned int r,g,b;
  int index;
} sfield_type;


#ifdef __STDC__
static int ccompare(const gptr ain,const gptr bin)
#else
static int ccompare(ain,bin)
     char *ain,*bin;
#endif
{
  const sfield_type *a,*b;
  a = (sfield_type *)ain;
  b = (sfield_type *)bin;
  if(a->r>b->r)
    return 1;
  if(a->r<b->r)
    return -1;
  if(a->g>b->g)
    return 1;
  if(a->g<b->g)
    return -1;
  if(a->b>b->b)
    return 1;
  if(a->b<b->b)
    return -1;
  return 0;
}



#ifdef __STDC__
static void shutDown(void)
#else
static void shutDown()
#endif
{
  XFreeCursor(display,curs);
  XFreeCursor(display,wait);
  if(pm_in)
    XFreePixmap(display,pm);
  if(xim!=NULL)
    XDestroyImage(xim);
  XDestroyWindow(display,theWindow);
  XFreeFont(display,theFont);
  XFreeGC(display,gc1);
  XFreeGC(display,gcerase);
  XFreeColormap(display,cmap);
  XCloseDisplay(display);
#ifndef NOFREE
  freetree(colortree,ccompare,NULL);
#endif
}

#define white 0
#define black 1




#ifdef __STDC__
static void fetchenv(char s[],const char name[])
#else
static void fetchenv(s,name)
     char s[],name[];
#endif
{
  char *p;
  int i;
  
  p = getenv(name);
  if(p==NULL)
    {
      (void)fprintf(stderr,"environment variable %s not set properly\n",name);
      punt("environment variable");
    }
  for(i=0;(p[i]!=0)&&(i<stlen-1);++i)
    s[i] = p[i];
  s[i] = 0;
}



static int midx,midy,radius;
#ifdef __STDC__
extern double floor(double);
#else
extern double floor();
#endif

#define screenx(x) ((int)floor((x)*radius+midx+0.5))
#define screeny(y) ((int)floor(midy-(y)*radius+0.5))
#define unscreenx(px) (((px) - midx)/((double)radius))
#define unscreeny(py) ((midy - (py))/((double)radius))


#ifdef __STDC__
static void Heval(realtype c[],int px, int py,int *qx, int *qy)
#else
static void Heval(c,px,py,qx,qy)
     realtype c[];
     int px,py,*qx,*qy;
#endif
{
  realtype x,y;

  /* invert screenx and screeny */
  Hmap(c,unscreenx(px),unscreeny(py),&x,&y);
  *qx = screenx(x);
  *qy = screeny(y);
}


static XPoint *draw_p = NULL;
static int draw_n = 0;
#ifdef DOSHAPE
static int need_draw = 0;
#endif
#ifdef __STDC__
static void drawpoints(GC gc,int x,int y,optype *oplist,int nops)
#else
static void drawpoints(gc,x,y,oplist,nops)
     GC gc;
     int x,y;
     optype *oplist;
     int nops;
#endif
{
  int i,j,k,qx,qy;

  if(draw_n<nops+1)
    {
#ifndef NOFREE
      if(draw_p!=NULL)
        free(draw_p);
#endif
      draw_n = nops+1;
      if((draw_p=(XPoint *)malloc((unsigned)(sizeof(XPoint)*draw_n)))==NULL)
        punt("malloc");
    }
  for(i=0;i<nops;++i)
    {
      Heval(oplist[i].c,x,y,&qx,&qy);
      draw_p[i].x = qx;
      draw_p[i].y = qy;
    }
  draw_p[nops].x = x;
  draw_p[nops].y = y;
  XDrawPoints(display,pm,gc,draw_p,nops+1,CoordModeOrigin);
#ifdef DOSHAPE
  XDrawPoint(display,theWindow,gc,x,y);
  need_draw = 1;
#else
  XDrawPoints(display,theWindow,gc,draw_p,nops+1,CoordModeOrigin);
#endif
}


#ifdef USEPBM
#ifdef __STDC__
static void Hfpatch(toptype *op, int npair,int **rfx, int **rfy, int *rndot,
                    realtype centerx, realtype centery)
#else
static void Hfpatch(op,npair,rfx,rfy,rndot,centerx,centery)
     toptype *op;
     int npair,**rfx,**rfy,*rndot;
     realtype centerx,centery;
#endif
{
  int i,j,len,*fx,*fy,ndot;
  realtype slop;

  slop = min(fabs(unscreenx(0)-unscreenx(1)),fabs(unscreeny(0)-unscreeny(0)));
  if((fx=(int *)malloc((unsigned)(sizeof(int)*4*radius*radius)))==NULL)
    punt("malloc");
  if((fy=(int *)malloc((unsigned)(sizeof(int)*4*radius*radius)))==NULL)
    punt("malloc");
#ifdef debug_hyp
  (void)printf("finding fundemental patch\n");
#endif
  /* find filled portions of fundemental region */
  ndot = 0;
  for(i=0;i<2*radius;++i)
    {
      len = (int)floor(sqrt(radius*((realtype)radius)-
                          (i-radius)*((realtype)(i-radius))));
      for(j=radius-len;j<radius+len;++j)
        {
          if(HinEfund(op,npair,centerx,centery,unscreenx(i),unscreeny(j),slop))
            {
              fx[ndot] = i;
              fy[ndot] = j;
              ++ndot;
            }
        }
    }
#ifndef NOFREE
  if((fx=(int *)realloc((void *)fx,(unsigned)(sizeof(int)*ndot)))==NULL)
    punt("realloc");
  if((fy=(int *)realloc((void *)fy,(unsigned)(sizeof(int)*ndot)))==NULL)
    punt("realloc");
#endif
  *rfx = fx;
  *rfy = fy;
  *rndot = ndot;
}



/* assume both same type (don't check) */
#ifdef __STDC__
static void pcopy(PICINFO *p1,int x,int y,PICINFO *pd,int xd, int yd)
#else
static void pcopy(p1,x,y,pd,xd,yd)
     PICINFO *p1;
     int x,y;
     PICINFO *pd;
     int xd,yd;
#endif
{
  switch(p1->type)
    {
    case PIC8:
      pd->pic[yd*pd->w+xd] = p1->pic[y*p1->w+x];
      break;
    case PIC24:
      pd->pic[3*(yd*pd->w+xd)] = p1->pic[3*(y*p1->w+x)];
      pd->pic[3*(yd*pd->w+xd)+1] = p1->pic[3*(y*p1->w+x)+1];
      pd->pic[3*(yd*pd->w+xd)+2] = p1->pic[3*(y*p1->w+x)+2];
      break;
    default: punt("bad bit mode");
    }
}



/* assume both same type (don't check) */
#ifdef __STDC__
static void paccum(PICINFO *p1, int x, int y, 
                   double *pr, double *pg, double *pb)
#else
static void paccum(p1,x,y,pr,pg,pb)
     PICINFO *p1;
     int x,y;
     double *pr,*pg,*pb;
#endif
{
  switch(p1->type)
    {
    case PIC8:
      *pr += p1->pic[y*p1->w+x];
      break;
    case PIC24:
      *pr += p1->pic[3*(y*p1->w+x)];
      *pg += p1->pic[3*(y*p1->w+x)+1];
      *pb += p1->pic[3*(y*p1->w+x)+2];
      break;
    default: punt("bad bit mode");
    }
}



#ifdef __STDC__
static void pset(PICINFO *pd, int xd, int yd, 
                 double p_r, double p_g, double p_b)
#else
static void pset(pd,xd,yd,p_r,p_g,p_b)
     PICINFO *pd;
     int xd,yd;
     double p_r,p_g,p_b;
#endif
{
  switch(pd->type)
    {
    case PIC8:
      pd->pic[yd*pd->w+xd] = (int)p_r;
      break;
    case PIC24:
      pd->pic[3*(yd*pd->w+xd)] = (int)p_r;
      pd->pic[3*(yd*pd->w+xd)+1] = (int)p_g;
      pd->pic[3*(yd*pd->w+xd)+2] = (int)p_b;
      break;
    default: punt("bad bit mode");
    }
}


#ifdef anti_alias
/* 3 points well distributed in [-.5 ,.5]^2 */
static double aap[3][2] = {
    { -0.321876 , 0.109245},
    { -0.034479 , -0.323665},
    { 0.216982 , 0.220536}
  };
#define aap_points 3
#else
static double aap[1][2] = { {0.0, 0.0} };
#define aap_points 1
#endif

#ifdef __STDC__
static void Hreplicate(toptype *op, int npair, 
                       realtype centerx,realtype centery,PICINFO *p,
                       int messup)
#else
static void Hreplicate(op,npair,centerx,centery,p,messup)
     toptype *op;
     int npair,messup;
     realtype centerx,centery;
     PICINFO *p;
#endif
{
  static realtype *im[2] = {NULL, NULL};
  int i,j,k,l,len,m,ntot,non,n,pnum,goods;
  realtype x,y,tx,ty,px,py,cm[comlen],slop,p_r,p_g,p_b;
  
  if(im[0]==NULL)
    {
      for(i=0;i<2;++i)
        if((im[i]=(realtype *)malloc((unsigned)(sizeof(realtype)*2)))==NULL)
          punt("malloc");
    }
#ifdef debug_hyp
  (void)printf("applying map\n");
#endif
  im[0][0] = 1.0;
  im[0][1] = 0.0;
  im[1][0] = 0.0;
  im[1][1] = 1.0;
  Hcompile(im,cm);
  slop = float_tol;
  /* do the drawing */
  for(i=0;i<2*radius;++i)
    {
      len = (int)floor(sqrt(radius*((realtype)radius)-
                          (i-radius)*((realtype)(i-radius))));
      for(j=radius-len;j<radius+len;++j)
        {
          x = unscreenx(j);
          y = unscreeny(i);
          if(x*x+y*y<1.0-slop)
            {
              if(!HinEfund(op,npair,centerx,centery,x,y,slop))
                {
                  if(messup&&((i&1)==0)&&((j&1)==0))
                    {
                      if(((i+j)&2)==0)
                        pset(p,j,i,255.0,255.0,255.0);
                      else
                        pset(p,j,i,0.0,0.0,0.0);
                    }
                  else
                    {
                      p_r = p_g = p_b = 0.0;
                      goods = 0;
                      for(pnum=0;pnum<aap_points;++pnum)
                        {
                          px = x + aap[pnum][0]/((double)radius);
                          py = y + aap[pnum][1]/((double)radius);
                          if(px*px+py*py<1.0-slop)
                            {
                              ++goods;
                              if(HinEfund(op,npair,centerx,centery,px,py,slop))
                                {
                                  tx = px;
                                  ty = py;
                                }
                              else
                                {
                                  /* check if last map will do the trick */
                                  Hmap(cm,px,py,&tx,&ty);
                                  if(!HinEfund(op,npair,centerx,centery,tx,ty,
                                               slop))
                                    { /* generate new pullback */
                                      HPmap(op,npair,centerx,centery,px,py,im,
                                            slop);
                                      Hcompile(im,cm);
                                      Hmap(cm,px,py,&tx,&ty);
                                    }
                                }
                              paccum(p,screenx(tx),screeny(ty),&p_r,&p_g,&p_b);
                            }
                          if(goods<=0)
                            {
                              px = x;
                              py = y;
                              ++goods;
                              if(HinEfund(op,npair,centerx,centery,px,py,slop))
                                {
                                  tx = px;
                                  ty = py;
                                }
                              else
                                {
                                  /* check if last map will do the trick */
                                  Hmap(cm,px,py,&tx,&ty);
                                  if(!HinEfund(op,npair,centerx,centery,tx,ty,
                                               slop))
                                    { /* generate new pullback */
                                      HPmap(op,npair,centerx,centery,px,py,im,
                                            slop);
                                      Hcompile(im,cm);
                                      Hmap(cm,px,py,&tx,&ty);
                                    }
                                }
                              paccum(p,screenx(tx),screeny(ty),&p_r,&p_g,&p_b);
                            }
                          pset(p,j,i,p_r/((double)goods),p_g/((double)goods),
                               p_b/((double)goods));
                        }
                    }
                }
            }
        }
#ifdef debug_hyp
      (void)printf(".");
      (void)fflush(stdout);
#endif
    }
#ifdef debug_hyp
  (void)printf("\ndone\n");
#endif
}
#endif


#ifdef __STDC__
static void HXdrawgeodesic(realtype x1,realtype y1, realtype x2, 
                           realtype y2,GC gc,Drawable dr)
#else
static void HXdrawgeodesic(x1,y1,x2,y2,gc,dr)
     realtype x1,y1,x2,y2;
     GC gc;
     Drawable dr;
#endif
{
  realtype gx,gy,cx,cy,r,t1,t2,t;
  
  /* doesn't matter what we do on very small structures */
  if((abs(screenx(x1)-screenx(x2))<=1)&&(abs(screeny(y1)-screeny(y2))<=1))
    {
      if((screenx(x1)==screenx(x2))&&(screeny(y1)==screeny(y2)))
        XDrawPoint(display,dr,gc,screenx(x1),screeny(y1));
      else
        XDrawLine(display,dr,gc,screenx(x1),screeny(y1),screenx(x2),
                  screeny(y2));
      return;
    }
  if(Lclose(x1,y1,x2,y2)>=
     max(fabs(unscreenx(0)-unscreenx(1)),fabs(unscreeny(0)-unscreeny(1))))
    {
      Hgeodesic(x1,y1,x2,y2,&gx,&gy);
      Hconvert(gx,gy,&r,&cx,&cy);
      if(r<20.0)
        {
          t1 = atan2(y1-cy,x1-cx);
          if(t1<0.0)
            t1 += 2.0*M_PI;
          t2 = atan2(y2-cy,x2-cx);
          if(t2<0.0)
            t2 += 2.0*M_PI;
          if(t1>t2)
            {
              t = t1;
              t1 = t2;
              t2 = t;
            }
          if(t2-t1<=M_PI)
            t2 = t2 - t1;
          else
            t2 = t2 - t1 - 2.0*M_PI;
          XDrawArc(display,dr,gc,
                   screenx(cx) - (int)floor(r*radius+0.5),
                   screeny(cy) - (int)floor(r*radius+0.5),
                   (unsigned int)(2*floor(radius*r+0.5)),
                   (unsigned int)(2*floor(radius*r+0.5)),
                   (int)floor(360.0*64.0*t1/(2.0*M_PI)+0.5),
                   (int)floor(360.0*64.0*t2/(2.0*M_PI)+0.5));
        }
      else
        XDrawLine(display,dr,gc,screenx(x1),screeny(y1),
                  screenx(x2),screeny(y2));
    }
  else
    XDrawLine(display,dr,gc,screenx(x1),screeny(y1),
              screenx(x2),screeny(y2));
}


#ifdef __STDC__
static void HXdrawgeodesics(realtype x1, realtype y1, realtype x2, realtype y2,
                            GC gc, Drawable dr, optype *oplist, int nops)
#else
static void HXdrawgeodesics(x1,y1,x2,y2,gc,dr,oplist,nops)
     realtype x1,y1,x2,y2;
     GC gc;
     Drawable dr;
     optype *oplist;
     int nops;
#endif
{
  int i;
  realtype nx1,nx2,ny1,ny2;

  HXdrawgeodesic(x1,y1,x2,y2,gc,dr);
  for(i=0;i<nops;++i)
    {
      Hmap(oplist[i].c,x1,y1,&nx1,&ny1);
      Hmap(oplist[i].c,x2,y2,&nx2,&ny2);
      HXdrawgeodesic(nx1,ny1,nx2,ny2,gc,dr);
    }
}


#define sq(x) ((x)*(x))


#ifdef __STDC__
static int rgbmap(unsigned int r,unsigned int g,unsigned  int b,int add, 
                  Tree **ct, int *nct)
#else
static int rgbmap(r,g,b,add,ct,nct)
     unsigned int r,g,b;
     int add;
     Tree **ct;
     int *nct;
#endif
{
  int i,j,gotcol;
  realtype bd,td;
  static sfield_type *s = NULL, *t = NULL;
  
  if(s==NULL)
    {
      if((s=(sfield_type *)malloc((unsigned)(sizeof(sfield_type))))==NULL)
        punt("malloc");
    }
  if(t==NULL)
    {
      if((t=(sfield_type *)malloc((unsigned)(sizeof(sfield_type))))==NULL)
        punt("malloc");
    }
  s->r = (r&0xff)<<8;
  s->g = (g&0xff)<<8;
  s->b = (b&0xff)<<8;
  s->index = ncolors;
  *ct = splay((gptr)s,*ct,ccompare);
  if((*ct!=NULL)&&(ccompare((gptr)s,(*ct)->item)==0))
    return ((sfield_type *)((*ct)->item))->index;
  /* else, color (or close match) not in- must add it (and maybe ref) */
  if(!add)
    punt("unknown color");
  /* else */
  COLORVEC[ncolors].red = s->r;
  COLORVEC[ncolors].green = s->g;
  COLORVEC[ncolors].blue = s->b;
  *ct = insert((gptr)s,*ct,nct,ccompare);  /* insert direct ref */
  if((s->r==s->g)&&(s->g==s->b)&&((s->b==0xff00)||(s->b==0x0000)))
    { /* black/white */
      if(s->b==0x0000)
        {  /* black */
          COLORVEC[ncolors].red = COLORVEC[ncolors].blue = 
            COLORVEC[ncolors].green = 0x0000;
          COLORVEC[ncolors].pixel = BlackPixel(display,screen);
        }
      else
        { /* white */
          COLORVEC[ncolors].red = COLORVEC[ncolors].blue = 
            COLORVEC[ncolors].green = 0xffff;
          COLORVEC[ncolors].pixel = WhitePixel(display,screen);
        }
      gotcol = 1;
    }
  else
    gotcol = XAllocColor(display,cmap,COLORVEC+ncolors);
  if(gotcol)
    {
      t->r = COLORVEC[ncolors].red;
      t->g = COLORVEC[ncolors].green;
      t->b = COLORVEC[ncolors].blue;
      t->index = ncolors;
      if((s->r!=t->r)||(s->g!=t->g)||(s->b!=t->b))
        { /* only got a near color */
          *ct = splay((gptr)t,*ct,ccompare);
          if(ccompare((gptr)t,(*ct)->item)==0)
            { /* actual color allready allocated- new ref only */
              s->index = ((sfield_type *)((*ct)->item))->index;
            }
          else
            { /* new color and not a match - insert it */
              *ct = insert((gptr)t,*ct,nct,ccompare);
              if(COLORVEC[ncolors].pixel<maxcolors) {
                cindex[COLORVEC[ncolors].pixel] = ncolors;
              }
              ++ncolors;
              if(ncolors>=maxcolors)
                punt("too many colors");
              t = NULL;
            }
        }
      else
        {
          if(COLORVEC[ncolors].pixel<maxcolors) {
            cindex[COLORVEC[ncolors].pixel] = ncolors;
          }
          ++ncolors;
          if(ncolors>=maxcolors)
            punt("too many colors");
        }
      i = s->index;
      s = NULL;
    }
  else
    {  /* assing a "close" color */
      for(j=0;j<ncolors;++j)
        {
          td = sq((realtype)(s->r-COLORVEC[j].red))+
            sq((realtype)(s->g-COLORVEC[j].green))+
              sq((realtype)(s->b-COLORVEC[j].blue));
          if((j==0)||(td<bd))
            {
              i = j;
              bd = td;
            }
        }
      s->index = i;
      s = NULL;
    }
  return i;
}



/* because % is signed */
#ifdef __STDC__
static int mod(int a,int b)
#else
static int mod(a,b)
     int a,b;
#endif
{
  int t;
  t = a%b;
  if(a<0)
    return t+b;
  return t;
}


/* wait till window is visible and ready- try to eat extra expose events */
/* return if we saw an exposure event (seperately) */
/* either returns an expose event or a good event */
#ifdef __STDC__
static int xnextvisevent(XEvent *r, int *haveone)
#else
static int xnextvisevent(r,haveone)
     XEvent *r;
     int *haveone;
#endif
{
  XWindowAttributes watt;
  int saw_expose;

  saw_expose = 0;
  XGetWindowAttributes(display,theWindow,&watt);
  do {
    if(saw_expose&&(watt.map_state==IsViewable))
      {  /* see if we should process current exposure */
        if(!XCheckWindowEvent(display,theWindow,Emask,r))
          {  /* no events pending- do the refresh */
            *haveone = 0;
            return saw_expose;
          }
      }
    else
      XNextEvent(display,r); /* go ahead and block */
    XGetWindowAttributes(display,theWindow,&watt);
    if((r->type==Expose)||(r->type==MappingNotify))
      saw_expose = 1;
  } while((watt.map_state!=IsViewable)||(r->type==Expose)||
          (r->type==NoExpose)||(r->type==MappingNotify));
  *haveone = 1;
  return saw_expose;
}


#define prefix "H_"


#ifdef __STDC__
static void insertpre(char *s,char *p, char *d)
#else
static void insertpre(s,p,d)
     char *s,*p,*d;
#endif
{
  int i;

  d[0] = 0;
  i = strlen(s);
  while((i>=0)&&(s[i]!='/'))
    --i;
  (void)strcpy(d,p);
  (void)strcat(d,s+i+1);
}


#ifdef USEPBM
#ifdef __STDC__
static void wpixmap(Pixmap p,char *ifname)
#else
static void wpixmap(p,ifname)
     Pixmap p;
     char *ifname;
#endif
{
  int i,j,saw_diff,nscolors,k;
  FILE *ofile;
  PICINFO rp;
  char ofname[stlen];

  if(xim!=NULL)
    punt("image in use");
  xim = XGetImage(display,pm,0,0,2*radius,2*radius,AllPlanes,
                  XYPixmap);
  insertpre(ifname,prefix,ofname);
  if(!rmsuffix(ofname,suffix))
    {
      (void)fprintf(stderr,"oops\n");
      XDestroyImage(xim);
      xim = NULL;
      return;
    }
  /* figure out color model to use */
  rp.w = 2*radius;
  rp.h = 2*radius;
  if(ncolors<=2)
    {
      rp.type = PIC8;
      rp.colType = F_BWDITHER;
      (void)strcat(ofname,".pbm");
      if((rp.pic = (byte *)malloc((unsigned)(sizeof(byte)*rp.w*rp.h)))==NULL)
        {
          (void)fprintf(stderr,"malloc\n");
          XDestroyImage(xim);
          xim = NULL;
          return;
        }
      rp.r[0] = rp.g[0] = rp.b[0] = 255;  /* white */
      rp.r[1] = rp.g[1] = rp.b[1] = 0;    /* black */
      nscolors = 2;
      for(i=0;i<rp.w;++i)
        for(j=0;j<rp.h;++j)
          if(XGetPixel(xim,i,j)==WhitePixel(display,screen))
            rp.pic[j*rp.w+i] = 0;
          else
            rp.pic[j*rp.w+i] = 1;
    }
  else
    {
      saw_diff = 0;
      for(i=0;(i<ncolors)&&(!saw_diff);++i)
        if((COLORVEC[i].red!=COLORVEC[i].blue)||
           (COLORVEC[i].red!=COLORVEC[i].green))
          saw_diff = 1;
      if(saw_diff)
        {
          rp.type = PIC24;
          rp.colType = F_FULLCOLOR;
          (void)strcat(ofname,".ppm");
          if((rp.pic = (byte *)malloc((unsigned)(sizeof(byte)*rp.w*rp.h*3)))==
             NULL)
            {
              (void)fprintf(stderr,"malloc\n");
              XDestroyImage(xim);
              xim = NULL;
              return;
            }
          nscolors = 0;
          for(i=0;i<rp.w;++i)
            for(j=0;j<rp.h;++j)
              {
                k = cindex[XGetPixel(xim,i,j)];
                rp.pic[3*(j*rp.w+i)] = (COLORVEC[k].red>>8)&0xff;
                rp.pic[3*(j*rp.w+i)+1] = (COLORVEC[k].green>>8)&0xff;
                rp.pic[3*(j*rp.w+i)+2] = (COLORVEC[k].blue>>8)&0xff;
              }
        }
      else
        {
          rp.type = PIC8;
          rp.colType = F_GREYSCALE;
          (void)strcat(ofname,".pgm");
          if((rp.pic = (byte *)malloc((unsigned)(sizeof(byte)*rp.w*rp.h)))==
             NULL)
            {
              (void)fprintf(stderr,"malloc\n");
              XDestroyImage(xim);
              xim = NULL;
              return;
            }
          for(i=0;i<256;++i)
            rp.r[i] = rp.g[i] = rp.b[i] = i;
          nscolors = 256;
          for(i=0;i<rp.w;++i)
            for(j=0;j<rp.h;++j)
              {
                k = cindex[XGetPixel(xim,i,j)];
                rp.pic[j*rp.w+i] = MONO((COLORVEC[k].red>>8)&0xff,
                                        (COLORVEC[k].green>>8)&0xff,
                                        (COLORVEC[k].blue>>8)&0xff);
              }
        }
    }
  XDestroyImage(xim);
  xim = NULL;
  if((ofile=fopen(ofname,"w"))==NULL)
    {
      (void)fprintf(stderr,"couldn't open \"%s\"\n",
                    ofname);
      free(rp.pic);
      return;
    }
  if(WritePBM(ofile,rp.pic,rp.type,rp.w,rp.h,rp.r,
              rp.g,rp.b,nscolors,rp.colType,1,NULL))
    {
      (void)fprintf(stderr,"couldn't write .pbm\n");
      (void)fclose(ofile);
      free(rp.pic);
      return;
    }
  free(rp.pic);
  if(fclose(ofile))
    {
      (void)fprintf(stderr,"couldn't close file\n");
      return;
    }
  (void)printf("wrote \"%s\"\n",ofname);
}
#endif


#define nucolor 8
#define motion_stutter 10

#ifdef __STDC__
main(int argc,char *argv[])
#else
main(argc,argv)
     int argc;
     char *argv[];
#endif
{
  int *fx,*fy,ndot,ofsx,ofsy,conjugated,happy,delta,gevent,showmeth;
  int xlat[256];
#ifdef DOSHAPE
  int motion_pulse = 0;
#endif
  char display_name[stlen],s[stlen];
  Window root;
  int i,j,k,depth,done,nimage,nin,rectangle,matchsize;
  XSizeHints hints;
  /* cname is white, black, skin, red, tcolor, placeforpupil, end mark */
  static char *cname[] = {"white", "black", (char *)NULL};
  char user_cnames[nucolor][stlen];
  int ucolor,usize;
  XGCValues values;
  unsigned long int valuemask;
  XEvent report;
  int oldx,oldy,first,npair,nops,c,error,automatic;
  optype *oplist,*inlist;
  toptype *op;
  realtype x,y,t,r,cx,cy,t1,t2,*xs,*ys,centerx,centery,x1,y1,x2,y2,*f[2];
  FILE *gfile;
  extern char *optarg;
  extern int optind;
  char bfname[stlen],ifname[stlen];
#ifdef USEPBM
  PICINFO pinfo,rp;
#endif
  FILE *ofile;
  char ofname[2*stlen];
  Pixmap icon_pixmap;
  unsigned long int **pim;
  KeySym keysym;
#ifdef DOSHAPE
  int shape_event_base, shape_error_base; /* just used as dummy parameters */
  static XtAppContext app_con;
  static Widget       toplevel;
#endif

#ifdef USEPBM
  pinfo.comment = NULL;
  rp.comment = NULL;
#endif
  start_up(0);
  error = 0;
  automatic = 0;
  ucolor = 0;
  usize = 200000;
  showmeth = 0;
  matchsize = 0;
  rectangle = 0;
  while((c=getopt(argc,argv,":pc:s:rdm"))!=EOF)
    switch(c)
      {
      case 'd':
        showmeth = 1;
        break;
      case 'm':
        matchsize = 1;
        break;
      case 'r':
        rectangle = 1;
        break;
      case 's':
        if((optarg==NULL)||(optarg[0]==0))
          ++error;
        else
          usize = atoi(optarg);
        break;
      case 'c':
        if((optarg==NULL)||(optarg[0]==0)||(automatic)||(ucolor>=nucolor))
          ++error;
        else
          {
            (void)strncpy(user_cnames[ucolor],optarg,stlen-1);
            user_cnames[ucolor][stlen-1] = 0;
            ++ucolor;
          }
        break;
      case 'p':
        if(ucolor!=0)
          ++error;
        else
          automatic = 1;
        break;
      default: 
        ++error;
        break;
      }
  if(error||(optind>argc-2))
    punt("use: xtile [-s size][-r]([-m][-d] -p gfile ppm | [-c color]* groupfile nops)");

  (void)strncpy(ifname,argv[optind],stlen-1);
  ifname[stlen-1] = 0;
  if(!rmsuffix(ifname,suffix))
    punt("didn't have right suffix");
  (void)strcat(ifname,suffix);
  if((gfile=fopen(ifname,"r"))==NULL)
    punt("couldn't open group file");
  if(automatic)
    {
      nops = 0;
      (void)strncpy(bfname,argv[optind+1],stlen-1);
      bfname[stlen-1] = 0;
    }
  else
    nops = atoi(argv[optind+1]);

  mysrandom(7845);

  first = 1;

  /* X junk */
  fetchenv(display_name,"DISPLAY");
  if( (display=XOpenDisplay(display_name))==NULL)
    punt("couldn't open display");
  screen = DefaultScreen(display);
  root = RootWindow(display,screen);
  display_width = DisplayWidth(display,screen);
  display_height = DisplayHeight(display,screen);
  /* allocate some colors */
  depth = DisplayPlanes(display,screen);
  cmap = DefaultColormap(display,screen);
  done = 0;
  ncolors = 0;
  colortree = NULL;
  nrefs = 0;
  for(i=0;(cname[i]!=(char *)NULL)&&
      ((ncolors<2)||(depth>1));++i)
    {
      if(!XParseColor(display,cmap,cname[i],COLORVEC+ncolors))
        punt("couldn't parse color");
      (void)rgbmap(COLORVEC[ncolors].red>>8,COLORVEC[ncolors].green>>8,
                   COLORVEC[ncolors].blue>>8,1,&colortree,&nrefs);
      if(i+1!=ncolors)
        punt("didn't add manditory color");
    }

  if(automatic)
    {
#ifdef USEPBM
      LoadPBM(bfname,&pinfo);
      if(matchsize)
        usize = min(pinfo.w,pinfo.h);
      insertpre(bfname,prefix,ofname);
      if((ofile=fopen(ofname,"w"))==NULL)
        punt("couldn't open output file");
      /* get colors */
      switch(pinfo.colType)
        {
        case F_BWDITHER: break;
        case F_GREYSCALE:
        case F_FULLCOLOR:
          for(i=0;i<64;++i)
            xlat[i] = rgbmap(i<<2,i<<2,i<<2,1,&colortree,&nrefs);
          break;
        default: punt("bad color type");
        }
#else
      (void)punt("not compiled to load or save pixmaps");
#endif
    }  
  else
    {
      /* add in user colors */
      for(i=0;cname[i]!=NULL;++i)
        (void)printf("key %d is color \"%s\"\n",i,cname[i]);
      for(i=0;i<ucolor;++i)
        {
          if(!XParseColor(display,cmap,user_cnames[i],COLORVEC+ncolors))
            punt("couldn't parse color");
          j = ncolors;
          (void)rgbmap(COLORVEC[ncolors].red>>8,COLORVEC[ncolors].green>>8,
                       COLORVEC[ncolors].blue>>8,1,&colortree,&nrefs);
          if(j!=ncolors)
            (void)printf("key %d is color \"%s\"\n",ncolors-1,user_cnames[i]);
        }
    }
  (void)printf("got %d colors and %d refs.\n",ncolors,nrefs);
  
  w_width = min(min(display_width,display_height)-50,usize);
  w_height = min(min(display_width,display_height)-50,usize);
  
  theWindow = XCreateSimpleWindow(display,root,0,0,w_width,w_height
                                  ,1,BlackPixel(display,screen),
                                  WhitePixel(display,screen));
  XSelectInput(display,theWindow,Emask);
               
  if((theFont = XLoadQueryFont(display,"9x15"))==NULL)
    {
      XCloseDisplay(display);
      punt("couldn't load font");
    }
  valuemask = 0;
  gc1 = XCreateGC(display,theWindow,valuemask,&values);
  XSetForeground(display,gc1,BlackPixel(display,screen));
  XSetBackground(display,gc1,WhitePixel(display,screen));
  XSetFont(display,gc1,theFont->fid);
  XSetLineAttributes(display,gc1,0,LineSolid,CapRound,JoinRound);
  gcerase = XCreateGC(display,theWindow,valuemask,&values);
  XSetForeground(display,gcerase,WhitePixel(display,screen));
  XSetBackground(display,gcerase,BlackPixel(display,screen));
  XSetFont(display,gcerase,theFont->fid);
  XSetLineAttributes(display,gc1,0,LineSolid,CapRound,JoinRound);
  valuemask = GCFunction;
  values.function = GXequiv;
  icon_pixmap = XCreatePixmapFromBitmapData(display,theWindow,icon_bits,
                                            icon_width,icon_height,
                                            WhitePixel(display,screen),
                                            BlackPixel(display,screen),1);
  hints.flags = PSize | PMinSize | PMaxSize | PAspect;
  hints.width = w_width;
  hints.height = w_height;
  hints.min_width = hints.width;
  hints.min_height = hints.height;  
  hints.max_width = hints.width;
  hints.max_height = hints.height;
  hints.min_aspect.x = 1;
  hints.min_aspect.y = 1;
  hints.max_aspect.x = 1;
  hints.max_aspect.y = 1;
  XSetStandardProperties(display,theWindow,"Lobachevski Plane","Lobachevski"
                         ,icon_pixmap,argv,argc,&hints);


  /* find the middle and radius of display circle */
  midx = w_width/2;
  midy = w_height/2;
  radius = min(min(midx,midy),min(w_height-midy,w_width-midx))/*-1*/;
  midx = radius;  /* some code doesn't handle midx/radius distinction */
  midy = radius;

  pm = XCreatePixmap(display,theWindow,2*radius,2*radius,depth);
  pm_in = 1;
#ifdef DOSHAPE
  /* if there is a shape extension, use it */
  if ((!rectangle)&&(!automatic)&&XShapeQueryExtension (display,
                            &shape_event_base, 
                            &shape_error_base)) {
    XGCValues	xgcv;
    GC shapeGC ;
    Pixmap shape_mask ;
    
    shape_mask = XCreatePixmap (display, theWindow,
                                w_width, w_height, 1);
    shapeGC = XCreateGC (display, shape_mask, 0, &xgcv);
    
    /* erase the pixmap as a mask */
    XSetForeground (display, shapeGC, 0);
    XFillRectangle (display, shape_mask, shapeGC, 0,0, w_width,w_height);
    XSetForeground (display, shapeGC, 1);
    /* draw the bounding/clipping shape : a circle */
    XFillArc(display, shape_mask, shapeGC, 0,0, w_width, w_height, 
             0,23040);
    /* shape the parent for event managing and the widget for drawing */
    XShapeCombineMask (display, theWindow, 
                       ShapeBounding, 0,0, shape_mask, ShapeSet); 
    XFreePixmap (display, shape_mask);
    toplevel = XtAppInitialize(&app_con, "xtile",
			       NULL, 0,
			       &argc, argv, NULL, NULL, 0);
    if (XmIsMotifWMRunning(toplevel))  {
      MwmHints     mwm_set_hints ;
      Atom         mwm_hints ;
      XWMHints     wm_set_hints;
      XUnmapEvent  Unmap_ev;
      
      mwm_hints = XmInternAtom(display, 
                               "_MOTIF_WM_HINTS", False);
      mwm_set_hints.flags = MWM_HINTS_DECORATIONS ;
      mwm_set_hints.decorations = 
        MWM_DECOR_ALL | MWM_DECOR_BORDER |
          MWM_DECOR_RESIZEH | MWM_DECOR_TITLE |MWM_DECOR_MENU|
            MWM_DECOR_MINIMIZE | MWM_DECOR_MAXIMIZE ;
      XChangeProperty(display,theWindow,
                      mwm_hints,mwm_hints,
                      32, PropModeReplace,
                      (unsigned char *)&mwm_set_hints, 
                      sizeof(MwmHints)/sizeof(int));
      XUnmapWindow(display,theWindow);
      Unmap_ev.type = UnmapNotify;
      Unmap_ev.event = DefaultRootWindow(display);
      Unmap_ev.window = theWindow;
      Unmap_ev.from_configure = False;
      XSendEvent(display, 
                 DefaultRootWindow(display), False,
                 (SubstructureNotifyMask|SubstructureRedirectMask), 
                 (XEvent *)&Unmap_ev);
      
      wm_set_hints.flags = (StateHint);
      wm_set_hints.initial_state = NormalState;
      XSetWMHints(display, theWindow, 
                  &wm_set_hints);
    } 
  }
#endif
  XMapRaised(display,theWindow);
  do {       /* wait for first expose event */
    XNextEvent(display,&report);
  } while(report.type!=Expose);
  wait = XCreateFontCursor(display,XC_watch);
  XDefineCursor(display,theWindow,wait);
  XSetWindowBackground(display,theWindow,WhitePixel(display,screen));
  XClearWindow(display,theWindow);
  XFlush(display);
  
  for(i=0;i<2;++i)
    if((f[i]=(realtype *)malloc((unsigned)(sizeof(double)*2)))==NULL)
      punt("malloc");

  readops(gfile,&op,&npair,&conjugated,&centerx,&centery,&inlist,&nin);
  if(fclose(gfile))
    punt("close");
  (void)printf("cx,cy= (%g,%g)\n",centerx,centery);
  if(nin>=nops)
    oplist = inlist;
  else
    HextendPatch(op,npair,centerx,centery,nops,
         min(fabs(unscreenx(0)-unscreenx(1)),fabs(unscreeny(0)-unscreeny(1))),
                 &oplist,inlist,nin);
  (void)printf("ready1\n");

  (void)printf("%d pairing relations\n",npair);

  if(automatic)
    {
#ifdef USEPBM
      curs = XCreateFontCursor(display,XC_crosshair);
      /* copy over pinfo structure (but steal pointers to color maps)*/
      rp = pinfo;
      rp.pic = NULL;
      rp.w = 2*radius;
      rp.h = 2*radius;
      switch(pinfo.type)
        {
        case PIC8:
          if((rp.pic=(byte *)malloc((unsigned)(sizeof(byte)*w_width*w_height)))
              ==NULL)
            punt("malloc");
          break;
        case PIC24:
          if((rp.pic=(byte *)malloc((unsigned)(sizeof(byte)*
                                               w_width*w_height*3)))==NULL)
            punt("malloc");
          break;
        default: punt("bad bit mode");
        }
      Hfpatch(op,npair,&fx,&fy,&ndot,centerx,centery);
      XFillRectangle(display,pm,gc1,0,0,2*radius,2*radius);
      xim = XGetImage(display,pm,0,0,2*radius,2*radius,AllPlanes,
                      XYPixmap);
      XFreePixmap(display,pm);
      pm_in = 0;
      if((pim=(unsigned long int **)malloc((unsigned)(
                   sizeof(unsigned long int *)*pinfo.w)))==NULL)
        punt("malloc");
      for(i=0;i<pinfo.w;++i)
        {
          if((pim[i]=(unsigned long int *)malloc((unsigned)(
                                   sizeof(unsigned long int)*pinfo.h)))==NULL)
            punt("malloc");
          for(j=0;j<pinfo.h;++j)
            switch(pinfo.colType)
              {
              case F_BWDITHER: 
                if(pinfo.pic[j*pinfo.w+i])
                  pim[i][j] = WhitePixel(display,screen);
                else
                  pim[i][j] = BlackPixel(display,screen);
                break;
              case F_GREYSCALE:
                pim[i][j] = 
                  COLORVEC[xlat[(pinfo.pic[j*pinfo.w+i]>>2)&63]].pixel;
                break;
              case F_FULLCOLOR:
                pim[i][j] = COLORVEC[xlat[(int)floor(0.25*(
                                    .33*pinfo.pic[3*(j*pinfo.w+i)]+
                                    .5*pinfo.pic[3*(j*pinfo.w+i)+1]+
                                    .17*pinfo.pic[3*(j*pinfo.w+i)+2]))]].pixel;
                break;
              default: punt("bad color type");
              }
        }
      ofsx = 0;
      ofsy = 0;
      happy = 0;
      do {
        XDefineCursor(display,theWindow,wait);
        XFlush(display);
        for(i=0;i<ndot;++i)
          XPutPixel(xim,fx[i],fy[i],pim[mod(fx[i]+ofsx,pinfo.w)][
                                                mod(fy[i]-ofsy,pinfo.h)]);
        XPutImage(display,theWindow,gc1,xim,0,0,0,0,2*radius,2*radius);
        XDefineCursor(display,theWindow,curs);
        XFlush(display);
        delta = 0;
        while((!happy)&&(!delta))
          {
            if(xnextvisevent(&report,&gevent))
              { /* saw expose */
                XDefineCursor(display,theWindow,wait);
                XFlush(display);
                XPutImage(display,theWindow,gc1,xim,0,0,0,0,2*radius,2*radius);
                XDefineCursor(display,theWindow,curs);
                XFlush(display);
              }
            if(gevent)
              switch(report.type)
                {
                case KeyPress:
                  break;
                case MotionNotify:
                  break;
                case ButtonPress:
                  switch(report.xbutton.button)
                    {
                    case 1: /* recenter */
                      XWarpPointer(display,None,theWindow,0,0,0,0,
                                   radius,radius);
                      XFlush(display);
                      break;
                    case 2: /* delta */
                      ofsx += report.xbutton.x - radius;
                      ofsy += radius - report.xbutton.y;
                      delta = 1;
                      break;
                    case 3: /* done */
                      happy = 1;
                      break;
                    default: (void)punt("bad button");
                    }
                  break;
                default: (void)printf("unexpected X event (%d)\n",report.type);
                }
          }
      } while(!happy);
      shutDown(); 
#ifndef NOFREE
      for(i=pinfo.w-1;i>=0;--i)
        free(pim[i]);
      free(pim);
      free(fx);
      free(fy);
#endif
      for(i=0;i<2*radius;++i)
        for(j=0;j<2*radius;++j)
          pcopy(&pinfo,mod(i+ofsx,pinfo.w),mod(j-ofsy,pinfo.h),&rp,i,j);
      Hreplicate(op,npair,centerx,centery,&rp,showmeth);
      if(WritePBM(ofile,rp.pic,rp.type,rp.w,rp.h,rp.r,rp.g,
                  rp.b,256,rp.colType,1,NULL))
        punt("couldn't write file");
      if(fclose(ofile))
        punt("couldn't close file");
      (void)printf("wrote \"%s\"\n",ofname);
#endif
    }
  else
    {
      curs = XCreateFontCursor(display,XC_pencil);
      XFillRectangle(display,pm,gcerase,0,0,2*radius,2*radius);          
      XClearWindow(display,theWindow);
      XDefineCursor(display,theWindow,curs);
      XFlush(display);
      /* do it */
      while(1)
        {
          if(xnextvisevent(&report,&gevent))
            { /* redraw screen */
              XDefineCursor(display,theWindow,wait);
              XFlush(display);
              XCopyArea(display,pm,theWindow,gc1,0,0,2*radius,2*radius,0,0);
              XDefineCursor(display,theWindow,curs);
#ifdef DOSHAPE
              need_draw = 0;
#endif
              XFlush(display);
            }
          if(gevent)
            {
#ifdef DOSHAPE
              if(report.type!=MotionNotify)
                {
                  if(need_draw)
                    {
                      need_draw = 0;
                      XCopyArea(display,pm,theWindow,gc1,0,0,
                                2*radius,2*radius,0,0);
                    }
                }
#endif
              switch (report.type) 
                {
                case KeyPress:
                  /* switch drawing color */
                  i = XLookupString(&(report.xkey),s,stlen-1,&keysym,NULL);
                  if(i==1)
                    {
                      if(((s[0]-'0')>=0)&&((s[0]-'0')<=min(9,ncolors)))
                        XSetForeground(display,gc1,COLORVEC[s[0]-'0'].pixel);
                      else
                        {
                          switch(s[0])
                            {
                            case 'c':
                              XFillRectangle(display,pm,gcerase,0,0,
                                             2*radius,2*radius);
                              XClearWindow(display,theWindow);
                              break;
                            case 'q':
                              goto exit_gracefull;
                              break;
                            case 's':
#ifdef USEPBM
                              XDefineCursor(display,theWindow,wait);
                              XFlush(display);
                              wpixmap(pm,ifname);
                              XDefineCursor(display,theWindow,curs);
                              XFlush(display);
#else
                              (void)fflush(stdout);
                              (void)fprintf(stderr,
                            "\nNot compiled with ability to save pixmaps.\n");
#endif
                              break;
                            case 'l':
                              XDefineCursor(display,theWindow,wait);
                              XFlush(display);
                              for(i=0;i<npair;++i)
                                {
                                  HXdrawgeodesics(op[i].vx[0],op[i].vy[0],
                                                 op[i].vx[1],op[i].vy[1],
                                                 gc1,pm,oplist,nops);
                                }
                              XCopyArea(display,pm,theWindow,gc1,0,0,
                                        2*radius,2*radius,0,0);
                              XDefineCursor(display,theWindow,curs);
                              XFlush(display);
                              break;
                            default:
                              break;
                            }
                        }
                    }
                  break;
                case ButtonPress:
                  switch(report.xbutton.button)
                    {
                    case 1:
                      if(unscreenx(report.xbutton.x)*
                         unscreenx(report.xbutton.x)+
                         unscreeny(report.xbutton.y)*
                         unscreeny(report.xbutton.y)<=
                         1.0)
                        {
                          oldx = report.xbutton.x;
                          oldy = report.xbutton.y;
                          first = 0;
                        }
                      break;
                    case 2:
                      if(unscreenx(report.xbutton.x)*
                         unscreenx(report.xbutton.x)+
                         unscreeny(report.xbutton.y)*
                         unscreeny(report.xbutton.y)
                         <=1.0)
                        {
                          if((!first)&&((oldx!=report.xbutton.x)||
                                        (oldy!=report.xbutton.y)))
                            {
                              XDefineCursor(display,theWindow,wait);
                              XFlush(display);
                              HXdrawgeodesics(unscreenx(oldx),unscreeny(oldy),
                                              unscreenx(report.xbutton.x),
                                              unscreeny(report.xbutton.y),
                                              gc1,pm,
                                              oplist,nops);
                              XCopyArea(display,pm,theWindow,gc1,0,0,
                                        2*radius,2*radius,0,0);
                              XDefineCursor(display,theWindow,curs);
                              XFlush(display);
                            }
                          oldx = report.xbutton.x;
                          oldy = report.xbutton.y;
                          first = 0;
                        }
                      break;
                    case 3:
                      XDefineCursor(display,theWindow,wait);
                      XFlush(display);
#ifndef DOSHAPE
                      XDrawArc(display,theWindow,gc1,0,0,2*radius,2*radius,
                               0,360*64);
                      XDrawArc(display,pm,gc1,0,0,2*radius,2*radius,
                               0,360*64);
#endif
                      for(i=0;i<npair;++i)
                        {
#if debug_hyp>=2
                          (void)printf("%d.[[%g %g][%g %g] (0,0)->(%g,%g)\n",i,
                                       op[i].a[0][0],op[i].a[0][1],
                                       op[i].a[1][0],op[i].a[1][1],
                                       op[i].gx,op[i].gy);
                          for(j=0;j<op[i].nv;++j)
                            {
                              XDrawArc(display,theWindow,gc1,
                                       screenx(op[i].vx[j]) - 5,
                                       screeny(op[i].vy[j]) - 5,
                                       (unsigned int)10,
                                       (unsigned int)10,
                                       0,64*360);
                            }
                          XDrawRectangle(display,theWindow,gc1,
                                         screenx(op[i].ax) - 5,
                                         screeny(op[i].ay) - 5,
                                         (unsigned int)10,
                                         (unsigned int)10);
                          XDrawRectangle(display,theWindow,gc1,
                                         screenx(op[i].bx) - 5,
                                         screeny(op[i].by) - 5,
                                         (unsigned int)10,
                                         (unsigned int)10);
#endif
                          HXdrawgeodesic(op[i].vx[0],op[i].vy[0],
                                         op[i].vx[1],op[i].vy[1],
                                         gc1,theWindow);
#ifdef debug_hyp
                          (void)printf(" (%g,%g)->(%g,%g)\n",op[i].vx[0],
                                       op[i].vy[0],op[i].vx[1],op[i].vy[1]);
                          XFlush(display);
#endif
                        }
                      XDefineCursor(display,theWindow,curs);
                      XFlush(display);
                      break;
                    default: punt("bad button");
                    }
                  break;
                case MotionNotify:
                  if((unscreenx(report.xmotion.x)*
                      unscreenx(report.xmotion.x)+
                      unscreeny(report.xmotion.y)*
                      unscreeny(report.xmotion.y)
                      <=1.0)&&
                     (report.xmotion.state&(Button1Mask|Button2Mask)))
                    {
                      if(report.xmotion.state&Button1Mask)
                        {
                          drawpoints(gc1,report.xmotion.x,report.xmotion.y,
                                     oplist,nops);
#ifdef DOSHAPE
                          ++motion_pulse;
                          if(motion_pulse>=motion_stutter)
                            {
                              motion_pulse = 0;
                              if(need_draw)
                                {
                                  need_draw = 0;
                                  XCopyArea(display,pm,theWindow,gc1,0,0,
                                            2*radius,2*radius,0,0);
                                }
                            }
#endif
                        }
                      if(report.xmotion.state&Button2Mask)
                        {
                          XDefineCursor(display,theWindow,wait);
                          XFlush(display);
                          HXdrawgeodesics(unscreenx(oldx),unscreeny(oldy),
                                          unscreenx(report.xmotion.x),
                                          unscreeny(report.xmotion.y),gc1,pm,
                                          oplist,nops);
                          XCopyArea(display,pm,theWindow,gc1,0,0,
                                    2*radius,2*radius,0,0);
                          
                          XDefineCursor(display,theWindow,curs);
                          XFlush(display);
                        }
                      first = 0;
                      oldx = report.xmotion.x;
                      oldy = report.xmotion.y;
                      XFlush(display);
                    }
                  break;
                default:
                  (void)printf("unknown X event type (%d)\n",report.type);
                }
            }
        }
    exit_gracefull:
      shutDown();
    }
  
  /* end of X junk */
  return 0;
}


#ifdef USEPBM
#ifdef __STDC__
char *BaseName(char *s) {  return s; }
void FatalError(char *s) {  punt(s); }
#if !defined(NOSTDHDRS)
void SetISTR(int fmt, ...) { punt("setistr"); }
#else
void SetISTR() { punt("setistr"); }
#endif
void WaitCursor(void) { return;};
#else
char *BaseName(s)
     char *s
{  return s; }
void FatalError(s)
     char *s;
{  punt(s) }
void SetISTR() { punt("setistr"); }
void WaitCursor() { };
#endif
#endif
