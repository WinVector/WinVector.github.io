
/*
    <xtile, hcom: hyperbolic tile sketch pad >
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#if defined(__hpux)&&defined(__STDC__)&&!defined(_HPUX_SOURCE)
#define _HPUX_SOURCE
#endif


#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>
#include "config.h"
#include "util.h"
#include "splay.h"
#include "nr.h"
#include "dist.h"
#include "hyp.h"

#define stlen 256
#define shrl 128


#ifdef __STDC__
int main(int argc,char *argv[])
#else
int main(argc,argv)
     int argc;
     char *argv[];
#endif
{
  int i,c,ngens,sparm,error,npair,conjugated,nops,sawp,sawq,sawr,p,q,r;
  int conserveconj,stayconjugated;
  char fname[stlen];
  extern char *optarg;
  extern int optind;
  FILE *ifile,*ofile;
  realtype ***gens,centerx,centery;
  toptype *op;
  optype *oplist;

  start_up(0);
  mysrandom(7845);
  error = 0;
  conserveconj = 0;
  stayconjugated = 0;
  sawp = 0;
  sawq = 0;
  sawr = 0;
  p = 3;
  q = 3;
  r = 3;
  gens = NULL;
  while((c = getopt(argc,argv,":ncf:s:t:p:q:r:"))!=EOF)
    switch(c)
      {
      case 'p':
        sawp = 1;
        if((optarg==NULL)||(optarg[0]==0))
          ++error;
        else
          p = atoi(optarg);
        break;
      case 'q':
        sawq = 1;
        if((optarg==NULL)||(optarg[0]==0))
          ++error;
        else
          q = atoi(optarg);
        break;
      case 'r':
        sawr = 1;
        if((optarg==NULL)||(optarg[0]==0))
          ++error;
        else
          r = atoi(optarg);
        break;
      case 'c':
        conserveconj = 1;
        break;
      case 'n':
        stayconjugated = 1;
        break;
      case 'f': 
        if((optarg==NULL)||(optarg[0]==0)||sawp||sawq||sawr)
          ++error;
        else
          {
            strncpy(fname,optarg,shrl-1);
            fname[shrl-1] = 0;
            if((ifile=fopen(fname,"r"))==NULL)
              punt("couldn't open in file");
            gens = readgen(&ngens,ifile);
            if(fclose(ifile))
              punt("close");
            if(!rmsuffix(fname,insuffix))
              ++error;
            else
              (void)strcat(fname,suffix);
          }
        break;
      case 's':
        if((optarg==NULL)||(optarg[0]==0)||sawp||sawq||sawr)
          ++error;
        else
          {
            sparm = atoi(optarg);
            gens = sgroup(&ngens,sparm);
            (void)sprintf(fname,"sq%d%s",sparm,suffix);
          }
        break;
      case 't':
        if((optarg==NULL)||(optarg[0]==0)||sawp||sawq||sawr)
          ++error;
        else
          {
            sparm = atoi(optarg);
            gens = tgroup(&ngens,sparm);
            (void)sprintf(fname,"tr%d%s",sparm,suffix);
          }
        break;
      default:
        ++error;
        break;
      }
  if(sawp||sawq||sawr)
    {
      if(gens!=NULL)
        ++error;
      else
        {
          gens = trigroup(&ngens,p,q,r);
          (void)sprintf(fname,"tg%d_%d_%d%s",p,q,r,suffix);
        }
    }
  if(error||(optind>=argc)||(gens==NULL))
    punt("use: hcom [-n][-c](-f file | -s num | -t num | -p num -q num -r num) nops");
  nops = atoi(argv[optind]);

  HdoGroup(gens,ngens,&op,&npair,&conjugated,&centerx,&centery,
           conserveconj,stayconjugated);
  HextendPatch(op,npair,centerx,centery,nops,float_tol,&oplist,NULL,0);
  if((ofile=fopen(fname,"w"))==NULL)
    punt("couldn't open output file");
  writeops(ofile,op,npair,conjugated,centerx,centery,oplist,nops);
  if(fclose(ofile))
    punt("fclose");
  return 0;
}
