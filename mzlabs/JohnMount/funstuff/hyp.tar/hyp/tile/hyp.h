
/*
    <xtile, hcom: hyperbolic tile sketch pad >
    Copyright (C) 1994  John Mount
        jmount+@cs.cmu.edu
        
        John Mount
        School of Computer Science
        Carnegie Mellon Univ
        Pittsburgh, Pa 15213

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef HYP_INCLUDED
#define HYP_INCLUDED

#define comlen 15

typedef struct {
  double **a;
  double c[comlen];
  double psindex;
} optype;


typedef struct {
  int nv;
  double gx,gy,**a,ax,ay,bx,by,vx[2],vy[2],c[comlen],**ai,ci[comlen],fcx,fcy;
} toptype;


#define min(a,b) (((a)<=(b))?(a):(b))
#define max(a,b) (((a)<=(b))?(b):(a))



#define float_tol 0.00000001
#define scaleddiff(a,b) (((a)-(b))/(max(1.0,max(fabs(a),fabs(b)))))
#define uscaleddiff(a,b) (fabs((a)-(b))/(max(1.0,max(fabs(a),fabs(b)))))

#ifdef __STDC__
extern double floor(double);
extern void Hcanonicalize(realtype **a);
extern realtype det(realtype **a);
extern void Hinverse(realtype **a,realtype **b);
extern void Hcompose(realtype **a,realtype **b,realtype **c);
extern void HFsend(realtype a, realtype b, realtype **m);
extern realtype HFdist(realtype px, realtype py, realtype qx, realtype qy);
extern int Hintersect(realtype rx,realtype ry,realtype sx, realtype sy,
                      realtype *x,realtype *y);
extern void Hboundary(realtype tx, realtype ty,realtype *px,realtype *py,
                      realtype *qx, realtype *qy);
extern realtype Lclose(realtype ax, realtype ay, realtype bx, realtype by);
extern void Hconvert(realtype rx, realtype ry, realtype *r, 
                realtype *cx, realtype *cy);
extern void Hgeodesic(realtype x1, realtype y1, realtype x2, realtype y2,
                      realtype *rx, realtype *ry);
extern realtype Hvisdist(realtype x1, realtype y1,realtype x2, realtype y2,
                       realtype tol);
extern void Hmap(realtype c[], realtype x, realtype y, 
                 realtype *qx, realtype *qy);
extern void Hcompile(realtype **m,realtype *c);
extern void Happly(realtype **m,realtype x,realtype y,
                   realtype *qx,realtype *qy);
extern realtype Qapply(realtype **m,realtype *qx,realtype *qy);
extern realtype Hpdist(toptype *op, int npair,optype *m,
                       realtype cx,realtype cy,
                       realtype tol);
extern int near(realtype **a,realtype **b);
extern int Hcompare(const gptr ain,const gptr bin);
extern int not_covered(Tree **t,optype *m);
extern realtype ***readgen(int *ngens,FILE *in);
extern int HinEfund(toptype *op, int npair,realtype centerx,realtype centery,
                   realtype x,realtype y,realtype slop);
extern int HinOfund(toptype *op, int npair,realtype centerx,realtype centery,
                   realtype x,realtype y,realtype slop);
extern void HdoGroup(realtype ***gen,int ngens,
                     toptype **top,int *rnpair,int *conjugated,
                     realtype *cx,realtype *cy,
                     int conserveconj,int stayconjugated);
extern void HextendPatch(toptype *op, int npair, 
                         realtype cx, realtype cy,int nops, 
                         realtype tol, optype **rlist, 
                         optype *inlist, int nin);
extern realtype ***sgroup(int *ngens,int dtouch);
extern realtype ***tgroup(int *ngens,int dtouch);
extern realtype ***trigroup(int *ngens,int p,int q, int r);
extern void readops(FILE *f,toptype **op, int *npair,int *conjugated,
             realtype *centerx, realtype *centery, optype **oplist,
             int *nops);
extern void writeops(FILE *f,toptype *op, int npair,int conjugated,
              realtype centerx, realtype centery, optype *oplist, int nops);
extern void HPmap(toptype *op, int npair, realtype centerx, realtype centery,
                  realtype x, realtype y, realtype **f,realtype tol);
extern int rmsuffix(char s[],char suf[]);
#else
extern double floor();
extern void Hcanonicalize();
extern realtype det();
extern void Hinverse();
extern void Hcompose();
extern void HFsend();
extern realtype HFdist();
extern int Hintersect();
extern void Hboundary();
extern realtype Lclose();
extern void Hconvert();
extern void Hgeodesic();
extern realtype Hvisdist();
extern void Hmap();
extern void Hcompile();
extern void Happly();
extern realtype Qapply();
extern realtype Hpdist();
extern int near();
extern int Hcompare();
extern int not_covered();
extern realtype ***readgen();
extern int HinEfund();
extern int HinOfund();
extern void HdoGroup();
extern void HextendPatch();
extern realtype ***sgroup();
extern realtype ***tgroup();
extern realtype ***trigroup();
extern void readops();
extern void writeops();
extern void HPmap();
extern int rmsuffix();
#endif

#define suffix ".HYP"
#define insuffix ".hyp"

#endif
