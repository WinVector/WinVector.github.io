# WVPlots

Common plots we use for analysis and presentation (on top of ggplot2 in [R](https://cran.r-project.org)).  For an introduction see: http://www.win-vector.com/blog/2016/04/wvplots-example-plots-in-r-using-ggplot2/

Website: [https://github.com/WinVector/WVPlots](https://github.com/WinVector/WVPlots)

More:

 * http://www.win-vector.com/blog/2013/02/revisiting-clevelands-the-elements-of-graphing-data-in-ggplot2/
 * http://www.win-vector.com/blog/2011/12/my-favorite-graphs/
 * http://www.win-vector.com/blog/2009/11/i-dont-think-that-means-what-you-think-it-means-statistics-to-english-translation-part-1-accuracy-measures/
 

To install in R:


    # install.packages(c('devtools','ggplot2'))
    devtools::install_github('WinVector/WVPlots',build_vignettes = TRUE)
    library('WVPlots')
    help('WVPlots')

