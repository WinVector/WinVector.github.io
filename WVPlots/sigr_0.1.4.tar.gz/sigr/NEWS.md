
'sigr'0.1.4 2017/01/17

 * More standard (data.frame plus column names) interfaces.

'sigr'0.1.3 2017/01/15

 * First CRAN submission.
