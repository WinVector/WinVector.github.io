
'sigr'0.1.3 2017/01/15

First CRAN submission.
