library(testthat)
library(sigr)

test_check("sigr")
