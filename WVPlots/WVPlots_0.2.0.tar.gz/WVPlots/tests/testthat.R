library(testthat)
library(WVPlots)

test_check("WVPlots")
