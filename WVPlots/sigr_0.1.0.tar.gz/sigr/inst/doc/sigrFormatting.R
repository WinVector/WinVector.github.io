## ----results='asis'------------------------------------------------------
sigr::getRenderingFormat()
cat(sigr::formatSignificance(1/300))

## ----results='asis'------------------------------------------------------
cat(sigr::formatFTestImpl(numdf=2,dendf=55,FValue=5.56)$formatStr)

## ------------------------------------------------------------------------
d <- data.frame(x=0.2*(1:20))
d$y <- cos(d$x)
model <- lm(y~x,data=d)
d$prediction <- predict(model,newdata=d)
print(summary(model))

## ----results='asis'------------------------------------------------------
cat(sigr::formatFTest(model,pSmallCutoff=1.0e-12)$formatStr)
cat(sigr::formatFTest(d,'prediction','y',
                              pSmallCutoff=1.0e-12)$formatStr)

## ------------------------------------------------------------------------
d <- data.frame(x=c(1,2,3,4,5,6,7,7),
       y=c(TRUE,FALSE,FALSE,FALSE,TRUE,TRUE,TRUE,FALSE))
model <- glm(y~x,data=d,family=binomial)
model$converged
summary(model)
d$pred <- predict(model,type='response',newdata=d)

## ----results='asis'------------------------------------------------------
cat(sigr::formatChiSqTest(model,pLargeCutoff=1)$formatStr)
cat(sigr::formatChiSqTest(d,'pred','y',pLargeCutoff=1)$formatStr)

## ------------------------------------------------------------------------
d <- data.frame(x=c(1,2,3,4,5,6,7,7),
               y=c(1,1,2,2,3,3,4,4))
ct <- cor.test(d$x,d$y)

## ----results='asis'------------------------------------------------------
cat(sigr::formatCorTest(ct)$formatStr)

## ------------------------------------------------------------------------
d <- data.frame(x=c('b','a','a','a','b','b','b'),
                y=c('1','1','1','2','2','2','2'))
ft <- fisher.test(table(d))

## ----results='asis'------------------------------------------------------
cat(sigr::formatFisherTest(ft,pLargeCutoff=1)$formatStr)

## ------------------------------------------------------------------------
d <- data.frame(x=c(1,2,3,4,5,6,7,7),
                y=c(1,1,2,2,3,3,4,4))
ft <- t.test(d$x,d$y)

## ----results='asis'------------------------------------------------------
cat(sigr::formatTTest(ft,pLargeCutoff=1)$formatStr)

## ----results='asis'------------------------------------------------------
parallelCluster <- NULL
#parallelCluster <- parallel::makeCluster(parallel::detectCores())

set.seed(25325)
d <- data.frame(x1=c(1,2,3,4,5,6,7,7),
                y=c(FALSE,TRUE,FALSE,FALSE,
                    TRUE,TRUE,FALSE,TRUE))
d <- rbind(d,d,d,d)
sigr::formatAUC(d,'x1','y',TRUE,pLargeCutoff=1,
                nrep=200,
                parallelCluster=parallelCluster)

set.seed(25325)
d <- data.frame(x1=c(1,2,3,4,5,6,7,7),
                x2=1,
                y=c(FALSE,TRUE,FALSE,FALSE,
                    TRUE,TRUE,FALSE,TRUE))
d <- rbind(d,d,d,d)
sigr::formatAUCpair(d,'x1','x2','y',TRUE,pLargeCutoff=1,
                    nrep=200,
                    parallelCluster=parallelCluster)
if(!is.null(parallelCluster)) {
  parallel::stopCluster(parallelCluster)
}

## ------------------------------------------------------------------------
set.seed(25325)
y <- 1:5
m <- c(1,1,2,2,2)
cor.test(m,y,alternative='greater')
f <- function(modelValues,yValues) cor(modelValues,yValues)
sigr::permutationScoreModel(m,y,f)

## ------------------------------------------------------------------------
set.seed(25325)
y <- 1:5
m1 <- c(1,1,2,2,2)
cor.test(m1,y,alternative='greater')
f <- function(modelValues,yValues) {
  if((sd(modelValues)<=0)||(sd(yValues)<=0)) {
    return(0)
  }
  cor(modelValues,yValues)
}
s <- sigr::resampleScoreModel(m1,y,f)
print(s)
z <- s$observedScore/s$sd  # always check size of z relative to bias!
pValue <- pt(z,df=length(y)-2,lower.tail=FALSE)
pValue

## ------------------------------------------------------------------------
set.seed(25325)
y <- 1:5
m1 <- c(1,1,2,2,2)
m2 <- c(1,1,1,1,2)
cor(m1,y)
cor(m2,y)
f <- function(modelValues,yValues) {
  if((sd(modelValues)<=0)||(sd(yValues)<=0)) {
    return(0)
  }
  cor(modelValues,yValues)
}
sigr::resampleScoreModelPair(m1,m2,y,f)

